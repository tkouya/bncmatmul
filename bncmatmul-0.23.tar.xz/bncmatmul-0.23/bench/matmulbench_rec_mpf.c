/********************************************************************************/
/* matmulbench_rec_mpf.c:                                                       */
/* Copyright (C) 2014 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bnc.h"
#include "matmul_strassen.h"

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)


#ifdef USE_GMP

// relative errors
void relerr3_mpfmatrix(mpf_t max_relerr, mpf_t min_relerr, mpf_t norm_relerr, MPFMatrix mat, MPFMatrix mat_true, int kind_of_norm)
{
	unsigned long prec;
	long int i, j, row_dim, col_dim;
	mpf_t tmp_relerr, mat_true_norm;
	MPFMatrix tmp_diff_mat;

	prec = mat->prec;
	row_dim = mat->row_dim;
	col_dim = mat->col_dim;

	mpf_init2(tmp_relerr, prec);
	mpf_init2(mat_true_norm, prec);
	tmp_diff_mat = init2_mpfmatrix(row_dim, col_dim, prec);

	// diff_mat := mat - mat_true
	sub_mpfmatrix(tmp_diff_mat, mat, mat_true);

	// norm_relerr
	switch(kind_of_norm)
	{
		case 0: // infinit norm
			normi_mpfmatrix(norm_relerr, tmp_diff_mat);
			normi_mpfmatrix(mat_true_norm, mat_true);
			break;
		case 1: // 1-norm
			norm1_mpfmatrix(norm_relerr, tmp_diff_mat);
			norm1_mpfmatrix(mat_true_norm, mat_true);
			break;
		case 2: // Frobenius norm
		default:
			normf_mpfmatrix(norm_relerr, tmp_diff_mat);
			normf_mpfmatrix(mat_true_norm, mat_true);
			break;
	}
	if(mpf_cmp_ui(mat_true_norm, 0UL) != 0)
		mpf_div(norm_relerr, norm_relerr, mat_true_norm);

	// relative errors at each elements
	mpf_set_ui(max_relerr, 0UL);
	mpf_set_ui(min_relerr, 0UL);

	for(i = 0; i < row_dim; i++)
	{
		for(j = 0; j < col_dim; j++)
		{
			mpf_abs(tmp_relerr, get_mpfmatrix_ij(tmp_diff_mat, i, j));
			if(mpf_cmp_ui(get_mpfmatrix_ij(mat_true, i, j), 0UL) != 0)
			{
				mpf_div(tmp_relerr, tmp_relerr, get_mpfmatrix_ij(mat_true, i, j));
				mpf_abs(tmp_relerr, tmp_relerr);
			}

			if(mpf_cmp(max_relerr, tmp_relerr) < 0)
				mpf_set(max_relerr, tmp_relerr);
			if(mpf_cmp(min_relerr, tmp_relerr) > 0)
				mpf_set(min_relerr, tmp_relerr);
		}
	}

	mpf_clear(tmp_relerr);
	mpf_clear(mat_true_norm);
	
	free_mpfmatrix(tmp_diff_mat);

	return;
}

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_rec_mpf(long int row_dim, long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec, long int min_dim)
{
	long int dim;
	long int i, j, end_flag;
	long int num_addsub, num_mul;
	double iteration, etime, stime, mflops;
	MPFMatrix da, db, dc, dc_long;
	mpf_t tmp, relerr[3];

	mpf_init2(tmp, prec);
	mpf_init2(relerr[0], prec);
	mpf_init2(relerr[1], prec);
	mpf_init2(relerr[2], prec);

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init2_mpfmatrix(row_dim, dim, prec);
		db = init2_mpfmatrix(dim, row_dim, prec);
		dc = init2_mpfmatrix(row_dim, row_dim, prec);
		dc_long = init2_mpfmatrix(row_dim, row_dim, (unsigned long)(prec + prec / 2));

		for(i = 0; i < row_dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_mpfmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
				mpf_sqrt_ui(tmp, 5UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(i + j + 1));
				set_mpfmatrix_ij(da, i, j, tmp);
			}
			for(j = 0; j < row_dim; j++)
			{
				mpf_sqrt_ui(tmp, 2UL);
				set_mpfmatrix_ij(dc, i, j, tmp);
			}
		}
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < row_dim; j++)
			{
//				set_mpfmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				mpf_sqrt_ui(tmp, 3UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(dim - i));
				set_mpfmatrix_ij(db, i, j, tmp);
			}
		}

		iteration = 1.0;
		do{
			stime = get_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
				reset_num_mul_mpfmatrix_strassen();
				mul_mpfmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
//				mul_mpfmatrix_strassen(dc, da, db, min_dim);
				get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
			}

#elif USE_STRASSEN_PADDING
			for(i = 0; i < iteration; i++)
			{
				reset_num_mul_mpfmatrix_strassen();
				mul_mpfmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
//				mul_mpfmatrix_strassen_odd_padding(dc, da, db, min_dim);
				get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
			}

#elif USE_BLOCK
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			for(i = 0; i < iteration; i++) mul_mpfmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
//			for(i = 0; i < iteration; i++) mul_mpfmatrix_block(dc, da, db, min_dim);
#else
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			for(i = 0; i < iteration; i++) mul_mpfmatrix_simple(dc, da, db);
#endif
			etime = get_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);

		if(etime > maxsec)
			end_flag = 1;

		// get relative errors
		mul_mpfmatrix_strassen(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
//		mul_mpfmatrix_simple(dc_long, da, db);
		relerr3_mpfmatrix(relerr[0], relerr[1], relerr[2], dc, dc_long, 0);

		etime /= iteration / 2;

//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		printf("[%5ld bits] (%5ld x %5ld) * (%5ld x %5ld): %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, row_dim, dim, dim, row_dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[0]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[1]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_mpfmatrix(da);
		free_mpfmatrix(db);
		free_mpfmatrix(dc);
		free_mpfmatrix(dc_long);
	}

	mpf_clear(tmp);
	mpf_clear(relerr[0]);
	mpf_clear(relerr[1]);
	mpf_clear(relerr[2]);

	return end_flag;
}
#endif

// usage
void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	printf("USAGE-> %s precision(in bits) [row_dim] [min_dim] [Maximum seconds]\n", commandname);
#else
	printf("USAGE-> %s precision(in bits) [row_dim] [Maximum seconds]\n", commandname);
#endif
}

int main(int argc, char *argv[])
{
	long int row_dim, dim, idim, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 600;
	unsigned long prec;

	if(argc <= 2)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 3)
	{
		prec = atol(argv[1]);
		if(prec <= 0)
		{
			printf("Invalid precision in bit! (%ld bits)\n", prec);
			return -1;
		}

		row_dim = atol(argv[2]);

#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
		if(row_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
		{
			printf("Warning: Too small row_dim (%ld < %d)\n", row_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			//return -1;
		}

		if(argc >= 4)
		{
			min_dim = atol(argv[3]);
			if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
			{
				printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				//return -1;
			}
		}
#endif
	}

	set_bnc_default_prec(prec);

	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

//	for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	{
		end_flag = 0;

//		end_flag = matmulloop_mpf(idim - 1, idim + 1, 1, maxsec, 0, prec);
		end_flag = matmulloop_rec_mpf(row_dim, idim - 1, idim + 1, 1, maxsec, 0, prec, min_dim);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_mpf(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, prec, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

