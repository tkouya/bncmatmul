/********************************************************************************/
/* lu_bench_dd.c: Quadruple Precision LU decomposition with Strassen MM         */
/*                                                                              */
/* Copyright (C) 2015-2021 Tomonori Kouya                                       */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/* stdio.h */
#ifndef _STDIO_H
#include <stdio.h>
#endif

/* math.h */
#ifndef _MATH_H
#include <math.h>
#endif

//#include "bnc.h"

#include "ddlinear.h"

#include "bncomp.h"
#include "matmul_strassen.h"


// (1) L11 * U11 = A11
//
//    start_index
// +--+-----+--------+
// |  +-----+        |
// |  |\ U11|        |
// |  |L11\ |        |
// +  +-----+        |
// |  min_dim        |
// |                 |
// |                 |
// |                 |
// +-----------+-----+
//
int DDLUdecomp_square(DDMatrix a, long int start_index, long int min_dim)
{
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[DDSIZE], dtmp1[DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	// dim > min_dim
	for(i = start_index; i < imax; i++)
	{
		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_square)!\n", i);
			return -1;
		}

		for(j = (i + 1); j < jmax; j++)
		{
			rdd_div(dtmp, get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, i));
			set_ddmatrix_ij(a, j, i, dtmp);
		}

		for(j = (i + 1); j < jmax; j++)
		{
			for(k = (i + 1); k < jmax; k++)
			{
				//get_dmatrix_ij(a, j, k) - get_dmatrix_ij(a, j, i) * get_dmatrix_ij(a, i, k)
				rdd_mul(dtmp1, get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, k));
				rdd_sub(dtmp, get_ddmatrix_ij(a, j, k), dtmp1);
				set_ddmatrix_ij(a, j, k, dtmp);
			}
		}
	}

	return 0;
}

#ifdef _OPENMP
int DDLUdecomp_square_omp(DDMatrix a, long int start_index, long int min_dim)
{
	int thread_index, thread_num;
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[128][DDSIZE], dtmp1[128][DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	#pragma omp parallel private(thread_index)
	{
		thread_index = omp_get_thread_num();

		set0_dd(dtmp[thread_index]);
		set0_dd(dtmp1[thread_index]);
	}

	set0_dd(dmaxii);

	// dim > min_dim
	for(i = start_index; i < imax; i++)
	{
		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_square)!\n", i);
			return -1;
		}

		#pragma omp parallel for private(thread_index)
		for(j = (i + 1); j < jmax; j++)
		{
			thread_index = omp_get_thread_num();

			rdd_div(dtmp[thread_index], get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, i));
			set_ddmatrix_ij(a, j, i, dtmp[thread_index]);
		}

		#pragma omp parallel for private(thread_index, k)
		for(j = (i + 1); j < jmax; j++)
		{
			thread_index = omp_get_thread_num();

			for(k = (i + 1); k < jmax; k++)
			{
				//get_dmatrix_ij(a, j, k) - get_dmatrix_ij(a, j, i) * get_dmatrix_ij(a, i, k)
				rdd_mul(dtmp1[thread_index], get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, k));
				rdd_sub(dtmp[thread_index], get_ddmatrix_ij(a, j, k), dtmp1[thread_index]);
				set_ddmatrix_ij(a, j, k, dtmp[thread_index]);
			}
		}
	}

	return 0;
}
#endif // _OPENMP

// (2) Solve L21 * U11 = A21
//
//    start_index
// +--+-----+--------+
// |  +-----+        |
// |  |\ U11|        |
// |  |L11\ |        |
// +  +-----+        |
// |  |     |        |
// |  |     |        |
// |  | L21 |        |
// |  |     |        |
// +--+-----+--------+
//
int DDLUdecomp_l21(DDMatrix l21, DDMatrix a, long int start_index, long int min_dim)
{
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[DDSIZE], dtmp1[DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	// dim > min_dim
	for(i = imax; i < dim; i++)
	{
		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_l21)!\n", i);
			return -1;
		}

		for(j = start_index; j < jmax; j++)
		{
			rdd_set(dtmp, get_ddmatrix_ij(a, i, j));
			for(k = start_index; k < j; k++)
			{
				//dtmp -= get_dmatrix_ij(a, i, k) * get_dmatrix_ij(a, k, j);
				rdd_mul(dtmp1, get_ddmatrix_ij(a, i, k), get_ddmatrix_ij(a, k, j));
				rdd_sub(dtmp, dtmp, dtmp1);
			}
			rdd_div(dtmp1, dtmp, get_ddmatrix_ij(a, j, j));
			rdd_set(dtmp, dtmp1);
			
			//printf("l21(i              , j       ) = (%ld, %ld), %ld, %ld\n", i, j, l21->row_dim, l21->col_dim);
			//printf("l21(i - start_index, j - imax) = (%ld, %ld), %ld, %ld\n", i - imax, j - start_index, l21->row_dim, l21->col_dim);
			//printf("(i              , j       ) = (%ld, %ld) %25.17e, %25.17e\n", i, j, dtmp, get_dmatrix_ij(a, j, j));
			set_ddmatrix_ij(a  , i              , j       , dtmp);
			set_ddmatrix_ij(l21, i - imax, j - start_index, dtmp);
		}
	}

	return 0;
}

#ifdef _OPENMP
int DDLUdecomp_l21_omp(DDMatrix l21, DDMatrix a, long int start_index, long int min_dim)
{
	int thread_index, thread_num;
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[128][DDSIZE], dtmp1[128][DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	#pragma omp parallel private(thread_index)
	{
		thread_index = omp_get_thread_num();
		
		set0_dd(dtmp[thread_index]);
		set0_dd(dtmp1[thread_index]);
	}

	set0_dd(dmaxii);

	// dim > min_dim
	#pragma omp parallel for private(thread_index, j, k)
	for(i = imax; i < dim; i++)
	{
		thread_index = omp_get_thread_num();

		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_l21_omp)!\n", i);
			//return -1;
		}

		for(j = start_index; j < jmax; j++)
		{
			rdd_set(dtmp[thread_index], get_ddmatrix_ij(a, i, j));
			for(k = start_index; k < j; k++)
			{
				//dtmp -= get_dmatrix_ij(a, i, k) * get_dmatrix_ij(a, k, j);
				rdd_mul(dtmp1[thread_index], get_ddmatrix_ij(a, i, k), get_ddmatrix_ij(a, k, j));
				rdd_sub(dtmp[thread_index], dtmp[thread_index], dtmp1[thread_index]);
			}
			rdd_div(dtmp1[thread_index], dtmp[thread_index], get_ddmatrix_ij(a, j, j));
			rdd_set(dtmp[thread_index], dtmp1[thread_index]);
			
			//printf("l21(i              , j       ) = (%ld, %ld), %ld, %ld\n", i, j, l21->row_dim, l21->col_dim);
			//printf("l21(i - start_index, j - imax) = (%ld, %ld), %ld, %ld\n", i - imax, j - start_index, l21->row_dim, l21->col_dim);
			//printf("(i              , j       ) = (%ld, %ld) %25.17e, %25.17e\n", i, j, dtmp, get_dmatrix_ij(a, j, j));
			set_ddmatrix_ij(a  , i              , j       , dtmp[thread_index]);
			set_ddmatrix_ij(l21, i - imax, j - start_index, dtmp[thread_index]);
		}
	}

	return 0;
}
#endif // _OPENMP

// (3) Solve L11 * U12 = A21
//
//    start_index
// +--+-----+--------+
// |  +-----+--------+
// |  |\ U11|  U12   |
// |  |L11\ |        |
// +  +-----+--------+
// |  |     |        |
// |  |     |        |
// |  | L21 |        |
// |  |     |        |
// +--+-----+--------+
//
int DDLUdecomp_u12(DDMatrix u12, DDMatrix a, long int start_index, long int min_dim)
{
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[DDSIZE], dtmp1[DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	// dim > min_dim
	for(i = imax; i < dim; i++)
	{
		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_u12)!\n", i);
			return -1;
		}

		for(j = start_index; j < jmax; j++)
		{
			rdd_set(dtmp, get_ddmatrix_ij(a, j, i));
			//printf("(j              , i              ) = (%ld, %ld) %25.17e\n", j, i , dtmp);
			for(k = start_index; k < j; k++)
			{
				//dtmp -= get_ddmatrix_ij(a, j, k) * get_ddmatrix_ij(a, k, i);
				rdd_mul(dtmp1, get_ddmatrix_ij(a, j, k), get_ddmatrix_ij(a, k, i));
				rdd_sub(dtmp, dtmp, dtmp1);
				//printf("(j - start_index, k - start_index) = (%ld, %ld)\n", j - start_index, k - start_index);
			}
			//printf("u12(j              , i       ) = (%ld, %ld) %ld, %ld\n", j, i, u12->row_dim, u12->col_dim);
			//printf("u12(j - start_index, i - imax) = (%ld, %ld) %ld, %ld\n", j - start_index, i - imax, u12->row_dim, u12->col_dim);
			set_ddmatrix_ij(a  , j              , i       , dtmp);
			set_ddmatrix_ij(u12, j - start_index, i - imax, dtmp);
		}
	}

	return 0;
}

#ifdef _OPENMP
int DDLUdecomp_u12_omp(DDMatrix u12, DDMatrix a, long int start_index, long int min_dim)
{
	int thread_index;
	long int i, j, k, imax, jmax, itmp, dim;
	static double dtmp[128][DDSIZE], dtmp1[128][DDSIZE], dmaxii[DDSIZE];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	#pragma omp parallel private(thread_index)
	{
		thread_index = omp_get_thread_num();

		set0_dd(dtmp[thread_index]);
		set0_dd(dtmp1[thread_index]);
	}

	// dim > min_dim
	#pragma omp parallel for private(thread_index, j, k)
	for(i = imax; i < dim; i++)
	{
		thread_index = omp_get_thread_num();

		rdd_abs(dmaxii, get_ddmatrix_ij(a, i, i));
		if(rdd_cmp_ui(dmaxii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_u12)!\n", i);
			//return -1;
		}

		for(j = start_index; j < jmax; j++)
		{
			rdd_set(dtmp[thread_index], get_ddmatrix_ij(a, j, i));
			//printf("(j              , i              ) = (%ld, %ld) %25.17e\n", j, i , dtmp);
			for(k = start_index; k < j; k++)
			{
				//dtmp -= get_ddmatrix_ij(a, j, k) * get_ddmatrix_ij(a, k, i);
				rdd_mul(dtmp1[thread_index], get_ddmatrix_ij(a, j, k), get_ddmatrix_ij(a, k, i));
				rdd_sub(dtmp[thread_index], dtmp[thread_index], dtmp1[thread_index]);
				//printf("(j - start_index, k - start_index) = (%ld, %ld)\n", j - start_index, k - start_index);
			}
			//printf("u12(j              , i       ) = (%ld, %ld) %ld, %ld\n", j, i, u12->row_dim, u12->col_dim);
			//printf("u12(j - start_index, i - imax) = (%ld, %ld) %ld, %ld\n", j - start_index, i - imax, u12->row_dim, u12->col_dim);
			set_ddmatrix_ij(a  , j              , i       , dtmp[thread_index]);
			set_ddmatrix_ij(u12, j - start_index, i - imax, dtmp[thread_index]);
		}
	}

	return 0;
}
#endif // _OPENMP


// (4) D22 := L21 * U12
// (5) A22 := A22 - D22
//
//    start_index
// +--+-----+--------+
// |  +-----+--------+
// |  |\ U11|  U12   |
// |  |L11\ |        |
// +  +-----+--------+
// |  |     |        |
// |  |     |        |
// |  | L21 |  A22   |
// |  |     |        |
// +--+-----+--------+
//
#define STRASSEN_MIN_DIM 32
int DDLUdecomp_a22(DDMatrix a, DDMatrix d22, DDMatrix l21, DDMatrix u12, long int start_index, long int min_dim)
{
	long int i, j, k, imax, jmax, itmp, dim, index[4], d22_index[4];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	// d22 := l21 * u12
#ifdef USE_BLOCK
//	mul_ddmatrix_block(d22, l21, u12, min_dim);
	mul_ddmatrix_block(d22, l21, u12, STRASSEN_MIN_DIM);
#elif USE_STRASSEN
//	mul_ddmatrix_strassen(d22, l21, u12, min_dim);
	mul_ddmatrix_strassen(d22, l21, u12, STRASSEN_MIN_DIM);
#elif USE_WINOGRAD
//	mul_ddmatrix_strassen(d22, l21, u12, min_dim);
	mul_ddmatrix_strassen(d22, l21, u12, STRASSEN_MIN_DIM);
#else
	mul_ddmatrix_simple(d22, l21, u12);
#endif

	// a22 := a22 - d22
	index[0] = imax;
	index[1] = dim;
	index[2] = jmax;
	index[3] = dim;
	d22_index[0] = 0;
	d22_index[1] = d22->row_dim;
	d22_index[2] = 0;
	d22_index[3] = d22->col_dim;

	sub_ddmatrix_partial(a, index, a, index, d22, d22_index);

	return 0;
}

#ifdef _OPENMP
int DDLUdecomp_a22_omp(DDMatrix a, DDMatrix d22, DDMatrix l21, DDMatrix u12, long int start_index, long int min_dim)
{
	long int i, j, k, imax, jmax, itmp, dim, index[4], d22_index[4];

	dim = a->col_dim;

	imax = start_index + min_dim;
	if(imax > dim) imax = dim;

	jmax = imax;

	// d22 := l21 * u12
#ifdef USE_BLOCK
//	mul_ddmatrix_block(d22, l21, u12, min_dim);
	_bncomp_mul_ddmatrix_block(d22, l21, u12, STRASSEN_MIN_DIM);
//	_bncomp_mul_ddmatrix_block_old(d22, l21, u12, STRASSEN_MIN_DIM);
#elif USE_STRASSEN
//	mul_ddmatrix_strassen(d22, l21, u12, min_dim);
	_bncomp_mul_ddmatrix_strassen(d22, l21, u12, STRASSEN_MIN_DIM);
	//print_normf_ddmatrix("||d22||_F = ", d22);
	//print_normf_ddmatrix("||l21||_F = ", l21);
	//print_normf_ddmatrix("||u12||_F = ", u12);
#elif USE_WINOGRAD
//	mul_ddmatrix_strassen(d22, l21, u12, min_dim);
	_bncomp_mul_ddmatrix_strassen(d22, l21, u12, STRASSEN_MIN_DIM);
#else
	_bncomp_mul_ddmatrix_simple(d22, l21, u12);
#endif

	// a22 := a22 - d22
	index[0] = imax;
	index[1] = dim;
	index[2] = jmax;
	index[3] = dim;
	d22_index[0] = 0;
	d22_index[1] = d22->row_dim;
	d22_index[2] = 0;
	d22_index[3] = d22->col_dim;

	//sub_ddmatrix_partial(a, index, a, index, d22, d22_index);
	_bncomp_sub_ddmatrix_partial(a, index, a, index, d22, d22_index);

	return 0;
}
#endif // _OPENMP

/************************************************************/
/*                                                          */
/*           LU Decomposition for Square Dense Matrix       */
/*                                 (Quadraple Precision)    */
/*                                                          */
/*                 ver. 0.0 2015-02-25 (Wed) Tomonori Kouya */
/*                                                          */
/************************************************************/
int DDLUdecomp_strassen(DDMatrix a, long int min_dim)
/************************************************************/
/*                                                          */
/* entries                                                  */
/*       DDMatrix a: Matrix (given by user)                 */
/*                   a[i * dim + j] ... (i,j)-entry of A    */
/*                                                          */
/* returns                                                  */
/*       a[]: LU decomposed matrix                          */
/*                                                          */
/************************************************************/
{
	long int i, row_dim, col_dim, dim;
	DDMatrix l21, u12, d22;

	dim = a->col_dim;

	// dim <= min_dim
	if(dim <= min_dim)
	{
		DDLUdecomp(a);
		return 0;
	}

	// dim > min_dim
	for(i = 0; i < dim; i += min_dim)
	{
		// Initialize
		row_dim = dim - (i + min_dim);
		if(row_dim <= 0) 
		{
			// (1) L11 * U11 = A11
			if((dim - i) > 0)
				DDLUdecomp_square(a, i, dim - i);

			break;
		}

		col_dim = row_dim;

		//printf("%2ld : (row_dim, col_dim, min_dim) = (%ld, %ld, %ld)\n", i, row_dim, col_dim, min_dim);

		// (1) L11 * U11 = A11
		DDLUdecomp_square(a, i, min_dim);

		//printf("i = %ld\n", i);
		//print_ddmatrix(a);

		l21 = init_ddmatrix(row_dim, min_dim);
		u12 = init_ddmatrix(min_dim, col_dim);
		d22 = init_ddmatrix(row_dim, col_dim);

		// (2) Solve L21 * U11 = A21
		DDLUdecomp_l21(l21, a, i, min_dim);
		//print_ddmatrix(a);
		//printf("L21:\n");
		//print_ddmatrix(l21);

		// (3) Solve L11 * U12 = A12
		DDLUdecomp_u12(u12, a, i, min_dim);
		//print_ddmatrix(a);
		//printf("U12:\n");
		//print_ddmatrix(u12);

		//printf("A:\n");
		//print_ddmatrix(a);

		// (4) D22 := L21 * U12
		// (5) A22 := A22 - D22
		DDLUdecomp_a22(a, d22, l21, u12, i, min_dim);
		//printf("D22:\n");
		//print_ddmatrix(d22);
		//print_ddmatrix(a);

		// clear
		free_ddmatrix(l21);
		free_ddmatrix(u12);
		free_ddmatrix(d22);

	}

	return 0;
}

#ifdef _OPENMP
/************************************************************/
/*                                                          */
/*           LU Decomposition for Square Dense Matrix       */
/*                                  (dd_real)               */
/*                                                          */
/*                 ver. 0.0 2015-07-07 (Tue) Tomonori Kouya */
/*                                                          */
/************************************************************/
int DDLUdecomp_omp(DDMatrix a)
/************************************************************/
/*                                                          */
/* entries                                                  */
/*        DDMatrix a: Matrix (given by user)                */
/*                   a[i * dim + j] ... (i,j)-entry of A    */
/*                                                          */
/* returns                                                  */
/*       a[]: LU decomposed matrix                          */
/*                                                          */
/************************************************************/
{
	long int i, j, k, imax, jmax, itmp, dim;
	double tmp[128][DDSIZE], axii[DDSIZE];
	int thread_index;

	dim = a->col_dim;
	set0_dd(axii);

	#pragma omp parallel private(thread_index)
	{
		thread_index = omp_get_thread_num();
		set0_dd(tmp[thread_index]);
	}

	for(i = 0; i < dim; i++)
	{
		rdd_abs(axii, get_ddmatrix_ij(a, i, i));

		if(rdd_cmp_ui(axii, 0UL) == 0)
		{
			fprintf(stderr, "%ld : Error! (DDLUdecomp_omp)!\n", i);
			return -1;
		}

		#pragma omp parallel for private(thread_index)
		for(j = (i + 1); j < dim; j++)
		{
			thread_index = omp_get_thread_num();

			rdd_div(tmp[thread_index], get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, i));
			set_ddmatrix_ij(a, j, i, tmp[thread_index]);
		}

		#pragma omp parallel for private(thread_index, k)
		for(j = (i + 1); j < dim; j++)
		{
			thread_index = omp_get_thread_num();

			for(k = (i + 1); k < dim; k++)
			{
				rdd_mul(tmp[thread_index], get_ddmatrix_ij(a, j, i), get_ddmatrix_ij(a, i, k));
				rdd_sub(tmp[thread_index], get_ddmatrix_ij(a, j, k), tmp[thread_index]);
				set_ddmatrix_ij(a, j, k, tmp[thread_index]);
			}
		}
	}

	return 0;
}
#endif // _OPENMP


#ifdef _OPENMP
/************************************************************/
/*                                                          */
/*           LU Decomposition for Square Dense Matrix       */
/*                                 (Quadraple Precision)    */
/*                                                          */
/*                 ver. 0.0 2015-02-25 (Wed) Tomonori Kouya */
/*                                                          */
/************************************************************/
int DDLUdecomp_strassen_omp(DDMatrix a, long int min_dim)
/************************************************************/
/*                                                          */
/* entries                                                  */
/*       DDMatrix a: Matrix (given by user)                 */
/*                   a[i * dim + j] ... (i,j)-entry of A    */
/*                                                          */
/* returns                                                  */
/*       a[]: LU decomposed matrix                          */
/*                                                          */
/************************************************************/
{
	long int i, row_dim, col_dim, dim;
	DDMatrix l21, u12, d22;

	dim = a->col_dim;

	// dim <= min_dim
	if(dim <= min_dim)
	{
		DDLUdecomp_omp(a);
		return 0;
	}

	// dim > min_dim
	for(i = 0; i < dim; i += min_dim)
	{
		// Initialize
		row_dim = dim - (i + min_dim);
		if(row_dim <= 0) 
		{
			// (1) L11 * U11 = A11
			if((dim - i) > 0)
				DDLUdecomp_square_omp(a, i, dim - i);

			break;
		}

		col_dim = row_dim;

		//printf("%2ld : (row_dim, col_dim, min_dim) = (%ld, %ld, %ld)\n", i, row_dim, col_dim, min_dim);

		// (1) L11 * U11 = A11
		DDLUdecomp_square_omp(a, i, min_dim);
		//DDLUdecomp_square(a, i, min_dim);

		//printf("i = %ld\n", i);
		//print_ddmatrix(a);

		l21 = init_ddmatrix(row_dim, min_dim);
		u12 = init_ddmatrix(min_dim, col_dim);
		d22 = init_ddmatrix(row_dim, col_dim);

		// (2) Solve L21 * U11 = A21
		DDLUdecomp_l21_omp(l21, a, i, min_dim);
		//DDLUdecomp_l21(l21, a, i, min_dim);
		//print_ddmatrix(a);
		//printf("L21:\n");
		//print_ddmatrix(l21);

		// (3) Solve L11 * U12 = A12
		DDLUdecomp_u12_omp(u12, a, i, min_dim);
		//DDLUdecomp_u12(u12, a, i, min_dim);
		//print_ddmatrix(a);
		//printf("U12:\n");
		//print_ddmatrix(u12);

		//printf("A:\n");
		//print_ddmatrix(a);

		// (4) D22 := L21 * U12
		// (5) A22 := A22 - D22
		DDLUdecomp_a22_omp(a, d22, l21, u12, i, min_dim);
		//DDLUdecomp_a22(a, d22, l21, u12, i, min_dim);
		//printf("D22:\n");
		//print_ddmatrix(d22);
		//print_ddmatrix(a);

		// clear
		free_ddmatrix(l21);
		free_ddmatrix(u12);
		free_ddmatrix(d22);

	}

	return 0;
}
#endif // _OPENMP

// n!
#ifdef __cplusplus
void ddfactorial(dd_real *ret, long int n)
{
	rdd_set_d(*ret, 1.0);

	if(n > 0)
	{
		do
		{
			rdd_mul_d(*ret, *ret, (double)n);
		} while(n-- > 1);
	}

	return;
}
#else
void ddfactorial(double ret[DDSIZE], long int n)
{
	rdd_set_d(ret, 1.0);

	if(n > 0)
	{
		do
		{
			rdd_mul_d(ret, ret, (double)n);
		} while(n-- > 1);
	}

	return;
}
#endif // __cplusplus

// Pascal Matrix
void pascal_ddmatrix(DDMatrix ret, long int dim)
{
	long int i, j;
	static double element[DDSIZE], ifac[DDSIZE], jfac[DDSIZE], ipjfac[DDSIZE], tmp[DDSIZE];

	for(i = 0; i < ret->row_dim; i++)
	{
		for(j = 0; j < ret->col_dim; j++)
		{
			//element = dfactorial(i + j) / (dfactorial(i) * dfactorial(j));
			ddfactorial(ifac, i);
			ddfactorial(jfac, j);
			rdd_mul(tmp, ifac, jfac);
			ddfactorial(ipjfac, i + j);
			rdd_mul(element, tmp, ipjfac);
			set_ddmatrix_ij(ret, i, j, element);
		}
	}
}

// I - randmatrix
void im_rand_ddmatrix(DDMatrix ret, unsigned long seed)
{
	long int i, j;
	double element[DDSIZE];

	set0_dd(element);

	// set seed
	srand(seed);

	// element := (-1)^rand() * rand() / RAND_MAX;
	for(i = 0; i < ret->row_dim; i++)
	{
		for(j = 0; j < ret->col_dim; j++)
		{
			//printf("%ld == %ld\n", i, j);
		#ifdef __cplusplus
			element = (double)rand();
			element /= (double)RAND_MAX;
			if((rand() % 2) != 0)
				element = -element;
		#else
			element[0] = (double)rand();
			element[1] = 0.0;
			rdd_div_d(element, element, (double)RAND_MAX);
			if((rand() % 2) != 0)
				rdd_neg(element, element);
		#endif

			set_ddmatrix_ij(ret, i, j, element);
		}

		//printf("%ld == %ld\n", i, i);
		// element[i][i] := 1 - element[i][i];
		#ifdef __cplusplus
			element = 1.0 - get_ddmatrix_ij(ret, i, i);
		#else
			rdd_ui_div(element, 1UL, get_ddmatrix_ij(ret, i, i));
		#endif
		set_ddmatrix_ij(ret, i, i, element);
	}
}

void get_ddproblem(DDMatrix a, DDVector b, DDVector ans)
{
	long int i, j, k;
	double tmp;

	/* Lotkin Matrix */
/*	for(i = 0; i < a->col_dim; i++)
		set_ddmatrix_ij(a, 0, i, 1.0);
	for(i = 1; i < a->row_dim; i++)
	{
		for(j = 0; j < a->col_dim; j++)
			set_ddmatrix_ij(a, i, j, 1.0 / (i + j + 1));
	}
*/
//	frank_ddmatrix(a, a->row_dim);
	im_rand_ddmatrix(a, a->row_dim);

	/* Answer */
	for(i = 0; i < ans->dim; i++)
		set_ddvector_i_d(ans, i, (double)i);

	/* Make constant vector */
	mul_ddmatrix_ddvec(b, a, ans);
}


//#define DIM 128
//#define DIM 128
//#define DIM 1024

#include "get_secv.h"

int main(int argc, char *argv[])
{
	int num_threads;
	long int dim, block_size, min_dim;
	double stime, etime[6];
	double relerr[3][DDSIZE];
	DDMatrix da;
	DDVector db, dx, dans;

	long int ret_f, ret_d, ret_mpf;
	long int *row_ch, *col_ch;
	long int i, j;

/* Double-double */
	if(argc <= 1)
	{
	#ifndef _OPENMP
		fprintf(stderr, "Usage: %s [dim]\n", argv[0]);
	#else // _OPENMP
		fprintf(stderr, "Usage: %s [dim] [#threads]\n", argv[0]);
	#endif // _OPENMP
		return 0;
	}
	dim = atol(argv[1]);
	if(dim <= 0)
		return 0;

#ifdef _OPENMP
	num_threads = 1;
	if(argc >= 3)
	{
		num_threads = atoi(argv[2]);
		if(num_threads < 1)
			num_threads = 1;
	}

//	omp_set_num_threads(num_threads);
//	printf("#Threads: %d\n", omp_get_num_threads());
	set_bncomp_num_threads(num_threads);
#endif // _OPENMP

	// Initialize QD library
	fpu_fix_start(NULL);

	/* initialize */
	row_ch = (long int *)calloc(sizeof(long int), dim);
	col_ch = (long int *)calloc(sizeof(long int), dim);
	da = init_ddmatrix(dim, dim);
	db = init_ddvector(dim);
	dx = init_ddvector(dim);
	dans = init_ddvector(dim);

	get_ddproblem(da, db, dans);
	stime = get_real_secv();
#ifdef _OPENMP
	ret_d = DDLUdecomp_omp(da);
	//ret_d = DDLUdecomp(da);
#else // _OPENMP
	ret_d = DDLUdecomp(da);
#endif // _OPENMP
	etime[1] = get_real_secv() - stime;
	printf("normalLU: %f\n", etime[1]);
	//print_ddmatrix(da);
	
	ret_d = SolveDDLS(dx, da, db);
	// ret_d = SolveDLSP(dx, da, db, row_ch);
	// ret_d = SolveDLSC(dx, da, db, row_ch, col_ch);

	relerr_element_ddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	printf("relerr(max, min, ||relerr||): ");
	rdd_out_str(relerr[0]); printf(", ");
	rdd_out_str(relerr[1]); printf(", ");
	rdd_out_str(relerr[2]); printf("\n");

	min_dim = STRASSEN_MIN_DIM;
	etime[5] = 0.0;
//	for(block_size = min_dim; block_size <= min_dim * 4; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 10; block_size += min_dim)
	for(block_size = min_dim; block_size <= min_dim * 15; block_size += min_dim)
	{
		/* get problem */
		get_ddproblem(da, db, dans);

	//	print_ddmatrix(da);

		/* run DLUdecomp & SolveDLS */
		stime = get_real_secv();
#ifdef _OPENMP
		ret_d = DDLUdecomp_strassen_omp(da, block_size);
#else // _OPENMP
		ret_d = DDLUdecomp_strassen(da, block_size);
#endif // _OPENMP
		etime[5] = get_real_secv() - stime;

		ret_d = SolveDDLS(dx, da, db);

	#ifdef USE_BLOCK 
			printf("DD blockLU(%ld, %ld, %ld): %f\n", dim, (long int)106, block_size, etime[5]);
	#elif USE_STRASSEN
			printf("DD strassenLU(%ld, %ld, %ld): %f\n", dim, (long int)106, block_size, etime[5]);
	#elif USE_WINOGRAD
			printf("DD winogradLU(%ld, %ld, %ld): %f\n", dim, (long int)106, block_size, etime[5]);
	#endif
		//printf("  i    row_ch[i]    col_ch[i]\n");
		//for(i = 0; i < dim; i++)
		//	printf("%5ld %25.17e %25.17e\n", i, rdd_get_d(get_ddvector_i(dx, i)), rdd_get_d(get_ddvector_i(dans, i)));

		relerr_element_ddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
		printf("relerr(max, min, ||relerr||): ");
		rdd_out_str(relerr[0]); printf(", ");
		rdd_out_str(relerr[1]); printf(", ");
		rdd_out_str(relerr[2]); printf("\n");
	}

	/* end */
	free_ddmatrix(da);
	free_ddvector(db);
	free_ddvector(dx);
	free_ddvector(dans);
	free(row_ch);
	free(col_ch);

	/* print itimes */
	return 0;

}

