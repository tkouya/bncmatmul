/********************************************************************************/
/* lu_bench_td.c: Triple Precision LU decomposition with Strassen MM            */
/*                                                                              */
/* Copyright (C) 2020 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/* stdio.h */
#ifndef _STDIO_H
#include <stdio.h>
#endif

/* math.h */
#ifndef _MATH_H
#include <math.h>
#endif

//#include "bnc.h"

#include "tdlinear.h"

#include "matmul_strassen.h"
#include "bncomp.h"

void get_tdproblem(TDMatrix a, TDVector b, TDVector ans)
{
	long int i, j, k;
	double tmp;

	/* Lotkin Matrix */
/*	for(i = 0; i < a->col_dim; i++)
		set_tdmatrix_ij(a, 0, i, 1.0);
	for(i = 1; i < a->row_dim; i++)
	{
		for(j = 0; j < a->col_dim; j++)
			set_tdmatrix_ij(a, i, j, 1.0 / (i + j + 1));
	}
*/
//	frank_tdmatrix(a, a->row_dim);
	im_rand_tdmatrix(a, a->row_dim);

	/* Answer */
	for(i = 0; i < ans->dim; i++)
		set_tdvector_i_d(ans, i, (double)i);

	/* Make constant vector */
	mul_tdmatrix_tdvec(b, a, ans);
}

//#define DIM 128
//#define DIM 128
//#define DIM 1024

#include "get_secv.h"

int main(int argc, char *argv[])
{
	int num_threads;
	long int dim, block_size, min_dim;
	double stime, etime[6];
#ifdef __cplusplus
	td_real relerr[3];
#else // __cplusplus
	double relerr[3][TDSIZE];
#endif // __cplusplus
	TDMatrix da;
	TDVector db, dx, dans;

	long int ret_f, ret_d, ret_mpf;
	long int *row_ch, *col_ch;
	long int i, j;
	char fname_A[256], fname_true_x[256], fname_vec_b[256];

/* Double-double */
	if(argc <= 1)
	{
		fprintf(stderr, "Usage: %s [dim]\n", argv[0]);
		return 0;
	}
	dim = atol(argv[1]);
	if(dim <= 0)
		return 0;

#ifdef _OPENMP
	num_threads = 1;
	if(argc >= 3)
	{
		num_threads = atoi(argv[2]);
		if(num_threads < 1)
			num_threads = 1;
	}

//	omp_set_num_threads(num_threads);
//	printf("#Threads: %d\n", omp_get_num_threads());
	set_bncomp_num_threads(num_threads);
#endif // _OPENMP

#ifdef USE_OZ
	#ifdef OZ_MAX_NUM_DIV
	int max_num_div = OZ_MAX_NUM_DIV;
	#else
	int max_num_div = 10;
	#endif // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, ");
	printf("max_num_div = %d\n", max_num_div);
#endif // USE_OZ

	// Initialize TD library
	fpu_fix_start(NULL);

	/* initialize */
	row_ch = (long int *)calloc(sizeof(long int), dim);
	col_ch = (long int *)calloc(sizeof(long int), dim);
	da = init_tdmatrix(dim, dim);
	db = init_tdvector(dim);
	dx = init_tdvector(dim);
	dans = init_tdvector(dim);

	sprintf(fname_A, "../python/mat_a_%ld_%ld_b256.txt", dim, dim);
	sprintf(fname_true_x, "../python/vec_true_x_%ld_b256.txt", dim);
	sprintf(fname_vec_b, "../python/vec_b_%ld_b256.txt", dim);	

	//get_tdproblem(da, db, dans);
	read_test_linear_eq_td(da, dans, db, dim, fname_A, fname_true_x, fname_vec_b);

	stime = get_real_secv();
#ifdef _OPENMP
	//ret_d = TDLUdecomp_omp(da);
	ret_d = TDLUdecompPM_omp(da, row_ch);
	etime[1] = get_real_secv() - stime;
	printf("normalLU: %f\n", etime[1]);
	//print_tdmatrix(da);
	
	ret_d = SolveTDLSPM(dx, da, db, row_ch);
#else // _OPENMP
	//ret_d = TDLUdecomp(da);
	ret_d = TDLUdecompPM(da, row_ch);
	//ret_d = TDLUdecompP(da, row_ch);
	etime[1] = get_real_secv() - stime;
	printf("normalLU: %f\n", etime[1]);
	//print_tdmatrix(da);
	
	//ret_d = SolveTDLS(dx, da, db);
	//ret_d = SolveTDLSP(dx, da, db, row_ch);
	// ret_d = SolveTDLSC(dx, da, db, row_ch, col_ch);
	ret_d = SolveTDLSPM(dx, da, db, row_ch);
#endif // _OPENMP
	/*for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		rtd_out_str(get_tdvector_i(dx, i));
		printf(" ");
		rtd_out_str(get_tdvector_i(dans, i));
		printf("\n");
	}
	*/

#ifdef __cplusplus
	relerr_element_tdvector(&relerr[0], &relerr[1], &relerr[2], dx, dans, 0);
//	relerr_element_tdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
#else // __cplusplus
	relerr_element_tdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
#endif // __cplusplus

	//printf("relerr(max, min, ||relerr||): ");
	//rtd_out_str(relerr[0]); printf(", ");
	//rtd_out_str(relerr[1]); printf(", ");
	//rtd_out_str(relerr[2]); printf("\n");
	printf("relerr(max, min, ||relerr||): %10.3e, %10.3e, %10.3e\n", relerr[0][0], relerr[1][0], relerr[2][0]);

	//return 0;

	min_dim = STRASSEN_MIN_DIM;
	etime[5] = 0.0;
//	for(block_size = min_dim; block_size <= min_dim * 4; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 10; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 15; block_size += min_dim)
	for(block_size = min_dim; block_size < dim; block_size += min_dim)
	{
		/* get problem */
		//get_tdproblem(da, db, dans);
		read_test_linear_eq_td(da, dans, db, dim, fname_A, fname_true_x, fname_vec_b);

	//	print_tdmatrix(da);

		/* run DLUdecomp & SolveDLS */
		stime = get_real_secv();
#ifdef _OPENMP
		//ret_d = TDLUdecomp_strassen_omp(da, block_size);
		ret_d = TDLUdecomp_strassenPM_omp(da, row_ch, block_size);
#else // _OPENMP
		//ret_d = TDLUdecomp_strassen(da, block_size);
		#ifdef USE_OZ
		ret_d = TDLUdecomp_ozPM(da, row_ch, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		ret_d = TDLUdecomp_strassenPM(da, row_ch, block_size);
		#endif // USE_OZ
#endif // _OPENMP
		etime[5] = get_real_secv() - stime;

		//ret_d = SolveTDLS(dx, da, db);
		ret_d = SolveTDLSPM(dx, da, db, row_ch);

	#ifdef USE_BLOCK 
			printf("TD blockLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)159, block_size, etime[5]);
	#elif USE_STRASSEN
			printf("TD strassenLU(%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)159, block_size, etime[5]);
	#elif USE_WINOGRAD
			printf("TD winogradLU(%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)159, block_size, etime[5]);
	#elif USE_OZ
			printf("TD ozakiLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)159, block_size, etime[5]);
	#endif
		//printf("  i    row_ch[i]    col_ch[i]\n");
		//for(i = 0; i < dim; i++)
		//	printf("%5ld %25.17e %25.17e\n", i, rtd_get_d(get_tdvector_i(dx, i)), rtd_get_d(get_tdvector_i(dans, i)));

#ifdef __cplusplus
		relerr_element_tdvector(&relerr[0], &relerr[1], &relerr[2], dx, dans, 0);
//		relerr_element_tdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
#else // __cplusplus
		relerr_element_tdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
#endif // __cplusplus
		//printf("relerr(max, min, ||relerr||): ");
		//rtd_out_str(relerr[0]); printf(", ");
		//rtd_out_str(relerr[1]); printf(", ");
		//rtd_out_str(relerr[2]); printf("\n");
		printf("%9.2e, %9.2e, %9.2e\n", relerr[0][0], relerr[1][0], relerr[2][0]);
	}

	/* end */
	free_tdmatrix(da);
	free_tdvector(db);
	free_tdvector(dx);
	free_tdvector(dans);
	free(row_ch);
	free(col_ch);

	/* print itimes */
	return 0;

}

