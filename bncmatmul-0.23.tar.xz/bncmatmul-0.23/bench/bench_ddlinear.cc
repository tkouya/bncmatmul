/********************************************************************************/
/* bench_ddlinear.cc:                                                           */
/* Copyright (C) 2016 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include "ddlinear.h"

// benchmark_mpfmatmul
// ret_c(row_dim, col_dim) := ret_a(row_dim, mid_dim) * ret_b(mid_dim, col_dim)
double benchmark_mpfmatmul(MPFMatrix ret_c, MPFMatrix ret_a, MPFMatrix ret_b, unsigned long prec)
{
	long int i, j, row_dim, mid_dim, col_dim;
	double stime, etime;
	mpf_t mpftmp, mpfval;

	// MPFMatrix
	mpf_init2(mpftmp, prec);
	mpf_init2(mpfval, prec);

//	ret_a = init2_mpfmatrix(row_dim, mid_dim, prec);
//	ret_b = init2_mpfmatrix(mid_dim, col_dim, prec);
//	ret_c = init2_mpfmatrix(row_dim, col_dim, prec);

	row_dim = ret_c->row_dim;
	col_dim = ret_c->col_dim;
	mid_dim = (ret_a->col_dim < ret_b->row_dim) ? ret_a->col_dim : ret_b->row_dim;

	// set ret_a
	for(i = 0; i < row_dim; i++)
	{
		for(j = 0; j < mid_dim; j++)
		{
			mpf_set_ui(mpfval, (unsigned long)(i + j + 1));
			mpf_sqrt(mpfval, mpfval);
			set_mpfmatrix_ij(ret_a, i, j, mpfval);
		}
	}

	// set ret_b
	for(i = 0; i < mid_dim; i++)
	{
		for(j = 0; j < col_dim; j++)
		{
			mpf_set_ui(mpfval, (unsigned long)((row_dim - i) + (col_dim - j)));
			mpf_sqrt(mpfval, mpfval);
			set_mpfmatrix_ij(ret_b, i, j, mpfval);
		}
	}
//	print_mpfmatrix(ret_a);
//	print_mpfmatrix(ret_b);

	stime = get_secv();
	mul_mpfmatrix(ret_c, ret_a, ret_b);
	etime = get_secv() - stime;

	mpf_clear(mpfval);
	mpf_clear(mpftmp);

	return etime;

//	free_mpfmatrix(ret_a);
//	free_mpfmatrix(ret_b);
//	free_mpfmatrix(ret_c);
}

#ifdef __cplusplus
using namespace std;
#endif // __cplusplus

int main(int argc, char *argv[])
{
	int i, j, dim;
	double stime, etime[4];
#ifdef __cplusplus
	dd_real ddval, ddtmp;
	qd_real qdval, qdtmp;
#else // __cplusplus
	double tmp[QDSIZE], val[QDSIZE];
#endif // __cplusplus
	DDVector ddvec;
	QDVector qdvec;
	DDMatrix ddmat_c, ddmat_a, ddmat_b;
	QDMatrix qdmat_c, qdmat_a, qdmat_b;
	int ddprec = 106, qdprec = 212;
	mpf_t mpfval;
	MPFMatrix mpfmat_c, mpfmat_a, mpfmat_b;

	// check argc
	if(argc <= 1)
	{
		printf("Usage: %s [dim]\n", argv[0]);
		return 0;
	}

	dim = atoi(argv[1]);
	if(dim < 0)
		dim = 128;

	for(dim = 128; dim <= 8192; dim += 128)
	{

		// MPFMatrix (ddprec)
		mpf_init2(mpfval, ddprec);
		mpfmat_a = init2_mpfmatrix(dim, dim, ddprec);
		mpfmat_b = init2_mpfmatrix(dim, dim, ddprec);
		mpfmat_c = init2_mpfmatrix(dim, dim, ddprec);

		printf("Starting matmul_mpfmatrix(%d, %d) in %d prec\n", dim, dim, ddprec);

		etime[0] = benchmark_mpfmatmul(mpfmat_c, mpfmat_a, mpfmat_b, ddprec);

		printf("End matmul_mpfmatrix(%d, %d) in %d prec\n", dim, dim, ddprec);

	//	print_mpfmatrix(ret_c);
		normf_mpfmatrix(mpfval, mpfmat_c);
		printf("MPF: ||C||_F = ");
		mpf_out_str(stdout, 10, 0, mpfval);
		printf("\n");

		free_mpfmatrix(mpfmat_a);
		free_mpfmatrix(mpfmat_b);
		free_mpfmatrix(mpfmat_c);
		mpf_clear(mpfval);

		// DDmatrix
		// Initialize QD library
		fpu_fix_start(NULL);

		ddmat_a = init_ddmatrix(dim, dim);
		ddmat_b = init_ddmatrix(dim, dim);
		ddmat_c = init_ddmatrix(dim, dim);

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
#ifdef __cplusplus
				ddmat_a->element[i * dim + j] = dd_real::sqrt((int)(i + j + 1));
				ddmat_b->element[i * dim + j] = dd_real::sqrt((int)((dim - i) + (dim - j)));
#else // __cplusplus
				c_dd_copy_d((double)(i + j + 1), tmp);
				c_dd_sqrt(tmp, val);
				//SET_DDMATRIX_IJ(ddmat_a, i, j, val);
				set_ddmatrix_ij(ddmat_a, i, j, val);

				c_dd_copy_d((double)((dim - i) + (dim - j)), tmp);
				c_dd_sqrt(tmp, val);
				//SET_DDMATRIX_IJ(ddmat_b, i, j, val);
				set_ddmatrix_ij(ddmat_b, i, j, val);
#endif // __cplusplus
			}
		}
		//print_ddmatrix(ddmat_a);
		//print_ddmatrix(ddmat_b);

		stime = get_secv();
		mul_ddmatrix(ddmat_c, ddmat_a, ddmat_b);
		etime[1] = get_secv() - stime;

		//print_ddmatrix(ddmat_c);
		normf_ddmatrix(&ddval, ddmat_c);
		
		printf(" DD: ||C||_F = ");
#ifdef __cplusplus
		cout << ddval.to_string() << "\n";
#else // __cplusplus
		c_dd_write(val);
#endif // __cplusplus
		free_ddmatrix(ddmat_a);
		free_ddmatrix(ddmat_b);
		free_ddmatrix(ddmat_c);

		// MPFMatrix (qdprec)
		mpf_init2(mpfval, qdprec);
		mpfmat_a = init2_mpfmatrix(dim, dim, qdprec);
		mpfmat_b = init2_mpfmatrix(dim, dim, qdprec);
		mpfmat_c = init2_mpfmatrix(dim, dim, qdprec);

		printf("Starting matmul_mpfmatrix(%d, %d) in %d prec\n", dim, dim, qdprec);

		etime[2] = benchmark_mpfmatmul(mpfmat_c, mpfmat_a, mpfmat_b, qdprec);

		printf("End matmul_mpfmatrix(%d, %d) in %d prec\n", dim, dim, qdprec);

	//	print_mpfmatrix(ret_c);
		normf_mpfmatrix(mpfval, mpfmat_c);
		printf("MPF: ||C||_F = ");
		mpf_out_str(stdout, 10, 0, mpfval);
		printf("\n");

		free_mpfmatrix(mpfmat_a);
		free_mpfmatrix(mpfmat_b);
		free_mpfmatrix(mpfmat_c);
		mpf_clear(mpfval);

		// QDmatrix
		qdmat_a = init_qdmatrix(dim, dim);
		qdmat_b = init_qdmatrix(dim, dim);
		qdmat_c = init_qdmatrix(dim, dim);

		//return 0;

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
#ifdef __cplusplus
				qdmat_a->element[i * dim + j] = (qd_real)(i + j + 1);
				qdmat_a->element[i * dim + j] = (qd_real)sqrt(qdmat_a->element[i * dim + j]);
				qdmat_b->element[i * dim + j] = (qd_real)((dim - i) + (dim - j));
				qdmat_b->element[i * dim + j] = (qd_real)sqrt(qdmat_b->element[i * dim + j]);
#else // __cplusplus
				c_qd_copy_d((double)(i + j + 1), tmp);
				c_qd_sqrt(tmp, val);
				//SET_QDMATRIX_IJ(qdmat_a, i, j, val);
				set_qdmatrix_ij(qdmat_a, i, j, val);

				c_qd_copy_d((double)((dim - i) + (dim - j)), tmp);
				c_qd_sqrt(tmp, val);
				//SET_QDMATRIX_IJ(qdmat_b, i, j, val);
				set_qdmatrix_ij(qdmat_b, i, j, val);
#endif // __cplusplus
			}
		}
	//	printf("qdmat_a:\n");
	//	print_qdmatrix(qdmat_a);
	//	printf("qdmat_b:\n");
	//	print_qdmatrix(qdmat_b);

		stime = get_secv();
		mul_qdmatrix(qdmat_c, qdmat_a, qdmat_b);
		etime[3] = get_secv() - stime;

	//	printf("qdmat_c:\n");
	//	print_qdmatrix(qdmat_c);
		normf_qdmatrix(&qdval, qdmat_c);
		printf(" QD: ||C||_F = ");
#ifdef __cplusplus
		cout << qdval.to_string() << "\n";
#else // __cplusplus
		c_qd_write(val);

		mpf_get_qd(val, mpfval);
		printf("qd val = "); rqd_out_str(val);
		mpf_set_qd(mpfval, val);
		printf("qd val = "); mpf_out_str(stdout, 10, 0, mpfval); printf("\n");
#endif // __cplusplus

		free_qdmatrix(qdmat_a);
		free_qdmatrix(qdmat_b);
		free_qdmatrix(qdmat_c);

		printf("%d x %d matmul\n", dim, dim);
		printf("mpfr(%4d): %f s\n", ddprec, etime[0]);
#ifdef __cplusplus
		printf("dd        : %f s\n", etime[1]);
#else  // __cplusplus
		printf("c_dd      : %f s\n", etime[1]);
#endif // __cplusplus
		printf("mpfr(%4d): %f s\n", qdprec, etime[2]);
#ifdef __cplusplus
		printf("qd        : %f s\n", etime[3]);
#else  // __cplusplus
		printf("c_qd      : %f s\n", etime[3]);
#endif // _cplusplus

	}

	return 0;
}
