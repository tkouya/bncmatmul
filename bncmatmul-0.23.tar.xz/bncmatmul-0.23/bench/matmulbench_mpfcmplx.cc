/********************************************************************************/
/* matmulbench_mpfcmplx.c:                                                      */
/* Copyright (C) 2023 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <cstdio>
#include <cstdlib>
#include <cmath>

// mpblas
#ifdef OLD_MBLAS
    #include <mblas_mpfr.h>
#else
	#include <mpblas_mpfr.h>
#endif // USE_MBLAS

#include "matmul_strassen.h"
#include "get_secv.h"
#ifdef USE_OMP
	#include "bncomp.h"
#endif


// row-major, zero index
#define RAW_ZERO_IJ(i, j, row_dim, col_dim)	((i) * (col_dim) + (j))
// column-major, zero index
#define COL_ZERO_IJ(i, j, row_dim, col_dim)	((i) + (j) * (row_dim))

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	#ifdef USE_OMP
		printf("USAGE-> %s precision(in bits) [min_dim] [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s precision(in bits) [min_dim] [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#else
	#ifdef USE_OMP
		printf("USAGE-> %s precision(in bits) [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s precision(in bits) [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#endif
}

#ifdef USE_GMP

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_mpfcmplx(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec, long int min_dim, int max_num_div)
{
	long int dim;
	long int i, j, end_flag = 0;
	long int num_addsub, num_mul;
	double iteration, etime, stime, mflops;
	CMPFMatrix da, db, dc, dc_long;
	mpf_t tmp, relerr[3];
    MPFCmplx ctmp;
#ifdef USE_MBLAS
	//mpcomplex::set_default_prec(prec);
	mpfr_set_default_prec((mp_prec_t)prec);
    mpfr::mpreal::default_prec = (mp_prec_t)prec;
    mpfr::mpcomplex::default_real_prec = (mp_prec_t)prec;
    mpfr::mpcomplex::default_imag_prec = (mp_prec_t)prec;
	mpcomplex *da_m, *db_m, *dc_m;
    mpcomplex cone = mpcomplex(1.0, 0.0), czero = mpcomplex(0.0, 0.0);
#endif // USE_MBLAS
#ifdef USE_OZ
	//int max_num_div; // For Ozaki scheme
	//#ifdef OZ_MAX_NUM_DIV
	//max_num_div = OZ_MAX_NUM_DIV;
	//#else // OZ_MAX_NUM_DIV
	//max_num_div = 10;
	//fprintf(stderr, "Warning: no definition of OZ_MAX_NUM_DIV! -> max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

	mpf_init2(tmp, prec);
	mpf_init2(relerr[0], prec);
	mpf_init2(relerr[1], prec);
	mpf_init2(relerr[2], prec);
    ctmp = init2_mpfcmplx(prec);

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init2_cmpfmatrix(dim, dim, prec);
		db = init2_cmpfmatrix(dim, dim, prec);
		dc = init2_cmpfmatrix(dim, dim, prec);
		dc_long = init2_cmpfmatrix(dim, dim, (unsigned long)(prec + prec / 2));
#ifdef USE_MBLAS
	// mpack
		da_m = new mpcomplex[dim * dim];
		db_m = new mpcomplex[dim * dim];
		dc_m = new mpcomplex[dim * dim];
#endif // USE_MBLAS
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_cmpfmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0)(1 + i));
				mpf_sqrt_ui(tmp, 5UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(i + j + 1));
                set_real_mpfcmplx(ctmp, tmp);
                set_image_mpfcmplx(ctmp, tmp);
				set_cmpfmatrix_ij(da, i, j, ctmp);
				// mpack
#ifdef USE_MBLAS
				da_m[COL_ZERO_IJ(i, j, dim, dim)] = mpcomplex(tmp, tmp);
#endif // USE_MBLAS

//				set_cmpfmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				mpf_sqrt_ui(tmp, 3UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(dim - i));
                set_real_mpfcmplx(ctmp, tmp);
                set_image_mpfcmplx(ctmp, tmp);
				set_cmpfmatrix_ij(db, i, j, ctmp);
				// mpack
#ifdef USE_MBLAS
				db_m[COL_ZERO_IJ(i, j, dim, dim)] = mpcomplex(tmp, tmp);
#endif // USE_MBLAS

				mpf_sqrt_ui(tmp, 2UL);
                set_real_mpfcmplx(ctmp, tmp);
                set_image_mpfcmplx(ctmp, tmp);
				set_cmpfmatrix_ij(dc, i, j, ctmp);
				// mpack
#ifdef USE_MBLAS
				dc_m[COL_ZERO_IJ(i, j, dim, dim)] = mpcomplex(tmp, tmp);
#endif // USE_MBLAS
			}
		}

		iteration = 1.0;
		do{
			//stime = get_secv();
			stime = get_real_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				//_bncomp_reset_num_mul_cmpfmatrix_strassen();
//				mul_cmpfmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_cmpfmatrix_strassen(dc, da, db, min_dim);
//				_bncomp_mul_cmpfmatrix_strassen_nonrec(dc, da, db, min_dim);
				//_bncomp_get_num_mul_cmpfmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				//reset_num_mul_cmpfmatrix_strassen();
//				mul_cmpfmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_cmpfmatrix_strassen(dc, da, db, min_dim);
				//get_num_mul_cmpfmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_STRASSEN_PADDING // USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				//_bncomp_reset_num_mul_cmpfmatrix_strassen();
//				mul_cmpfmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_cmpfmatrix_strassen_odd_padding(dc, da, db, min_dim);
				//_bncomp_get_num_mul_cmpfmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				//reset_num_mul_cmpfmatrix_strassen();
//				mul_cmpfmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_cmpfmatrix_strassen_odd_padding(dc, da, db, min_dim);
				//get_num_mul_cmpfmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_cmpfmatrix_block(dc, da, db, min_dim);
#else // USE_OMP
//			for(i = 0; i < iteration; i++) mul_cmpfmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_cmpfmatrix_block(dc, da, db, min_dim);
#endif // USE_OMP
#elif USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN		
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			for(i = 0; i < iteration; i++) mul_cmpfmatrix_oz(dc, da, max_num_div, max_num_div, db, max_num_div, max_num_div);

#elif USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;

			for(i = 0; i < iteration; i++) Cgemm("n", "n", dim, dim, dim, cone, da_m, dim, db_m, dim, czero, dc_m, dim);

#else // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_cmpfmatrix_simple(dc, da, db);
#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_cmpfmatrix_simple(dc, da, db);
#endif // USE_OMP
#endif // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			//etime = get_secv() - stime;
			etime = get_real_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);
#ifdef USE_MBLAS
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
            {
                set_real_mpfcmplx(ctmp, mpfr_ptr(dc_m[COL_ZERO_IJ(i, j, dim, dim)].real()));
                set_image_mpfcmplx(ctmp, mpfr_ptr(dc_m[COL_ZERO_IJ(i, j, dim, dim)].imag()));

				set_cmpfmatrix_ij(dc, i, j, ctmp);
            }
		}
#endif // USE_MBLAS

		// get relative errors
#ifdef USE_OMP
		_bncomp_mul_cmpfmatrix_strassen(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
#else // USE_OMP
		mul_cmpfmatrix_strassen(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
#endif // USE_OMP
//		mul_cmpfmatrix_simple(dc_long, da, db);
		relerr3_cmpfmatrix(relerr[0], relerr[1], relerr[2], dc, dc_long, 0);

		etime /= iteration / 2;

//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		//printf("[%5ld bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", prec, dim, dim, etime, num_mul, num_addsub);
		printf("[%5ld bits] %5ld x %5ld: %9.5f sec", prec, dim, dim, etime);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[0]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[1]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_cmpfmatrix(da);
		free_cmpfmatrix(db);
		free_cmpfmatrix(dc);
		free_cmpfmatrix(dc_long);

		// mpack
#ifdef USE_MBLAS
		delete[] da_m;
		delete[] db_m;
		delete[] dc_m;
#endif // USE_MBLAS

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}

	}

	mpf_clear(tmp);
	mpf_clear(relerr[0]);
	mpf_clear(relerr[1]);
	mpf_clear(relerr[2]);
    free_mpfcmplx(ctmp);

	return end_flag;
}
#endif // USE_GMP

int main(int argc, char *argv[])
{
	int num_threads = 1, max_num_div = 10;
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 2000;
	unsigned long prec;
	if(argc <= 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
		prec = atol(argv[1]);
		if(prec <= 0)
		{
			printf("Invalid precision in bit! (%ld bits)\n", prec);
			return -1;
		}
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
		if(argc >= 3)
		{
		#ifdef USE_OZ
			max_num_div = atoi(argv[2]);
		#else // USE_OZ
			min_dim = atol(argv[2]);
			if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
			{
				printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				//return -1;
			}
		#endif // USE_OZ
#ifdef USE_OMP
			if(argc >= 4)
			{
				num_threads = atoi(argv[3]);
				if(num_threads < 1)
				{
					printf("num_threads is 1\n");
				}
			}
			if(argc >= 5)
			{
				maxsec = atol(argv[4]);
				if(maxsec < 0)
				{
					printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
					return -1;
				}
			}
#else // USE_OMP
			if(argc >= 4)
			{
				maxsec = atol(argv[3]);
				if(maxsec < 0)
				{
					printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
					return -1;
				}
			}
#endif // USE_OMP
		}
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
#ifdef USE_OMP
		if(argc >= 3)
		{
			num_threads = atoi(argv[2]);
			if(num_threads < 1)
			{
				printf("num_threads is 1\n");
			}
		}
		if(argc >= 4)
		{
			maxsec = atol(argv[3]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	}

	set_bnc_default_prec(prec);
	printf("Maxsec: %ld\n", maxsec);

#ifdef USE_OMP
	set_bncomp_num_threads(num_threads);
	printf("OpenMP #threads = %d\n", omp_get_num_threads());
#endif // USE_OMP

#ifdef USE_OZ
	//#ifdef OZ_MAX_NUM_DIV
	//printf("Ozaki scheme, max_num_div = %d\n", OZ_MAX_NUM_DIV);
	//#else // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

    bnc_print_env_all();
	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

	//min_dim = 2048;

	//for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_mpfcmplx(idim - 1, idim + 1, 1, maxsec, 0, prec, min_dim, max_num_div);

//		end_flag = matmulloop_mpf(idim - 1, idim + 1, 1, maxsec, 0, prec);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_mpfcmplx(idim_half - 1, idim_half + 1, 1, maxsec, 0, prec, min_dim, max_num_div);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_mpf(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, prec, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

