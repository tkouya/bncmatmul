/********************************************************************************/
/* matmulbench_d.c:                                                             */
/* Copyright (C) 2014 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bnc.h"
#include "matmul_strassen.h"

#ifdef USE_IMKL
	#include "mkl.h"
	#include "mkl_cblas.h" // for Intel Math Kernel Library
#endif

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
	printf("USAGE-> %s Cachesize(Kilo bytes) [Maximum seconds]\n", commandname);
}

int matmulloop(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, long int min_dim)
{
	long int dim;
	long int i, j, end_flag;
	double iteration, etime, stime;
	DMatrix da, db, dc, dc_true;
	double max_relerr, min_relerr, norm_relerr;

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init_dmatrix(dim, dim);
		db = init_dmatrix(dim, dim);
		dc = init_dmatrix(dim, dim);
		dc_true = init_dmatrix(dim, dim);

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
				set_dmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
				set_dmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				set_dmatrix_ij(dc, i, j, sqrt(2.0));
			}
		}

		iteration = 1.0;
		do{
			stime = get_secv();
#ifdef USE_IMKL
  #ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++) mul_dmatrix_strassen(dc, da, db, min_dim);
  #elif USE_WINOGRAD
			for(i = 0; i < iteration; i++) mul_dmatrix_strassen(dc, da, db, min_dim);
  #else
			for(i = 0; i < iteration; i++) cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, dim, dim, dim, 1.0, da->element, dim, db->element, dim, 0.0, dc->element, dim);
  #endif // USE_STRASSEN
#else  // USE_IMKL
			for(i = 0; i < iteration; i++) mul_dmatrix(dc, da, db);
#endif // USE_IMKL
			etime = get_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);

		etime /= iteration / 2;

#ifdef USE_IMKL
		cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, dim, dim, dim, 1.0, da->element, dim, db->element, dim, 0.0, dc_true->element, dim);
#else
		mul_dmatrix(dc_true, da, db);
#endif // USE_STRASSEN
		//mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;

		relerr3_dmatrix(&max_relerr, &min_relerr, &norm_relerr, dc, dc_true, 0);

		printf("%5ld x %5ld: %9.5f sec (%8.5f micro-sec/mul) %10.2e %10.2e %10.2e", dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, max_relerr, min_relerr, norm_relerr);
		//printf("%5d x %5d: %9.5f sec %8.5f GFlop/s", dim, dim, etime, mflops);
		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_dmatrix(da);
		free_dmatrix(db);
		free_dmatrix(dc);
		free_dmatrix(dc_true);

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}
	}

	return end_flag;
}

int main(int argc, char *argv[])
{
	long int dim, idim, idim_half, opt_dim, end_flag;
	long int cachesize = 128, maxsec = 600;
	long int min_dim = 32, max_dim = 32768;

	if(argc <= 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
		min_dim = atol(argv[1]);
		//cachesize = atol(argv[1]);
		//cachesize *= 1024;
		//if(cachesize < 0)
		//{
		//	printf("Invalid cache memory size! (%ld kilo bytes)\n", cachesize);
		//	return -1;
		//}
		/* if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		} */
	}

	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

//	opt_dim = (long int)floor(sqrt((double)cachesize / 8.0 / 2));
	opt_dim = (long int)floor((-1.0 + sqrt(4 * (double)cachesize / 8.0)) / 2.0);
	printf("Cache size                 : %ld Kilo bytes\n", cachesize / 1024);
	printf("Maximum limit of dimension : %ld x %ld\n\n", opt_dim, opt_dim);

//	for(idim = 32; idim <= 16384; idim *= 2)
	for(idim = min_dim; idim <= max_dim; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop(idim - 1, idim + 1, 1, maxsec, 0, min_dim);

		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop(idim_half - 1, idim_half + 1, 1, maxsec, 0, min_dim);

	//	if((idim <= opt_dim) && (opt_dim <= idim * 2))
	//		end_flag = matmulloop(opt_dim - 5, opt_dim + 5, 1, maxsec, 1);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

