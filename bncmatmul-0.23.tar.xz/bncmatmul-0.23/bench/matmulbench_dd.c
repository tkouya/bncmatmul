/********************************************************************************/
/* matmulbench_dd.c:                                                            */
/* Copyright (C) 2015 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//#include "bnc.h"
#include "matmul_strassen.h"
#include "get_secv.h"

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	printf("USAGE-> %s [min_dim] [Maximum seconds]\n", commandname);
#else
	printf("USAGE-> %s [Maximum seconds]\n", commandname);
#endif
}

#ifdef USE_DDLINEAR

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_dd(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, long int min_dim)
{
	long int dim;
	long int i, j, end_flag;
	long int num_addsub, num_mul;
	double iteration, etime, stime, mflops;
	DDMatrix da, db, dc;
	//QDMatrix dc_long;
	DDMatrix dc_long;
	double tmp[DDSIZE], relerr[3][DDSIZE];

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init_ddmatrix(dim, dim);
		db = init_ddmatrix(dim, dim);
		dc = init_ddmatrix(dim, dim);
		//dc_long = init_qdmatrix(dim, dim);
		dc_long = init_ddmatrix(dim, dim);

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_ddmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
				rdd_sqrt_ui(tmp, 5UL);
				rdd_mul_ui(tmp, tmp, (unsigned long)(i + j + 1));
				set_ddmatrix_ij(da, i, j, tmp);

//				set_ddmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				rdd_sqrt_ui(tmp, 3UL);
				rdd_mul_ui(tmp, tmp, (unsigned long)(dim - i));
				set_ddmatrix_ij(db, i, j, tmp);

				rdd_sqrt_ui(tmp, 2UL);
				set_ddmatrix_ij(dc, i, j, tmp);
			}
		}

		iteration = 1.0;
		do{
			stime = get_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
				reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_ddmatrix_strassen(dc, da, db, min_dim);
				get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
			}

#elif USE_STRASSEN_PADDING
			for(i = 0; i < iteration; i++)
			{
				reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_ddmatrix_strassen_odd_padding(dc, da, db, min_dim);
				get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
			}

#elif USE_BLOCK
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
//			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, min_dim);
#else
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			for(i = 0; i < iteration; i++) mul_ddmatrix_simple(dc, da, db);
#endif
			etime = get_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);

		// get relative errors
//		mul_qdmatrix(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
		mul_ddmatrix_simple(dc_long, da, db);
		relerr3_ddmatrix(relerr[0], relerr[1], relerr[2], dc, dc_long, 0);

		etime /= iteration / 2;

//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		printf("[%5d bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", 106, dim, dim, etime, num_mul, num_addsub);
		printf(" "); printf("%10.3e", relerr[0][0]); //rdd_out_str(relerr[0]);
		printf(" "); printf("%10.3e", relerr[1][0]); //rdd_out_str(relerr[1]);
		printf(" "); printf("%10.3e", relerr[2][0]); //rdd_out_str(relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_ddmatrix(da);
		free_ddmatrix(db);
		free_ddmatrix(dc);
		free_ddmatrix(dc_long);

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}
	}

	return end_flag;
}
#endif

int main(int argc, char *argv[])
{
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 600;

	if(argc < 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 1)
	{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
		if(argc >= 2)
		{
			min_dim = atol(argv[1]);
			if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
			{
				printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				//return -1;
			}
			if(argc >= 3)
			{
				maxsec = atol(argv[2]);
				if(maxsec < 0)
				{
					printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
					return -1;
				}
			}
		}
#else // normal multiply
		if(argc >= 2)
		{
			maxsec = atol(argv[1]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#endif
	}

	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

	// Initialize QD library
	fpu_fix_start(NULL);

//	for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_dd(idim - 1, idim + 1, 1, maxsec, 0, min_dim);

//		end_flag = matmulloop_dd(idim - 1, idim + 1, 1, maxsec, 0);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_dd(idim_half - 1, idim_half + 1, 1, maxsec, 0, min_dim);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_dd(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, min_dim);

		//if(end_flag == 1)
		//	break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

