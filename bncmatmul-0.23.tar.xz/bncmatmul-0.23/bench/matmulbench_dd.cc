/********************************************************************************/
/* matmulbench_cdd.cc:                                                          */
/* Copyright (C) 2023 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ccomplex>
#include "qd/qd_real.h"
using namespace std;

// mplapack, mpblas
//#ifdef USE_MBLAS
#ifdef USE_MBLAS
#ifdef OLD_MBLAS
    #include <mblas_dd.h>
    //#include <mlapack_dd.h>
#else // OLD_MBLAS
    #include <mpblas_dd.h>
    //#include <mplapack_dd.h>
#endif // OLD_MBLAS
#endif // USE_MBLAS


//#include "bnc.h"
#include "bncmatmul.h"
//#include "matmul_strassen.h"
#include "get_secv.h"

#ifdef USE_OMP
	#include "bncomp.h"
#endif // USE_OMP

// row-major, zero index
#define ROW_ZERO_IJ(i, j, row_dim, col_dim)	((i) * (col_dim) + (j))
// column-major, zero index
#define COL_ZERO_IJ(i, j, row_dim, col_dim)	((i) + (j) * (row_dim))

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [num_threads] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [num_threads] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#else // USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		printf("USAGE-> %s [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
}

//#ifdef USE_DDLINEAR

// Frobenius norm
void normf_ddmatrix_(double ret[DDSIZE], DDMatrix mat)
{
	long int i;
	long int real_total_dim;
	double tmp[DDSIZE];

	real_total_dim = mat->real_row_dim * mat->real_col_dim;

	double mat1[DDSIZE];

	rdd_set0(ret);
	for(i = 0; i < real_total_dim; i++)
	{
		mat1[0] = mat->element[0][i];
		mat1[1] = mat->element[1][i];

		// tmp := mat1[i]^2
		// ret += tmp
		rdd_mul(tmp, mat1, mat1);
		rdd_add(ret, ret, tmp);
	}
	//printf("ret = %25.17e\n", ret[0]);

	rdd_sqrt(tmp, ret);
	//printf("tmp = %25.17e\n", tmp[0]);
	rdd_set(ret, tmp);
	//printf("ret = %25.17e\n", ret[0]);
}

// initialize ddvector
DDMatrix test_init_ddmatrix(long int row_dim, long int col_dim)
{
	long int row_index, col_index, i;
	long int real_row_dim, real_col_dim, real_total_dim;
	DDMatrix ret = NULL;

	printf("_BNC_D_WIDTH = %ld\n", _BNC_D_WIDTH);
	ret = (DDMatrix)BNC_MALLOC(sizeof(ddmatrix));
	if(ret == NULL)
		return ret;

	// real_dim is the nearest positive multiplier of _BNC_D_WIDTH
	real_row_dim = (long int)ceil((double)(row_dim) / (double)_BNC_D_WIDTH) * _BNC_D_WIDTH;
	real_col_dim = (long int)ceil((double)(col_dim) / (double)_BNC_D_WIDTH) * _BNC_D_WIDTH;
	real_total_dim = real_row_dim * real_col_dim;

	printf("row_dim, real_row_dim, col_dim, real_col_dim = %ld, %ld, %ld, %ld\n", row_dim, real_row_dim, col_dim, real_col_dim);

	//printf("init_ddmatrix(%ld, %ld) %ld calloc\n", row_dim, col_dim, real_total_dim);
	ret->element[0] = (double *)BNC_CALLOC(real_total_dim, sizeof(double));
	if(ret->element[0] == NULL)
	{ 	free(ret);
		return NULL;
	}
	printf("ret->element[0]\n");

	ret->element[1] = (double *)BNC_CALLOC(real_total_dim, sizeof(double));
	if(ret->element[1] == NULL)
	{
		free(ret->element[0]);
		free(ret);
		return NULL;
	}
	printf("ret->element[1]\n");

	//printf("init_ddmatrix(%ld, %ld) calloc\n", row_dim, col_dim);
	/* All 0 */
#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d zero4;

	zero4 = _mm256_setzero_pd();
	for(i = 0; i < real_total_dim; i += _BNC_D_WIDTH)
	{
		_mm256_store_pd(&ret->element[0][i], zero4);
		_mm256_store_pd(&ret->element[1][i], zero4);
	}
#elif defined(__AVX512F__) // __AVX512F__
	__m512d zero8;

	zero8 = _mm512_setzero_pd();
	for(i = 0; i < real_total_dim; i += _BNC_D_WIDTH)
	{
		printf("%ld ", i); fflush(stdout);
		_mm512_store_pd(&(ret->element[0][i]), zero8);
		_mm512_store_pd(&(ret->element[1][i]), zero8);
	}
	printf("set zero8\n");

#elif (defined(__ARM_NEON) || defined(__aarch64__)) && defined(BNC_ENABLE_NEON) // Arm Neon|| defined(__aarch64__)
	float64x2_t z2 = vdupq_n_f64(0.0);

	for(i = 0; i < real_total_dim; i += _BNC_D_WIDTH){
        vst1q_f64(&ret->element[0][i], z2);
        vst1q_f64(&ret->element[1][i], z2);
    }
#else // others
	for(i = 0; i < real_total_dim; i++)
	{
		ret->element[0][i] = 0.0;
		ret->element[1][i] = 0.0;
	}
#endif // __AVX2__

	ret->real_row_dim = real_row_dim;
	ret->real_col_dim = real_col_dim;
	ret->row_dim = row_dim;
	ret->col_dim = col_dim;

	return ret;
}

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_dd(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, long int min_dim, int max_num_div)
{
	long int dim;
	long int i, j, end_flag = 0;
	long int num_addsub, num_mul, iteration;
	double etime, stime, mflops;
	DDMatrix da, db, dc;
	//DDMatrix dc_long;
	DDMatrix dc_long;
	dd_real tmp, relerr[3], one = (dd_real)(1.0), zero = (dd_real)(0.0);
	dd_real *da_m, *db_m, *dc_m;

#ifdef USE_OZ
	//int max_num_div; // For Ozaki scheme
	//#ifdef OZ_MAX_NUM_DIV
	//max_num_div = OZ_MAX_NUM_DIV;
	//#else // OZ_MAX_NUM_DIV
	//max_num_div = 10;
	//fprintf(stderr, "Warning: no definition of OZ_MAX_NUM_DIV! -> max_num_div = %d\n", max_num_div);
	//printf("max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ
	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init_ddmatrix(dim, dim);
		db = init_ddmatrix(dim, dim);
		dc = init_ddmatrix(dim, dim);
		//dc_long = init_ddmatrix(dim, dim);
		dc_long = init_ddmatrix(dim, dim);

	// mpack
		da_m = new dd_real[dim * dim];
		db_m = new dd_real[dim * dim];
		dc_m = new dd_real[dim * dim];

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_ddmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
//				rdd_set_ui(tmp.x, 5UL);
//				rdd_sqrt(tmp.x, tmp.x);
				tmp = sqrt((dd_real)5.0) * (dd_real)(double)(i + j + 1);
					//tmp = sqrt((dd_real)rand()) * (dd_real)(double)(i + j + 1);
				//rdd_sqrt_ui(tmp.x, 5UL);
				//cout << "tmp = " << tmp << endl;
				//rdd_mul_ui(tmp.x, tmp.x, (unsigned long)(i + j + 1));
				set_ddmatrix_ij(da, i, j, tmp.x);
				// mpack
				da_m[COL_ZERO_IJ(i, j, dim, dim)] = tmp;
				//cout << "tmp = " << tmp << endl;
				//printf("tmp_x = %25.17e\n", tmp.x[0]);

//				set_ddmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				//rdd_sqrt_ui(tmp.x, 3UL);
				//rdd_mul_ui(tmp.x, tmp.x, (unsigned long)(dim - i));
				tmp = sqrt((dd_real)3.0) * (dd_real)(double)(dim - i);
				set_ddmatrix_ij(db, i, j, tmp.x);
				// mpack
				db_m[COL_ZERO_IJ(i, j, dim, dim)] = tmp;

				rdd_sqrt_ui(tmp.x, 2UL);
				set_ddmatrix_ij(dc, i, j, tmp.x);
				// mpack
				dc_m[COL_ZERO_IJ(i, j, dim, dim)] = tmp;

			}
		}
		//rdd_sqrt_ui(tmp, 5UL);
		//std::cout << "sqrt5 = " << tmp.to_string() << std::endl;
		//rdd_mul_ui(tmp, tmp, (unsigned long)(2 + 3 + 1));
		//std::cout << "5 / 6 = " << tmp.to_string() << std::endl;

		//normf_ddmatrix(tmp.x, da); std::cout << "||A||_F = " << tmp.x[0] << std::endl;
		//normf_ddmatrix(tmp.x, db); std::cout << "||B||_F = " << tmp.x[0] << std::endl;

		iteration = 1; //1.0;
		do{
//#ifdef USE_OMP
//			stime = omp_get_wtime();
//#else // USE_OMP
			stime = get_real_secv();
//#endif // USE_OMP
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_ddmatrix_strassen(dc, da, db, min_dim);
//				_bncomp_mul_ddmatrix_strassen_nonrec(dc, da, db, min_dim);
				_bncomp_get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_ddmatrix_strassen(dc, da, db, min_dim);
				get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_STRASSEN_PADDING // USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_ddmatrix_strassen(dc, da, db, min_dim);
				_bncomp_get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_ddmatrix_strassen();
//				mul_ddmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_ddmatrix_strassen_odd_padding(dc, da, db, min_dim);
				get_num_mul_ddmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
//			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) _bncomp_mul_ddmatrix_block(dc, da, db, min_dim);
#else // USE_OMP
//			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, min_dim);
#endif // USE_OMP

#elif USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN		
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
	#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_ddmatrix_oz(dc, da, max_num_div, db, max_num_div);
	#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_ddmatrix_oz(dc, da, max_num_div, db, max_num_div);
	#endif // USE_OMP

#elif USE_MBLAS // USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			//cout << "one = " << one << ", zero = " << zero << endl; //printf("Rgemm(%ld, %ld)\n", dim, dim);
			for(i = 0; i < iteration; i++) Rgemm("n", "n", dim, dim, dim, one, da_m, dim, db_m, dim, zero, dc_m, dim);

#else // USE_OZ // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_ddmatrix_simple(dc, da, db);
#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_ddmatrix_simple(dc, da, db);
#endif // USE_OMP
#endif // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN

			//etime = get_secv() - stime;
//#ifdef USE_OMP
//			etime = omp_get_wtime() - stime;
//#else // USE_OMP
			etime = get_real_secv() - stime;
//#endif // USE_OMP
			iteration *= 2; //2.0;
		} while(etime < 2);

#ifdef USE_MBLAS
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
				set_ddmatrix_ij(dc, i, j, dc_m[COL_ZERO_IJ(i, j, dim, dim)].x);
				//printf("dc[%ld][%ld] = %25.17e\n", i, j, dc->element[0][ROW_ZERO_IJ(i, j, dim, dim)]);
			}
		}
		//printf("||C|| = "); normf_ddmatrix(tmp.x, dc); cout << tmp.x[0]; printf("\n");
#else // USE_MBLAS
		//printf("||C|| = "); normf_ddmatrix(tmp.x, dc); cout << tmp.x[0]; printf("\n");
#endif // USE_MBLAS

		// get relative errors
#ifdef USE_OMP
		_bncomp_mul_ddmatrix_simple(dc_long, da, db);
		//mul_ddmatrix_simple(dc_long, da, db);
#else // USE_OMP
//		mul_ddmatrix(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
		mul_ddmatrix_simple(dc_long, da, db);
#endif // USE_OMP
		relerr3_ddmatrix(relerr[0].x, relerr[1].x, relerr[2].x, dc, dc_long, 0);

		//printf("etime = %g, Iteration = %ld\n", etime, iteration / 2);
		etime /= iteration / 2;


//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		//printf("[%5ld bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", (long int)106, dim, dim, etime, num_mul, num_addsub);
		printf("[%5ld bits] %5ld x %5ld: %9.5f sec ", (long int)106, dim, dim, etime);
		printf(" "); printf("%10.3e", to_double(relerr[0])); //rdd_out_str(relerr[0]);
		printf(" "); printf("%10.3e", to_double(relerr[1])); //rdd_out_str(relerr[1]);
		printf(" "); printf("%10.3e", to_double(relerr[2])); //rdd_out_str(relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_ddmatrix(da);
		free_ddmatrix(db);
		free_ddmatrix(dc);
		free_ddmatrix(dc_long);

		// mpack
		delete[] da_m;
		delete[] db_m;
		delete[] dc_m;

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}
	}

	return end_flag;
}
//#endif // USE_DDLINEAR

int main(int argc, char *argv[])
{
	int num_threads = 1, max_num_div = 10;
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 1200;

	if(argc < 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OZ
		max_num_div = atoi(argv[1]);
	#else // USE_OZ
		min_dim = atol(argv[1]);
		if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
		{
			printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			//return -1;
		}
	#endif // USE_OZ
#ifdef USE_OMP
		if(argc >= 3)
		{
			num_threads = atoi(argv[2]);
			if(num_threads < 1)
			{
				printf("num_threads is 1\n");
			}
		}
		if(argc >= 4)
		{
			maxsec = atol(argv[3]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[1]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
#ifdef USE_OMP
		num_threads = atoi(argv[1]);
		if(num_threads < 1)
		{
			printf("num_threads is 1\n");
		}
		if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[2]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	}
    bnc_print_env_all();
	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

#ifdef USE_OZ
	//#ifdef OZ_MAX_NUM_DIV
	//printf("Ozaki scheme, max_num_div = %d\n", OZ_MAX_NUM_DIV);
	//#else // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

	// Initialize QD library
	fpu_fix_start(NULL);
	printf("Maxsec: %ld\n", maxsec);

#ifdef USE_OMP
	set_bncomp_num_threads(num_threads);
	printf("OpenMP #threads = %d\n", omp_get_num_threads());
#endif // USE_OMP

//	for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	//for(idim = 1024; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_dd(idim - 1, idim + 1, 1, maxsec, 0, min_dim, max_num_div);

//		end_flag = matmulloop_dd(idim - 1, idim + 1, 1, maxsec, 0);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_dd(idim_half - 1, idim_half + 1, 1, maxsec, 0, min_dim, max_num_div);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_dd(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

