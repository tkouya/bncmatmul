/********************************************************************************/
/* matmulbench_cqd.cc:                                                          */
/* Copyright (C) 2023 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ccomplex>
#include "qd/qd_real.h"
using namespace std;

// mplapack, mpblas
//#ifdef USE_MBLAS
#ifdef OLD_MBLAS
    #include <mblas_qd.h>
    #include <mblas_mpfr.h>
    //#include <mlapack_dd.h>
#else // OLD_MBLAS
    #include <mpblas_qd.h>
	#include <mpblas_mpfr.h>
    //#include <mplapack_dd.h>
#endif // OLD_MBLAS


//#include "bnc.h"
#include "matmul_strassen.h"
#include "get_secv.h"

#ifdef USE_OMP
	#include "bncomp.h"
#endif // USE_OMP

// row-major, zero index
#define ROW_ZERO_IJ(i, j, row_dim, col_dim)	((i) * (col_dim) + (j))
// column-major, zero index
#define COL_ZERO_IJ(i, j, row_dim, col_dim)	((i) + (j) * (row_dim))

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [num_threads] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [num_threads] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#else // USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		printf("USAGE-> %s [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
}

//#ifdef USE_DDLINEAR

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_cqd(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, long int min_dim, int max_num_div)
{
	long int dim;
	long int i, j, end_flag = 0;
	long int num_addsub, num_mul, iteration;
	double etime, stime, mflops;
	CQDMatrix da, db, dc;
	//DDMatrix dc_long;
	CQDMatrix dc_long;
	qd_real tmp, tmp1, relerr[7], one = (dd_real)(1.0), zero = (dd_real)(0.0);
	qd_complex ctmp, *da_m, *db_m, *dc_m;

#ifdef USE_OZ
	//int max_num_div; // For Ozaki scheme
	//#ifdef OZ_MAX_NUM_DIV
	//max_num_div = OZ_MAX_NUM_DIV;
	//#else // OZ_MAX_NUM_DIV
	//max_num_div = 10;
	//fprintf(stderr, "Warning: no definition of OZ_MAX_NUM_DIV! -> max_num_div = %d\n", max_num_div);
	//printf("max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

	// initialize
	rqd_srand((unsigned long)(dim * 212));

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init_cqdmatrix(dim, dim);
		db = init_cqdmatrix(dim, dim);
		dc = init_cqdmatrix(dim, dim);
		//dc_long = init_ddmatrix(dim, dim);
		dc_long = init_cqdmatrix(dim, dim);

	// mpack
		da_m = new qd_complex[dim * dim];
		db_m = new qd_complex[dim * dim];
		dc_m = new qd_complex[dim * dim];

		rqd_srand(20230531);
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_ddmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
//				rqd_set_ui(tmp.x, 5UL);
//				rqd_sqrt(tmp.x, tmp.x);
				//tmp = sqrt((dd_real)5.0) * (dd_real)(double)(i + j + 1);
				//tmp = sqrt((dd_real)rand()) * (dd_real)(double)(i + j + 1);
				//rqd_sqrt_ui(tmp.x, 5UL);
				//cout << "tmp = " << tmp << endl;
				//rqd_mul_ui(tmp.x, tmp.x, (unsigned long)(i + j + 1));

				// tmp := (ru - 0.5) * exp(rn)
				rqd_urand(tmp.x); // ru in [0, 1]
				rqd_sub_d(tmp.x, tmp.x, 0.5); // (ru - 0.5)
				rqd_nrand(tmp1.x); rqd_exp_mpfr(tmp1.x, tmp1.x); // exp(rn)
				rqd_mul(tmp.x, tmp.x, tmp1.x);
                rqd_set(ctmp.real().x, tmp.x);

				rqd_urand(tmp.x); // ru in [0, 1]
				rqd_sub_d(tmp.x, tmp.x, 0.5); // (ru - 0.5)
				rqd_nrand(tmp1.x);rqd_exp_mpfr(tmp1.x, tmp1.x); // exp(rn)
				rqd_mul(tmp.x, tmp.x, tmp1.x);
                rqd_set(ctmp.imag().x, tmp.x);
				//mpc_set_fr_fr(ctmp, tmp, tmp, get_bnc_default_rounding_mode());
				set_cqdmatrix_ij_qd_complex(da, i, j, ctmp);

				//set_cqdmatrix_ij(da, i, j, tmp.x);
				// mpack
				da_m[COL_ZERO_IJ(i, j, dim, dim)] = ctmp;
				//cout << "tmp = " << tmp << endl;
				//printf("tmp_x = %25.17e\n", tmp.x[0]);

//				set_ddmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				//rqd_sqrt_ui(tmp.x, 3UL);
				//rqd_mul_ui(tmp.x, tmp.x, (unsigned long)(dim - i));
				//tmp = sqrt((dd_real)3.0) * (dd_real)(double)(dim - i);
				//set_ddmatrix_ij(db, i, j, tmp.x);
				// mpack
				// tmp := (ru - 0.5) * exp(rn)
				rqd_urand(tmp.x); // ru in [0, 1]
				rqd_sub_d(tmp.x, tmp.x, 0.5); // (ru - 0.5)
				rqd_nrand(tmp1.x); rqd_exp_mpfr(tmp1.x, tmp1.x); // exp(rn)
				rqd_mul(tmp.x, tmp.x, tmp1.x);
                rqd_set(ctmp.real().x, tmp.x);

				rqd_urand(tmp.x); // ru in [0, 1]
				rqd_sub_d(tmp.x, tmp.x, 0.5); // (ru - 0.5)
				rqd_nrand(tmp1.x);rqd_exp_mpfr(tmp1.x, tmp1.x); // exp(rn)
				rqd_mul(tmp.x, tmp.x, tmp1.x);
                rqd_set(ctmp.imag().x, tmp.x);
				//mpc_set_fr_fr(ctmp, tmp, tmp, get_bnc_default_rounding_mode());
				set_cqdmatrix_ij_qd_complex(db, i, j, ctmp);

				db_m[COL_ZERO_IJ(i, j, dim, dim)] = ctmp;

				rqd_sqrt_ui(tmp.x, 2UL);
				set_cqdmatrix_ij_qd(dc, i, j, tmp.x);
				// mpack
				dc_m[COL_ZERO_IJ(i, j, dim, dim)] = tmp;

			}
		}
		//rqd_sqrt_ui(tmp, 5UL);
		//std::cout << "sqrt5 = " << tmp.to_string() << std::endl;
		//rqd_mul_ui(tmp, tmp, (unsigned long)(2 + 3 + 1));
		//std::cout << "5 / 6 = " << tmp.to_string() << std::endl;

		//normf_ddmatrix(tmp.x, da); std::cout << "||A||_F = " << tmp.x[0] << std::endl;
		//normf_ddmatrix(tmp.x, db); std::cout << "||B||_F = " << tmp.x[0] << std::endl;

		iteration = 1; //1.0;
		do{
			stime = get_real_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				//_bncomp_reset_num_mul_cqdmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_cqdmatrix_strassen(dc, da, db, min_dim);
//				_bncomp_mul_ddmatrix_strassen_nonrec(dc, da, db, min_dim);
				//_bncomp_get_num_mul_cqdmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				//reset_num_mul_cqdmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_cqdmatrix_strassen(dc, da, db, min_dim);
				//get_num_mul_cqdmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_STRASSEN_PADDING // USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				//_bncomp_reset_num_mul_cqdmatrix_strassen();
//				mul_ddmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_cqdmatrix_strassen(dc, da, db, min_dim);
				//_bncomp_get_num_mul_cqdmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				//reset_num_mul_cqdmatrix_strassen();
//				mul_ddmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_cqdmatrix_strassen_odd_padding(dc, da, db, min_dim);
				//get_num_mul_cqdmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
			num_mul = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
#ifdef USE_OMP
//			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) _bncomp_mul_cqdmatrix_block(dc, da, db, min_dim);
#else // USE_OMP
//			for(i = 0; i < iteration; i++) mul_ddmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_cqdmatrix_block(dc, da, db, min_dim);
#endif // USE_OMP

#elif USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN		
			num_addsub = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
			num_mul = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
	#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_cqdmatrix_oz(dc, da, max_num_div, max_num_div, db, max_num_div, max_num_div);
	#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_cqdmatrix_oz(dc, da, max_num_div, max_num_div, db, max_num_div, max_num_div);
	#endif // USE_OMP

#elif USE_MBLAS // USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
			num_mul = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
			//cout << "one = " << one << ", zero = " << zero << endl; //printf("Rgemm(%ld, %ld)\n", dim, dim);
			for(i = 0; i < iteration; i++) Cgemm("n", "n", dim, dim, dim, one, da_m, dim, db_m, dim, zero, dc_m, dim);

#else // USE_OZ // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
			num_mul = da->re->row_dim * dc->re->row_dim * dc->re->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_cqdmatrix_simple(dc, da, db);
#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_cqdmatrix_simple(dc, da, db);
#endif // USE_OMP
#endif // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN

			//etime = get_secv() - stime;
			etime = get_real_secv() - stime;
			iteration *= 2; //2.0;
		} while(etime < 2);

#ifdef USE_MBLAS
		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
				set_cqdmatrix_ij_qd_complex(dc, i, j, dc_m[COL_ZERO_IJ(i, j, dim, dim)]);
				//printf("dc[%ld][%ld] = %25.17e\n", i, j, dc->element[0][ROW_ZERO_IJ(i, j, dim, dim)]);
			}
		}
		//printf("||C|| = "); normf_ddmatrix(tmp.x, dc); cout << tmp.x[0]; printf("\n");
#else // USE_MBLAS
		//printf("||C|| = "); normf_ddmatrix(tmp.x, dc); cout << tmp.x[0]; printf("\n");
#endif // USE_MBLAS

		// get relative errors
#ifdef USE_OMP
		_bncomp_mul_cqdmatrix_simple(dc_long, da, db);
		//mul_ddmatrix_simple(dc_long, da, db);
#else // USE_OMP
//		mul_qdmatrix(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
		mul_cqdmatrix_simple(dc_long, da, db);
#endif // USE_OMP
		relerr3_cqdmatrix(relerr[0].x, relerr[1].x, relerr[2].x, relerr[3].x, relerr[4].x, relerr[5].x, relerr[6].x, dc, dc_long, 0);

		//printf("etime = %g, Iteration = %ld\n", etime, iteration / 2);
		etime /= iteration / 2;


//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		//printf("[%5ld bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", (long int)106, dim, dim, etime, num_mul, num_addsub);
		printf("[%5ld bits] %5ld x %5ld: %9.5f sec ", (long int)212, dim, dim, etime);
		printf(" "); printf("%10.3e", to_double(relerr[0])); //rqd_out_str(relerr[0]);
		printf(" "); printf("%10.3e", to_double(relerr[1])); //rqd_out_str(relerr[1]);
		printf(" "); printf("%10.3e", to_double(relerr[2])); //rqd_out_str(relerr[2]);
		printf(" "); printf("%10.3e", to_double(relerr[3])); //rqd_out_str(relerr[3]);
		printf(" "); printf("%10.3e", to_double(relerr[4])); //rqd_out_str(relerr[4]); 
		printf(" "); printf("%10.3e", to_double(relerr[5])); //rqd_out_str(relerr[5]);
		printf(" "); printf("%10.3e", to_double(relerr[6])); //rqd_out_str(relerr[6]);// 

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_cqdmatrix(da);
		free_cqdmatrix(db);
		free_cqdmatrix(dc);
		free_cqdmatrix(dc_long);

		// mpack
		delete[] da_m;
		delete[] db_m;
		delete[] dc_m;

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}
	}

	return end_flag;
}
//#endif // USE_DDLINEAR

int main(int argc, char *argv[])
{
	int num_threads = 1, max_num_div = 10;
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 1200;

	if(argc < 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OZ
		max_num_div = atoi(argv[1]);
	#else // USE_OZ
		min_dim = atol(argv[1]);
		if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
		{
			printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			//return -1;
		}
	#endif // USE_OZ
#ifdef USE_OMP
		if(argc >= 3)
		{
			num_threads = atoi(argv[2]);
			if(num_threads < 1)
			{
				printf("num_threads is 1\n");
			}
		}
		if(argc >= 4)
		{
			maxsec = atol(argv[3]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[1]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
#ifdef USE_OMP
		num_threads = atoi(argv[1]);
		if(num_threads < 1)
		{
			printf("num_threads is 1\n");
		}
		if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[2]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	}
    bnc_print_env_all();
	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

	#ifdef USE_4M
	printf("Using 4M method\n");
	#else // USE_4M
	printf("Using 3M method\n");
	#endif // USE_4M

#ifdef USE_OZ
	//#ifdef OZ_MAX_NUM_DIV
	//printf("Ozaki scheme, max_num_div = %d\n", OZ_MAX_NUM_DIV);
	//#else // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

	// Initialize QD library
	fpu_fix_start(NULL);
	printf("Maxsec: %ld\n", maxsec);

#ifdef USE_OMP
	set_bncomp_num_threads(num_threads);
	printf("OpenMP #threads = %d\n", omp_get_num_threads());
#endif // USE_OMP

//	for(idim = 32; idim <= 16384; idim *= 2)
	for(idim = 32; idim <= 2048; idim *= 2)
	//for(idim = min_dim; idim < 32768; idim *= 2)
	//for(idim = 1024; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_cqd(idim - 1, idim + 1, 1, maxsec, 0, min_dim, max_num_div);

//		end_flag = matmulloop_dd(idim - 1, idim + 1, 1, maxsec, 0);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_cqd(idim_half - 1, idim_half + 1, 1, maxsec, 0, min_dim, max_num_div);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_dd(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

