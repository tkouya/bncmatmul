/********************************************************************************/
/* matmulbench_td.cc:                                                            */
/* Copyright (C) 2015 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include "qd/qd_real.h"

using namespace std;

#include "matmul_strassen.h"
#include "get_secv.h"

#ifdef USE_OMP
	#include "bncomp.h"
#endif // USE_OMP

// row-major, zero index
#define RAW_ZERO_IJ(i, j, row_dim, col_dim)	((i) * (col_dim) + (j))
// column-major, zero index
#define COL_ZERO_IJ(i, j, row_dim, col_dim)	((i) + (j) * (row_dim))

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [num_threads] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [num_threads] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#else // USE_OMP
		#ifdef USE_OZ
		printf("USAGE-> %s [max_num_div] [Maximum seconds]\n", commandname);
		#else // USE_OZ
		printf("USAGE-> %s [min_dim] [Maximum seconds]\n", commandname);
		#endif // USE_OZ
	#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OMP
		printf("USAGE-> %s [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
}

//#ifdef USE_DDLINEAR

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_td(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, long int min_dim, int max_num_div)
{
	long int dim;
	long int i, j, end_flag = 0;
	long int num_addsub, num_mul;
	double iteration, etime, stime, mflops;
	TDMatrix da, db, dc;
	//TDMatrix dc_long;
	//TDMatrix dc_long;
	QDMatrix dc_long, da_long, db_long;
	//qd_real tmp, relerr[3];
	qd_real relerr[3];
	double tmp[TDSIZE];
//	qd_real *da_m, *db_m, *dc_m;

#ifdef USE_OZ
/*	int max_num_div; // For Ozaki scheme
	#ifdef OZ_MAX_NUM_DIV
	max_num_div = OZ_MAX_NUM_DIV;
	#else // OZ_MAX_NUM_DIV
	max_num_div = 10;
	fprintf(stderr, "Warning: no definition of OZ_MAX_NUM_DIV! -> max_num_div = %d\n", max_num_div);
	#endif // OZ_MAX_NUM_DIV
*/
#endif // USE_OZ

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init_tdmatrix(dim, dim);
		db = init_tdmatrix(dim, dim);
		dc = init_tdmatrix(dim, dim);
		//dc_long = init_tdmatrix(dim, dim);
		da_long = init_qdmatrix(dim, dim);
		db_long = init_qdmatrix(dim, dim);
		dc_long = init_qdmatrix(dim, dim);

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_tdmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
				rtd_sqrt_ui(tmp, 5UL);
				//rtd_set_ui(tmp, 5UL); rtd_sqrt(tmp, tmp);
				rtd_mul_ui(tmp, tmp, (unsigned long)(i + j + 1));
				//rtd_mul(tmp, tmp, (unsigned long)(i + j + 1));
				set_tdmatrix_ij(da, i, j, tmp);
				// mpack
				//da_m[COL_ZERO_IJ(i, j, dim, dim)] = tmp;

//				set_tdmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				rtd_sqrt_ui(tmp, 3UL);
				rtd_mul_ui(tmp, tmp, (unsigned long)(dim - i));
				set_tdmatrix_ij(db, i, j, tmp);

				rtd_sqrt_ui(tmp, 2UL);
				set_tdmatrix_ij(dc, i, j, tmp);

			}
		}
		//rtd_sqrt_ui(tmp, 5UL);
		//std::cout << "sqrt5 = " << tmp.to_string() << std::endl;
		//rtd_mul_ui(tmp, tmp, (unsigned long)(2 + 3 + 1));
		//std::cout << "5 / 6 = " << tmp.to_string() << std::endl;

		//normf_tdmatrix(&tmp, da); std::cout << "||A||_F = " << tmp << std::endl;
		//normf_tdmatrix(&tmp, da); std::cout << "||B||_F = " << tmp << std::endl;

		iteration = 1.0;
		do{
			stime = get_real_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_tdmatrix_strassen();
//				mul_tdmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_tdmatrix_strassen(dc, da, db, min_dim);
//				_bncomp_mul_tdmatrix_strassen_nonrec(dc, da, db, min_dim);
				_bncomp_get_num_mul_tdmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_tdmatrix_strassen();
//				mul_tdmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_tdmatrix_strassen(dc, da, db, min_dim);
				get_num_mul_tdmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_STRASSEN_PADDING // USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_tdmatrix_strassen();
//				mul_tdmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_tdmatrix_strassen(dc, da, db, min_dim);
				_bncomp_get_num_mul_tdmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_tdmatrix_strassen();
//				mul_tdmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_tdmatrix_strassen_odd_padding(dc, da, db, min_dim);
				get_num_mul_tdmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
//			for(i = 0; i < iteration; i++) mul_tdmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) _bncomp_mul_tdmatrix_block(dc, da, db, min_dim);
#else // USE_OMP
//			for(i = 0; i < iteration; i++) mul_tdmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_tdmatrix_block(dc, da, db, min_dim);
#endif // USE_OMP

//#elif USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
//			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
//			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
//
//			for(i = 0; i < iteration; i++) Rgemm("n", "n", dim, dim, dim, 1.0, da_m, dim, db_m, dim, 0.0, dc_m, dim);
#elif USE_OZ // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN		
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
			for(i = 0; i < iteration; i++) mul_tdmatrix_oz(dc, da, max_num_div, db, max_num_div);

#else // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_tdmatrix_simple(dc, da, db);
#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_tdmatrix_simple(dc, da, db);
#endif // USE_OMP
#endif // USE_MBLAS // USE_BLOCK // USE_STRASSEN_PADDING // USE_STRASSEN

			//etime = get_secv() - stime;
			etime = get_real_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);

		// get relative errors

		subst_qdmatrix_tdmat(da_long, da);
		subst_qdmatrix_tdmat(db_long, db);
#ifdef USE_OMP
		//_bncomp_mul_tdmatrix_simple(dc_long, da, db);
		//mul_tdmatrix_simple(dc_long, da, db);
		_bncomp_mul_qdmatrix_simple(dc_long, da_long, db_long);
#else // USE_OMP
//		mul_tdmatrix(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
		mul_qdmatrix_simple(dc_long, da_long, db_long);
#endif // USE_OMP
		//relerr3_tdmatrix(relerr[0].x, relerr[1].x, relerr[2].x, dc, dc_long, 0);
		subst_qdmatrix_tdmat(da_long, dc);
		relerr3_qdmatrix(relerr[0].x, relerr[1].x, relerr[2].x, da_long, dc_long, 0);

		etime /= iteration / 2;

//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		//printf("[%5ld bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", (long int)(53 * TDSIZE), dim, dim, etime, num_mul, num_addsub);
		printf("[%5ld bits] %5ld x %5ld: %9.5f sec", (long int)(53 * TDSIZE), dim, dim, etime);
		printf(" "); printf("%10.3e", to_double(relerr[0])); //rtd_out_str(relerr[0]);
		printf(" "); printf("%10.3e", to_double(relerr[1])); //rtd_out_str(relerr[1]);
		printf(" "); printf("%10.3e", to_double(relerr[2])); //rtd_out_str(relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_tdmatrix(da);
		free_tdmatrix(db);
		free_tdmatrix(dc);
		free_qdmatrix(dc_long);
		free_qdmatrix(da_long);
		free_qdmatrix(db_long);

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}
	}

	return end_flag;
}
//#endif // USE_DDLINEAR

int main(int argc, char *argv[])
{
	int num_threads = 1, max_num_div;
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 2000;

	if(argc < 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK) || defined(USE_OZ)
	#ifdef USE_OZ
		max_num_div = atoi(argv[1]);
	#else // USE_OZ
		min_dim = atol(argv[1]);
		if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
		{
			printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			//return -1;
		}
	#endif // USE_OZ
#ifdef USE_OMP
		if(argc >= 3)
		{
			num_threads = atoi(argv[2]);
			if(num_threads < 1)
			{
				printf("num_threads is 1\n");
			}
		}
		if(argc >= 4)
		{
			maxsec = atol(argv[3]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[1]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
#ifdef USE_OMP
		num_threads = atoi(argv[1]);
		if(num_threads < 1)
		{
			printf("num_threads is 1\n");
		}
		if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		maxsec = atol(argv[2]);
		if(maxsec < 0)
		{
			printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
			return -1;
		}
#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	}
    bnc_print_env_all();
	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

#ifdef USE_OZ
	//#ifdef OZ_MAX_NUM_DIV
	//printf("Ozaki scheme, max_num_div = %d\n", OZ_MAX_NUM_DIV);
	//#else // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, max_num_div = %d\n", max_num_div);
	//#endif // OZ_MAX_NUM_DIV
#endif // USE_OZ

	// Initialize TD library
	fpu_fix_start(NULL);
	printf("Maxsec: %ld\n", maxsec);

#ifdef USE_OMP
	set_bncomp_num_threads(num_threads);
	printf("OpenMP #threads = %d\n", omp_get_num_threads());
#endif // USE_OMP

//	for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_td(idim - 1, idim + 1, 1, maxsec, 0, min_dim, max_num_div);

//		end_flag = matmulloop_td(idim - 1, idim + 1, 1, maxsec, 0);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_td(idim_half - 1, idim_half + 1, 1, maxsec, 0, min_dim, max_num_div);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_td(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

