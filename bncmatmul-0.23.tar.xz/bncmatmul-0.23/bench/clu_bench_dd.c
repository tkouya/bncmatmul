/********************************************************************************/
/* clu_bench_dd.c:                                                              */
/* Copyright (C) 2023 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/* stdio.h */
#ifndef _STDIO_H
#include <stdio.h>
#endif

/* math.h */
#ifndef _MATH_H
#include <math.h>
#endif

//#include "bnc.h"

#ifdef USE_IMKL
	#include "mkl.h"
	#include "mkl_cblas.h" // for Intel Math Kernel Library
#endif

#include "bncomp.h"
#include "matmul_strassen.h"

//#include "lu_bench.h"
#include "get_secv.h"

int main(int argc, char *argv[])
{
	long int dim, *pivot, min_dim, limit_dim, block_size;
	int num_threads;
	double stime, etime[6];
	double reps, aeps, relerr[7][DDSIZE];
	CDDMatrix da;
	CDDVector db, dx, dans;
	long int ret_f, ret_d, ret_mpfS;
	long int *row_ch, *col_ch;
#ifdef USE_IMKL
	lapack_int *row_ch_imkl;
#endif // USE_IMKL
	char fname_A[256], fname_true_x[256], fname_vec_b[256];
	long int i, j;

/* Double */
//	dim = 128;
	if(argc <= 1)
	{
	#ifndef _OPENMP
		fprintf(stderr, "Usage: %s [dim]\n", argv[0]);
	#else // _OPENMP
		fprintf(stderr, "Usage: %s [dim] [#threads] \n", argv[0]);
	#endif // _OPENMP
		return 0;
	}
	dim = atol(argv[1]);
	if(dim <= 0)
		return 0;

#ifdef _OPENMP
	num_threads = 1;
	if(argc >= 3)
	{
		num_threads = atoi(argv[2]);
		if(num_threads < 1)
			num_threads = 1;
	}

//	omp_set_num_threads(num_threads);
//	printf("#Threads: %d\n", omp_get_num_threads());
	set_bncomp_num_threads(num_threads);
#endif // _OPENMP

#ifdef USE_OZ
	#ifndef OZ_MAX_NUM_DIV
	#define OZ_MAX_NUM_DIV 10
	#endif // OZ_MAX_NUM_DIV
	int max_num_div = OZ_MAX_NUM_DIV;
//	#else
//	int max_num_div = 10;
//	#endif // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, ");
	printf("max_num_div = %d\n", max_num_div);
#endif // USE_OZ

	/* initialize */
	// Initialize QD library
	fpu_fix_start(NULL);

	/* initialize */
	row_ch = (long int *)calloc(sizeof(long int), dim);
	col_ch = (long int *)calloc(sizeof(long int), dim);
	da = init_cddmatrix(dim, dim);
	db = init_cddvector(dim);
	dx = init_cddvector(dim);
	dans = init_cddvector(dim);
	pivot = (long int *)calloc(dim, sizeof(long int));

	/* get problem */
	//get_mpfproblem(da, db, dans);
	sprintf(fname_A, "../python/cmat_a_%d_%d_b2048_c.txt", dim, dim);
	sprintf(fname_true_x, "../python/cvec_true_x_%d_b2048_c.txt", dim);
	sprintf(fname_vec_b, "../python/cvec_b_%d_b2048_c.txt", dim);	

	read_test_linear_eq_cdd(da, dans, db, (int)dim, fname_A, fname_true_x, fname_vec_b);

	//printf("A(%ld, %ld) = \n", dim, dim); print_cddmatrix(da);
    //printf("x(%ld) = \n", dim); print_cddvector(dans);
    //printf("b(%ld) = \n", dim); print_cddvector(db);

	/* run MPFLUdecomp & SolveMPFLS */
	//stime = get_secv();
	stime = get_real_secv();
#ifndef _OPENMP
	//ret_d = CDDLUdecomp(da);
	ret_d = CDDLUdecompPM(da, pivot);
#else // _OPENMP
	//ret_d = CDDLUdecomp_omp(da);
	ret_d = CDDLUdecompPM_omp(da, pivot);
#endif // _OPENMP
	//etime[4] = get_secv() - stime;
	etime[4] = get_real_secv() - stime;
	// ret_d = MPFLUdecompP(da, row_ch);
	// ret_d = MPFLUdecompC(da, row_ch, col_ch);
	//ret_d = SolveCDDLS(dx, da, db);
	ret_d = SolveCDDLSPM(dx, da, db, pivot);
	printf("normalLU(%ld, %ld): %g, ", dim, 106, etime[4]);
	// ret_d = SolveMPFLSP(dx, da, db, row_ch);
	//relerr_element_cddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	relerr3_cddvector(relerr[0], relerr[1], relerr[2], relerr[3], relerr[4], relerr[5], relerr[6], dx, dans, 0);
	//printf("relerr(max, min, ||relerr||): ");
	printf("%8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e\n", 
		relerr[0][0],
		relerr[1][0],
		relerr[2][0],
		relerr[3][0],
		relerr[4][0],
		relerr[5][0],
		relerr[6][0]
	);
	/*
	rdd_out_str_base(stdout, 10, 3, relerr[0]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[1]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[2]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[3]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[4]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[5]); printf(", ");
	rdd_out_str_base(stdout, 10, 3, relerr[6]); printf("\n");
	*/
	/*
	rdd_out_str(relerr[0]); printf(", ");
	rdd_out_str(relerr[1]); printf(", ");
	rdd_out_str(relerr[2]); printf(", ");
	rdd_out_str(relerr[3]); printf(", ");
	rdd_out_str(relerr[4]); printf(", ");
	rdd_out_str(relerr[5]); printf(", ");
	rdd_out_str(relerr[6]); printf("\n");
	*/
	// ret_d = SolveMPFLSC(dx, da, db, row_ch, col_ch);

	min_dim = STRASSEN_MIN_DIM;
	etime[5] = 0.0;

	//limit_dim = min_dim * 20;
	limit_dim = dim;
	if(limit_dim > dim) limit_dim = dim;

//	for(block_size = min_dim; block_size <= min_dim * 4; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 10; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 15; block_size += min_dim)
	for(block_size = min_dim; block_size < limit_dim; block_size += min_dim)
	{
		//get_mpfproblem(da, db, dans);
		read_test_linear_eq_cdd(da, dans, db, (int)dim, fname_A, fname_true_x, fname_vec_b);
		//stime = get_secv();
		stime = get_real_secv();
#ifndef _OPENMP
	//	ret_d = MPFLUdecomp_strassen(da, block_size);
		#ifdef USE_OZ
		ret_d = CDDLUdecomp_ozPM(da, pivot, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		ret_d = CDDLUdecomp_strassenPM(da, pivot, block_size);
		#endif // USE_OZ
		//ret_d = MPFLUdecomp_strassenPM(da, pivot, block_size);
		printf("PM ");
	//	ret_d = MPFLUdecomp_strassen(da, 64);
	//	ret_d = MPFLUdecomp_strassen(da, 128);
	//	ret_d = MPFLUdecomp_strassen(da, 16);
		//etime[5] = get_secv() - stime;
#else // _OPENMP
		#ifdef USE_OZ
		ret_d = CDDLUdecomp_ozPM_omp(da, pivot, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		//ret_d = MPFLUdecomp_strassen_omp(da, block_size);
		ret_d = CDDLUdecomp_strassenPM_omp(da, pivot, block_size);
		#endif // USE_OZ
		printf("PM ");
#endif // _OPENMP
		etime[5] = get_real_secv() - stime;
		//ret_d = SolveMPFLS(dx, da, db);
		//ret_d = SolveMPFLSP(dx, da, db, pivot);
		ret_d = SolveCDDLSPM(dx, da, db, pivot);
#ifdef USE_BLOCK 
		printf("blockLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 106, block_size, etime[5]);
#elif USE_STRASSEN
		printf("strassenLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 106, block_size, etime[5]);
#elif USE_WINOGRAD
		printf("winogradLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 106, block_size, etime[5]);
#elif USE_OZ
		printf("ozakiLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, 106, block_size, etime[5]);
#endif
		//relerr_element_cddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
		relerr3_cddvector(relerr[0], relerr[1], relerr[2], relerr[3], relerr[4], relerr[5], relerr[6], dx, dans, 0);
		//printf("relerr(max, min, ||relerr||): ");
		printf("%8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e\n", 
			relerr[0][0],
			relerr[1][0],
			relerr[2][0],
			relerr[3][0],
			relerr[4][0],
			relerr[5][0],
			relerr[6][0]
		);
		/*
		rdd_out_str(relerr[0]); printf(", ");
		rdd_out_str(relerr[1]); printf(", ");
		rdd_out_str(relerr[2]); printf(", ");
		rdd_out_str(relerr[3]); printf(", ");
		rdd_out_str(relerr[4]); printf(", ");
		rdd_out_str(relerr[5]); printf(", ");
		rdd_out_str(relerr[6]); printf("\n");
		*/
		/*
		if(mpf_cmp_ui(relerr[0], 100UL) > 0)
		{
			print_mpfvector(dx);
			for(i = 0; i < dx->dim; i++) printf("%ld ", pivot[i]);
			printf("\n");
		}
		*/
	}
	// relerr_element_mpfvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	// printf("relerr(max, min, ||relerr||): ");
	//rdd_out_str_base(stdout, 10, 3, relerr[0]); printf(", ");
	//rdd_out_str_base(stdout, 10, 3, relerr[1]); printf(", ");
	//rdd_out_str_base(stdout, 10, 3, relerr[2]); printf("\n");

	/* print */
	/* for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		rdd_out_str_base(stdout, 10, 0, get_mpfvector_i(dx, i));
		printf(" ");
		rdd_out_str_base(stdout, 10, 0, get_mpfvector_i(dans, i));
		printf("\n");
	}
*/
	/* end */
	free_cddmatrix(da);
	free_cddvector(db);
	free_cddvector(dx);
	free_cddvector(dans);
	free(pivot);

	/* print itimes */
//end:
	return 0;

}

