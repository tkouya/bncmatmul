/********************************************************************************/
/* lu_bench_dd.c: Quadruple Precision LU decomposition with Strassen MM         */
/*                                                                              */
/* Copyright (C) 2015-2021 Tomonori Kouya                                       */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/* stdio.h */
#ifndef _STDIO_H
#include <stdio.h>
#endif

/* math.h */
#ifndef _MATH_H
#include <math.h>
#endif

//#include "bnc.h"

#include "ddlinear.h"

#ifdef _OPENMP
#include "bncomp.h"
#endif // _OPENMP
#include "matmul_strassen.h"


void get_ddproblem(DDMatrix a, DDVector b, DDVector ans)
{
	long int i, j, k;
	double tmp;

#ifdef USE_GMP
	unsigned long prec = 1024;
	MPFMatrix tmp_a;
	MPFVector tmp_ans, tmp_b;

	tmp_a = init2_mpfmatrix(a->row_dim, a->col_dim, prec);
	tmp_ans = init2_mpfvector(ans->dim, prec);
	tmp_b = init2_mpfvector(b->dim, prec);

	//im_rand_mpfmatrix(tmp_a, tmp_a->row_dim);
	im_rand_ddmatrix(a, a->row_dim);

	/* Answer */
	for(i = 0; i < ans->dim; i++)
		set_ddvector_i_d(ans, i, (double)i);

	subst_mpfmatrix_ddmat(tmp_a, a);
	subst_mpfvector_ddvec(tmp_ans, ans);

	/* Answer */
	//for(i = 0; i < tmp_ans->dim; i++)
	//	set_mpfvector_i_d(tmp_ans, i, (double)i);

	/* Make constant vector */
	mul_mpfmatrix_mpfvec(tmp_b, tmp_a, tmp_ans);

	//subst_ddmatrix_mpfmat(a, tmp_a);
	subst_ddvector_mpfvec(b, tmp_b);
	//subst_ddvector_mpfvec(ans, tmp_ans);

	free_mpfmatrix(tmp_a);
	free_mpfvector(tmp_ans);
	free_mpfvector(tmp_b);
#else // USE_GMP

	/* Lotkin Matrix */
/*	for(i = 0; i < a->col_dim; i++)
		set_ddmatrix_ij(a, 0, i, 1.0);
	for(i = 1; i < a->row_dim; i++)
	{
		for(j = 0; j < a->col_dim; j++)
			set_ddmatrix_ij(a, i, j, 1.0 / (i + j + 1));
	}
*/
//	frank_ddmatrix(a, a->row_dim);
	im_rand_ddmatrix(a, a->row_dim);

	/* Answer */
	for(i = 0; i < ans->dim; i++)
		set_ddvector_i_d(ans, i, (double)i);

	/* Make constant vector */
	mul_ddmatrix_ddvec(b, a, ans);

#endif // USE_GMP
}


//#define DIM 128
//#define DIM 128
//#define DIM 1024

#include "get_secv.h"

int main(int argc, char *argv[])
{
	int num_threads;
	long int dim, block_size, min_dim;
	double stime, etime[6];
	double relerr[3][DDSIZE];
	DDMatrix da;
	DDVector db, dx, dans;
	char fname_A[256], fname_true_x[256], fname_vec_b[256];

	long int ret_f, ret_d, ret_mpf;
	long int *row_ch, *col_ch;
	long int i, j;

/* Double-double */
	if(argc <= 1)
	{
	#ifndef _OPENMP
		fprintf(stderr, "Usage: %s [dim]\n", argv[0]);
	#else // _OPENMP
		fprintf(stderr, "Usage: %s [dim] [#threads]\n", argv[0]);
	#endif // _OPENMP
		return 0;
	}
	dim = atol(argv[1]);
	if(dim <= 0)
		return 0;

#ifdef _OPENMP
	num_threads = 1;
	if(argc >= 3)
	{
		num_threads = atoi(argv[2]);
		if(num_threads < 1)
			num_threads = 1;
	}

//	omp_set_num_threads(num_threads);
//	printf("#Threads: %d\n", omp_get_num_threads());
	set_bncomp_num_threads(num_threads);
#endif // _OPENMP

#ifdef USE_OZ
	#ifdef OZ_MAX_NUM_DIV
	int max_num_div = OZ_MAX_NUM_DIV;
	#else
	int max_num_div = 10;
	#endif // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, ");
	printf("max_num_div = %d\n", max_num_div);
#endif // USE_OZ

	// Initialize QD library
	fpu_fix_start(NULL);

	/* initialize */
	row_ch = (long int *)calloc(sizeof(long int), dim);
	col_ch = (long int *)calloc(sizeof(long int), dim);
	da = init_ddmatrix(dim, dim);
	db = init_ddvector(dim);
	dx = init_ddvector(dim);
	dans = init_ddvector(dim);

	sprintf(fname_A, "../python/mat_a_%ld_%ld_b256.txt", dim, dim);
	sprintf(fname_true_x, "../python/vec_true_x_%ld_b256.txt", dim);
	sprintf(fname_vec_b, "../python/vec_b_%ld_b256.txt", dim);	
	//sprintf(fname_A, "../python/mat_a_%ld_%ld_b256_cond10p11.txt", dim, dim);
	//sprintf(fname_true_x, "../python/vec_true_x_%ld_b256_cond10p11.txt", dim);
	//sprintf(fname_vec_b, "../python/vec_b_%ld_b256_cond10p11.txt", dim);	

	//get_ddproblem(da, db, dans);
	read_test_linear_eq_dd(da, dans, db, dim, fname_A, fname_true_x, fname_vec_b);

	stime = get_real_secv();
#ifdef _OPENMP
	//ret_d = DDLUdecomp_omp(da);
	ret_d = DDLUdecompPM_omp(da, row_ch);
#else // _OPENMP
	//ret_d = DDLUdecomp(da);
	//ret_d = DDLUdecompP(da, row_ch);
	ret_d = DDLUdecompPM(da, row_ch);
#endif // _OPENMP
	etime[1] = get_real_secv() - stime;
	printf("normalLU: %f\n", etime[1]);
	//print_ddmatrix(da);

	//ret_d = SolveDDLS(dx, da, db);
	//ret_d = SolveDDLSP(dx, da, db, row_ch);
	// ret_d = SolveDDLSC(dx, da, db, row_ch, col_ch);
	ret_d = SolveDDLSPM(dx, da, db, row_ch);
	/*for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		rdd_out_str(get_ddvector_i(dx, i));
		printf(" ");
		rdd_out_str(get_ddvector_i(dans, i));
		printf("\n");
	}*/

	relerr_element_ddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	//printf("relerr(max, min, ||relerr||): ");
	//rdd_out_str(relerr[0]); printf(", ");
	//rdd_out_str(relerr[1]); printf(", ");
	//rdd_out_str(relerr[2]); printf("\n");
	printf("relerr(max, min, ||relerr||): %10.3e, %10.3e, %10.3e\n", relerr[0][0], relerr[1][0], relerr[2][0]);

	//return 0;

	min_dim = STRASSEN_MIN_DIM;
	etime[5] = 0.0;
//	for(block_size = min_dim; block_size <= min_dim * 4; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 10; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 15; block_size += min_dim)
	for(block_size = min_dim; block_size < dim; block_size += min_dim)
	{
		/* get problem */
		//get_ddproblem(da, db, dans);
		read_test_linear_eq_dd(da, dans, db, dim, fname_A, fname_true_x, fname_vec_b);

	//	print_ddmatrix(da);

		/* run DLUdecomp & SolveDLS */
		stime = get_real_secv();
#ifdef _OPENMP
		//ret_d = DDLUdecomp_strassen_omp(da, block_size);
		ret_d = DDLUdecomp_strassenPM_omp(da, row_ch, block_size);
#else // _OPENMP
		//ret_d = DDLUdecomp_strassen(da, block_size);
		#ifdef USE_OZ
		ret_d = DDLUdecomp_ozPM(da, row_ch, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		ret_d = DDLUdecomp_strassenPM(da, row_ch, block_size);
		#endif // USE_OZ
#endif // _OPENMP
		etime[5] = get_real_secv() - stime;

		//ret_d = SolveDDLS(dx, da, db);
		ret_d = SolveDDLSPM(dx, da, db, row_ch);

	#ifdef USE_BLOCK 
			printf("DD blockLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)106, block_size, etime[5]);
	#elif USE_STRASSEN
			printf("DD strassenLU(%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)106, block_size, etime[5]);
	#elif USE_WINOGRAD
			printf("DD winogradLU(%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)106, block_size, etime[5]);
	#elif USE_OZ
			printf("DD ozakiLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, (long int)212, block_size, etime[5]);
	#endif
		/*printf("  i    row_ch[i]    col_ch[i]\n");
		for(i = 0; i < dim; i++)
		{
			//("%5ld %25.17e %25.17e\n", i, rdd_get_d(get_ddvector_i(dx, i)), rdd_get_d(get_ddvector_i(dans, i)));
			printf("%5ld ", i); rdd_out_str(get_ddvector_i(dx, i));
		}
		*/

		relerr_element_ddvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
		//printf("relerr(max, min, ||relerr||): ");
		//rdd_out_str(relerr[0]); printf(", ");
		//rdd_out_str(relerr[1]); printf(", ");
		//rdd_out_str(relerr[2]); printf("\n");
		printf("%9.2e, %9.2e, %9.2e\n", relerr[0][0], relerr[1][0], relerr[2][0]);
	}

	/* end */
	free_ddmatrix(da);
	free_ddvector(db);
	free_ddvector(dx);
	free_ddvector(dans);
	free(row_ch);
	free(col_ch);

	/* print itimes */
	return 0;

}

