/********************************************************************************/
/* clu_bench_td.c:                                                              */
/* Copyright (C) 2024 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/* stdio.h */
#ifndef _STDIO_H
#include <stdio.h>
#endif

/* math.h */
#ifndef _MATH_H
#include <math.h>
#endif

//#include "bnc.h"

#ifdef USE_IMKL
	#include "mkl.h"
	#include "mkl_cblas.h" // for Intel Math Kernel Library
#endif

#include "bncomp.h"
#include "matmul_strassen.h"

//#include "lu_bench.h"
#include "get_secv.h"

int main(int argc, char *argv[])
{
	long int dim, *pivot, min_dim, limit_dim, block_size;
	int num_threads;
	double stime, etime[6];
	double reps, aeps, relerr[7][TDSIZE];
	CTDMatrix da;
	CTDVector db, dx, dans;
	long int ret_f, ret_d, ret_mpfS;
	long int *row_ch, *col_ch;
#ifdef USE_IMKL
	lapack_int *row_ch_imkl;
#endif // USE_IMKL
	char fname_A[256], fname_true_x[256], fname_vec_b[256];
	long int i, j;

/* Double */
//	dim = 128;
	if(argc <= 1)
	{
	#ifndef _OPENMP
		fprintf(stderr, "Usage: %s [dim]\n", argv[0]);
	#else // _OPENMP
		fprintf(stderr, "Usage: %s [dim] [#threads] \n", argv[0]);
	#endif // _OPENMP
		return 0;
	}
	dim = atol(argv[1]);
	if(dim <= 0)
		return 0;

#ifdef _OPENMP
	num_threads = 1;
	if(argc >= 3)
	{
		num_threads = atoi(argv[2]);
		if(num_threads < 1)
			num_threads = 1;
	}

//	omp_set_num_threads(num_threads);
//	printf("#Threads: %d\n", omp_get_num_threads());
	set_bncomp_num_threads(num_threads);
#endif // _OPENMP

#ifdef USE_OZ
	#ifndef OZ_MAX_NUM_DIV
	#define OZ_MAX_NUM_DIV 10
	#endif // OZ_MAX_NUM_DIV
	int max_num_div = OZ_MAX_NUM_DIV;
//	#else
//	int max_num_div = 10;
//	#endif // OZ_MAX_NUM_DIV
	printf("Ozaki scheme, ");
	printf("max_num_div = %d\n", max_num_div);
#endif // USE_OZ

	/* initialize */
	// Initialize QD library
	fpu_fix_start(NULL);

	/* initialize */
	row_ch = (long int *)calloc(sizeof(long int), dim);
	col_ch = (long int *)calloc(sizeof(long int), dim);
	da = init_ctdmatrix(dim, dim);
	db = init_ctdvector(dim);
	dx = init_ctdvector(dim);
	dans = init_ctdvector(dim);
	pivot = (long int *)calloc(dim, sizeof(long int));

	/* get problem */
	//get_mpfproblem(da, db, dans);
	sprintf(fname_A, "../python/cmat_a_%d_%d_b2048_c.txt", dim, dim);
	sprintf(fname_true_x, "../python/cvec_true_x_%d_b2048_c.txt", dim);
	sprintf(fname_vec_b, "../python/cvec_b_%d_b2048_c.txt", dim);	

	read_test_linear_eq_ctd(da, dans, db, (int)dim, fname_A, fname_true_x, fname_vec_b);

	//printf("A(%ld, %ld) = \n", dim, dim); print_ctdmatrix(da);
    //printf("x(%ld) = \n", dim); print_ctdvector(dans);
    //printf("b(%ld) = \n", dim); print_ctdvector(db);

	/* run MPFLUdecomp & SolveMPFLS */
	//stime = get_secv();
	stime = get_real_secv();
#ifndef _OPENMP
	//ret_d = CTDLUdecomp(da);
	ret_d = CTDLUdecompPM(da, pivot);
#else // _OPENMP
	//ret_d = CTDLUdecomp_omp(da);
	ret_d = CTDLUdecompPM_omp(da, pivot);
#endif // _OPENMP
	//etime[4] = get_secv() - stime;
	etime[4] = get_real_secv() - stime;
	// ret_d = MPFLUdecompP(da, row_ch);
	// ret_d = MPFLUdecompC(da, row_ch, col_ch);
	//ret_d = SolveCTDLS(dx, da, db);
	ret_d = SolveCTDLSPM(dx, da, db, pivot);
	printf("normalLU(%ld, %ld): %g, ", dim, 212, etime[4]);
	// ret_d = SolveMPFLSP(dx, da, db, row_ch);
	//relerr_element_ctdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	relerr3_ctdvector(relerr[0], relerr[1], relerr[2], relerr[3], relerr[4], relerr[5], relerr[6], dx, dans, 0);
	//printf("relerr(max, min, ||relerr||): ");
	printf("%8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e, %8.1e\n", 
		relerr[0][0],
		relerr[1][0],
		relerr[2][0],
		relerr[3][0],
		relerr[4][0],
		relerr[5][0],
		relerr[6][0]
	);
	/* 
	rtd_out_str(relerr[0]); printf(", ");
	rtd_out_str(relerr[1]); printf(", ");
	rtd_out_str(relerr[2]); printf(", ");
	rtd_out_str(relerr[3]); printf(", ");
	rtd_out_str(relerr[4]); printf(", ");
	rtd_out_str(relerr[5]); printf(", ");
	rtd_out_str(relerr[6]); printf("\n");
	*/
	printf("%7.1e, %7.1e, %7.1e, %7.1e, %7.1e, %7.1e, %7.1e\n", relerr[0][0], relerr[1][0], relerr[2][0], relerr[3][0], relerr[4][0], relerr[5][0], relerr[6][0]);
	// ret_d = SolveMPFLSC(dx, da, db, row_ch, col_ch);

	min_dim = STRASSEN_MIN_DIM;
	etime[5] = 0.0;

	//limit_dim = min_dim * 20;
	limit_dim = dim;
	if(limit_dim > dim) limit_dim = dim;

//	for(block_size = min_dim; block_size <= min_dim * 4; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 10; block_size += min_dim)
//	for(block_size = min_dim; block_size <= min_dim * 15; block_size += min_dim)
	for(block_size = min_dim; block_size < limit_dim; block_size += min_dim)
	{
		//get_mpfproblem(da, db, dans);
		read_test_linear_eq_ctd(da, dans, db, (int)dim, fname_A, fname_true_x, fname_vec_b);
		//stime = get_secv();
		stime = get_real_secv();
#ifndef _OPENMP
	//	ret_d = MPFLUdecomp_strassen(da, block_size);
		#ifdef USE_OZ
		ret_d = CTDLUdecomp_ozPM(da, pivot, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		ret_d = CTDLUdecomp_strassenPM(da, pivot, block_size);
		#endif // USE_OZ
		//ret_d = MPFLUdecomp_strassenPM(da, pivot, block_size);
		printf("PM ");
	//	ret_d = MPFLUdecomp_strassen(da, 64);
	//	ret_d = MPFLUdecomp_strassen(da, 128);
	//	ret_d = MPFLUdecomp_strassen(da, 16);
		//etime[5] = get_secv() - stime;
#else // _OPENMP
		//ret_d = MPFLUdecomp_strassen_omp(da, block_size);
		#ifdef USE_OZ
		ret_d = CTDLUdecomp_ozPM_omp(da, pivot, block_size, max_num_div);
		printf("oz ");
		#else // USE_OZ
		ret_d = CTDLUdecomp_strassenPM_omp(da, pivot, block_size);
		#endif // USE_OZ
		printf("PM ");
#endif // _OPENMP
		etime[5] = get_real_secv() - stime;
		//ret_d = SolveMPFLS(dx, da, db);
		//ret_d = SolveMPFLSP(dx, da, db, pivot);
		ret_d = SolveCTDLSPM(dx, da, db, pivot);
#ifdef USE_BLOCK 
		printf("blockLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 212, block_size, etime[5]);
#elif USE_STRASSEN
		printf("strassenLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 212, block_size, etime[5]);
#elif USE_WINOGRAD
		printf("winogradLU(%5ld, %5ld, %5ld): %10.3f, ", dim, 212, block_size, etime[5]);
#elif USE_OZ
		printf("ozakiLU   (%5ld, %5ld, %5ld): %10.3f, ", dim, 212, block_size, etime[5]);
#endif
		//relerr_element_ctdvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
		relerr3_ctdvector(relerr[0], relerr[1], relerr[2], relerr[3], relerr[4], relerr[5], relerr[6], dx, dans, 0);
		//printf("relerr(max, min, ||relerr||): ");
		/*
		rtd_out_str(relerr[0]); printf(", ");
		rtd_out_str(relerr[1]); printf(", ");
		rtd_out_str(relerr[2]); printf(", ");
		rtd_out_str(relerr[3]); printf(", ");
		rtd_out_str(relerr[4]); printf(", ");
		rtd_out_str(relerr[5]); printf(", ");
		rtd_out_str(relerr[6]); printf("\n");
		*/
		printf("%7.1e, %7.1e, %7.1e, %7.1e, %7.1e, %7.1e, %7.1e\n", relerr[0][0], relerr[1][0], relerr[2][0], relerr[3][0], relerr[4][0], relerr[5][0], relerr[6][0]);
		/*
		if(mpf_cmp_ui(relerr[0], 100UL) > 0)
		{
			print_mpfvector(dx);
			for(i = 0; i < dx->dim; i++) printf("%ld ", pivot[i]);
			printf("\n");
		}
		*/
	}
	// relerr_element_mpfvector(relerr[0], relerr[1], relerr[2], dx, dans, 0);
	// printf("relerr(max, min, ||relerr||): ");
	//rqd_out_str_base(stdout, 10, 3, relerr[0]); printf(", ");
	//rqd_out_str_base(stdout, 10, 3, relerr[1]); printf(", ");
	//rqd_out_str_base(stdout, 10, 3, relerr[2]); printf("\n");

	/* print */
	/* for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		rqd_out_str_base(stdout, 10, 0, get_mpfvector_i(dx, i));
		printf(" ");
		rqd_out_str_base(stdout, 10, 0, get_mpfvector_i(dans, i));
		printf("\n");
	}
*/
	/* end */
	free_ctdmatrix(da);
	free_ctdvector(db);
	free_ctdvector(dx);
	free_ctdvector(dans);
	free(pivot);

	/* print itimes */
//end:
	return 0;

}

