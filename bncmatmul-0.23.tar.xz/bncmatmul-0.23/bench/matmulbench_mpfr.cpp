/********************************************************************************/
/* matmulbench_mpf.c:                                                           */
/* Copyright (C) 2014 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bnc.h"
#include "matmul_strassen.h"
#ifdef USE_OMP
	#include "bncomp.h"
#endif

// 256k bytes
//#define CACHESIZE (256 * 1024)

// 512k bytes
//#define CACHESIZE (512 * 1024)

// 1M bytes
//#define CACHESIZE (1 * 1024 * 1024)

// 2M bytes
//#define CACHESIZE (2 * 1024 * 1024)

void usage(const char *commandname)
{
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	#ifdef USE_OMP
		printf("USAGE-> %s precision(in bits) [min_dim] [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s precision(in bits) [min_dim] [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#else
	#ifdef USE_OMP
		printf("USAGE-> %s precision(in bits) [num_threads] [Maximum seconds]\n", commandname);
	#else // USE_OMP
		printf("USAGE-> %s precision(in bits) [Maximum seconds]\n", commandname);
	#endif // USE_OMP
#endif
}

#ifdef USE_GMP

//int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec)
int matmulloop_mpf(long int start_dim, long int end_dim, long int dim_step, long int maxsec, long int opt_dim_flag, unsigned long prec, long int min_dim)
{
	long int dim;
	long int i, j, end_flag;
	long int num_addsub, num_mul;
	double iteration, etime, stime, mflops;
	MPFMatrix da, db, dc, dc_long;
	mpf_t tmp, relerr[3];

	mpf_init2(tmp, prec);
	mpf_init2(relerr[0], prec);
	mpf_init2(relerr[1], prec);
	mpf_init2(relerr[2], prec);

	for(dim = start_dim; dim <= end_dim; dim += dim_step)
	{
		da = init2_mpfmatrix(dim, dim, prec);
		db = init2_mpfmatrix(dim, dim, prec);
		dc = init2_mpfmatrix(dim, dim, prec);
		dc_long = init2_mpfmatrix(dim, dim, (unsigned long)(prec + prec / 2));

		for(i = 0; i < dim; i++)
		{
			for(j = 0; j < dim; j++)
			{
//				set_mpfmatrix_ij(da, i, j, (i + j + 1) * sqrt(5.0));
				mpf_sqrt_ui(tmp, 5UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(i + j + 1));
				set_mpfmatrix_ij(da, i, j, tmp);

//				set_mpfmatrix_ij(db, i, j, (dim - i) * sqrt(3.0));
				mpf_sqrt_ui(tmp, 3UL);
				mpf_mul_ui(tmp, tmp, (unsigned long)(dim - i));
				set_mpfmatrix_ij(db, i, j, tmp);

				mpf_sqrt_ui(tmp, 2UL);
				set_mpfmatrix_ij(dc, i, j, tmp);
			}
		}

		iteration = 1.0;
		do{
			//stime = get_secv();
			stime = get_real_secv();
#ifdef USE_STRASSEN
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_mpfmatrix_strassen();
//				mul_mpfmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_mpfmatrix_strassen(dc, da, db, min_dim);
//				_bncomp_mul_mpfmatrix_strassen_nonrec(dc, da, db, min_dim);
				_bncomp_get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_mpfmatrix_strassen();
//				mul_mpfmatrix_strassen(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_mpfmatrix_strassen(dc, da, db, min_dim);
				get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_STRASSEN_PADDING
			for(i = 0; i < iteration; i++)
			{
#ifdef USE_OMP
				_bncomp_reset_num_mul_mpfmatrix_strassen();
//				mul_mpfmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				_bncomp_mul_mpfmatrix_strassen_odd_padding(dc, da, db, min_dim);
				_bncomp_get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
#else // USE_OMP
				reset_num_mul_mpfmatrix_strassen();
//				mul_mpfmatrix_strassen_odd_padding(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				mul_mpfmatrix_strassen_odd_padding(dc, da, db, min_dim);
				get_num_mul_mpfmatrix_strassen(&num_addsub, &num_mul);
#endif // USE_OMP
			}

#elif USE_BLOCK
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_mpfmatrix_block(dc, da, db, min_dim);
#else // USE_OMP
//			for(i = 0; i < iteration; i++) mul_mpfmatrix_block(dc, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
			for(i = 0; i < iteration; i++) mul_mpfmatrix_block(dc, da, db, min_dim);
#endif // USE_OMP
#else
			num_addsub = da->row_dim * dc->row_dim * dc->col_dim;
			num_mul = da->row_dim * dc->row_dim * dc->col_dim;
#ifdef USE_OMP
			for(i = 0; i < iteration; i++) _bncomp_mul_mpfmatrix_simple(dc, da, db);
#else // USE_OMP
			for(i = 0; i < iteration; i++) mul_mpfmatrix_simple(dc, da, db);
#endif // USE_OMP
#endif
			//etime = get_secv() - stime;
			etime = get_real_secv() - stime;
			iteration *= 2.0;
		} while(etime < 2);

		// get relative errors
#ifdef USE_OMP
		_bncomp_mul_mpfmatrix_strassen(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
#else // USE_OMP
		mul_mpfmatrix_strassen(dc_long, da, db, _BNC_DEFAULT_MIN_DIM_STRASSEN);
#endif // USE_OMP
//		mul_mpfmatrix_simple(dc_long, da, db);
		relerr3_mpfmatrix(relerr[0], relerr[1], relerr[2], dc, dc_long, 0);

		etime /= iteration / 2;

//		mflops = (double)dim * (double)dim * (double)dim * 2 / etime / 1000.0 / 1000.0;
		mflops = (double)(num_addsub + num_mul) / etime / 1000.0 / 1000.0;
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / dim / dim / dim) * 1000 * 1000, mflops);
		//printf("[%5d bits] %5d x %5d: %9.5f sec (%8.5f micro-sec/mul) %f MFlops", prec, dim, dim, etime, (etime / (double)num_mul) * 1000 * 1000, mflops);
		printf("[%5ld bits] %5ld x %5ld: %9.5f sec [mul]%ld [addsub]%ld", prec, dim, dim, etime, num_mul, num_addsub);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[0]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[1]);
		printf(" "); mpf_out_str(stdout, 10, 3, relerr[2]);// printf("\n");

		if(opt_dim_flag == 1)
			printf(" <-- Optimal dimension %+ld", dim - (end_dim + start_dim) / 2);
		printf("\n");

		free_mpfmatrix(da);
		free_mpfmatrix(db);
		free_mpfmatrix(dc);
		free_mpfmatrix(dc_long);

		// exceed max. comp. time
		if(etime > maxsec)
		{
			end_flag = 1;
			break;
		}

	}

	mpf_clear(tmp);
	mpf_clear(relerr[0]);
	mpf_clear(relerr[1]);
	mpf_clear(relerr[2]);

	return end_flag;
}
#endif // USE_GMP

int main(int argc, char *argv[])
{
	int num_threads = 1;
	long int dim, idim, idim_half, opt_dim, end_flag, min_dim = _BNC_DEFAULT_MIN_DIM_STRASSEN;
	long int cachesize = 128, maxsec = 1200;
	unsigned long prec;
	if(argc <= 1)
	{
		usage(argv[0]);
		return 0;
	}
	else if(argc >= 2)
	{
		prec = atol(argv[1]);
		if(prec <= 0)
		{
			printf("Invalid precision in bit! (%ld bits)\n", prec);
			return -1;
		}
#if defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
		if(argc >= 3)
		{
			min_dim = atol(argv[2]);
			if(min_dim < _BNC_DEFAULT_MIN_DIM_STRASSEN)
			{
				printf("Warning: Too small min_dim (%ld < %d)\n", min_dim, _BNC_DEFAULT_MIN_DIM_STRASSEN);
				//return -1;
			}
#ifdef USE_OMP
			if(argc >= 4)
			{
				num_threads = atoi(argv[3]);
				if(num_threads < 1)
				{
					printf("num_threads is 1\n");
				}
			}
			if(argc >= 5)
			{
				maxsec = atol(argv[4]);
				if(maxsec < 0)
				{
					printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
					return -1;
				}
			}
#else // USE_OMP
			if(argc >= 4)
			{
				maxsec = atol(argv[3]);
				if(maxsec < 0)
				{
					printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
					return -1;
				}
			}
#endif // USE_OMP
		}
#else // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
#ifdef USE_OMP
		if(argc >= 3)
		{
			num_threads = atoi(argv[2]);
			if(num_threads < 1)
			{
				printf("num_threads is 1\n");
			}
		}
		if(argc >= 4)
		{
			maxsec = atol(argv[3]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#else // USE_OMP
		if(argc >= 3)
		{
			maxsec = atol(argv[2]);
			if(maxsec < 0)
			{
				printf("Invalid Maximum seconds! (%ld seconds)\n", maxsec);
				return -1;
			}
		}
#endif // USE_OMP
#endif // defined(USE_STRASSEN) || defined(USE_STRASSEN_PADDING) || defined(USE_BLOCK)
	}

	set_bnc_default_prec(prec);
	printf("Maxsec: %ld\n", maxsec);
    bnc_print_env_all();
#ifdef USE_OMP
	set_bncomp_num_threads(num_threads);
	printf("OpenMP #threads = %d\n", omp_get_num_threads());
#endif
	printf("------------------ Benchmark Test using Matrix Multiplication -----------------\n");

//	for(idim = 32; idim <= 16384; idim *= 2)
	//for(idim = 2; idim <= 2048; idim *= 2)
	for(idim = min_dim; idim < 32768; idim *= 2)
	{
		end_flag = 0;

		end_flag = matmulloop_mpf(idim - 1, idim + 1, 1, maxsec, 0, prec, min_dim);

//		end_flag = matmulloop_mpf(idim - 1, idim + 1, 1, maxsec, 0, prec);
		idim_half = 3 * idim / 2;

		if(idim_half >= min_dim)
			end_flag = matmulloop_mpf(idim_half - 1, idim_half + 1, 1, maxsec, 0, prec, min_dim);

//		if((idim <= opt_dim) && (opt_dim <= idim * 2))
//			end_flag = matmulloop_mpf(opt_dim - 5, opt_dim + 5, 1, maxsec, 1, prec, min_dim);

		if(end_flag == 1)
			break;

	}
	printf("------------------------------------ END --------------------------------------\n");
}

