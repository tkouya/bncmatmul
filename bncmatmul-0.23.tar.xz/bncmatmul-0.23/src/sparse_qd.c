/********************************************************************************/
/*                                                                              */
/* sparse_qd.c : Sparse Matrix and Vector Library (QD Precision)                */
/* Copyright (c) 2024 Tomonori Kouya, All rights reserved.                      */
/*                                                                              */
/* Version 0.2 2024-08-02 : Append Ozaki scheme for SpMV                        */
/* Version 0.1 2024-04-23 : Create sparse_qd.c from sparse_qd.c                 */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bncsparse.h"

//#ifdef USE_GMP
#ifdef USE_QDLINEAR

/* Sparse matrix struct */
/* Example:             */
/*      0 1 2 3 4       */
/* A = [a 0 b c 0]0     */
/*     [0 d 0 0 0]1     */
/*     [0 e f 0 0]2     */
/*     [0 0 0 g 0]3     */
/*     [0 0 h 0 i]4     */
/*                      */
/* <--> element = [a b c d e f g h i] */
/*      row_dim = 5, col_dim = 5 */
/*      nzero_index[0] = [0 2 3] */
/*      nzero_index[1] = [4]     */
/*      nzero_index[2] = [1 2]   */
/*      nzero_index[3] = [3]     */
/*      nzero_index[4] = [2 4]   */
/*      nzero_col_dim[0] = 3 */
/*      nzero_col_dim[1] = 1 */
/*      nzero_col_dim[2] = 2 */
/*      nzero_col_dim[3] = 1 */
/*      nzero_col_dim[4] = 2 */
/*      nzero_total_num = 9  */
/*	    zero_element = 0UL   */

/* initialize QDRSMatrix */
QDRSMatrix init_qdrsmatrix(long int row_dim, long int *nzero_col_dim, long int nzero_total_num)
{
	QDRSMatrix ret;
	long int i, j;

	ret = (QDRSMatrix)malloc(sizeof(qdrsmatrix));
	if(ret == NULL)
	{
		fprintf(stderr, "Cannot allocate QDRSMatrix\n");
		return ret;
	}
	
	if((row_dim < 0) || (nzero_total_num < 0))
	{
		fprintf(stderr, "Illigal nzero values\n");
		return NULL;
	}

	ret->row_dim = row_dim;
	ret->col_dim = row_dim; // Square matrix only
	ret->nzero_total_num = nzero_total_num;

	/* allocate nzero_index */
	//printf("%ld %ld %ld %ld\n", ret->row_dim, ret->col_dim, ret->nzero_total_num, sizeof(long int *) * row_dim);
	// ret->nzero_col_dim = (long int *)malloc(sizeof(long int *) * row_dim);
	// ret->nzero_row_dim = (long int *)malloc(sizeof(long int *) * ret->col_dim);
	// ret->nzero_index = (long int **)malloc(sizeof(long int *) * row_dim);
	// Fix it!: 2024-04-25(Thu) T.Kouya
	ret->nzero_col_dim = (long int *)calloc(ret->row_dim, sizeof(long int));
	ret->nzero_row_dim = (long int *)calloc(ret->col_dim, sizeof(long int));
	ret->real_nzero_col_dim = (long int *)calloc(ret->row_dim, sizeof(long int));
	ret->nzero_index = (long int **)calloc(ret->row_dim, sizeof(long int *));

	if(ret->nzero_index == NULL)
	{
		fprintf(stderr, "Cannot allocate QDRSMatrix(nzero_index!)\n");
		return NULL;
	}

	// real_nzero_total_num := real_nzero_col_dim[0] + ... + real_nzero_col_dim[nzero_]
	ret->real_nzero_total_num = 0;
	for(i = 0; i < row_dim; i++)
	{
		if(nzero_col_dim[i] < 0)
		{
			fprintf(stderr, "Illigal nzero values(nzero_col_dim[%ld])\n", i);
			return NULL;
		}
		ret->nzero_col_dim[i] = nzero_col_dim[i];
		// alignment for SIMD
		ret->real_nzero_col_dim[i] = (long int)ceil((double)(nzero_col_dim[i]) / (double)_BNC_D_WIDTH) * _BNC_D_WIDTH;
		//ret->nzero_index[i] = (long int *)malloc(sizeof(long int) * nzero_col_dim[i]);
		ret->nzero_index[i] = (long int *)calloc(nzero_col_dim[i], sizeof(long int));
		if(ret->nzero_index[i] == NULL)
		{
			fprintf(stderr, "Cannot allocate QDRSMatrix(nzero_index[%ld]!)\n", i);
			return NULL;
		}
		for(j = 0; j < nzero_col_dim[i]; j++)
			ret->nzero_index[i][j] = EMPTY;

		ret->real_nzero_total_num += ret->real_nzero_col_dim[i];
	}
	
	/* allocate element */
	// ret->element[0] = (double *)calloc(nzero_total_num, sizeof(double));
	// ret->element[1] = (double *)calloc(nzero_total_num, sizeof(double));
	// ret->element[2] = (double *)calloc(nzero_total_num, sizeof(double));
	// ret->element[3] = (double *)calloc(nzero_total_num, sizeof(double));
	ret->element[0] = (double *)BNC_CALLOC(ret->real_nzero_total_num, sizeof(double));
	ret->element[1] = (double *)BNC_CALLOC(ret->real_nzero_total_num, sizeof(double));
	ret->element[2] = (double *)BNC_CALLOC(ret->real_nzero_total_num, sizeof(double));
	ret->element[3] = (double *)BNC_CALLOC(ret->real_nzero_total_num, sizeof(double));

	if((ret->element[0] == NULL) || (ret->element[1] == NULL) || (ret->element[2] == NULL) || (ret->element[3] == NULL))
	{
		fprintf(stderr, "Cannot allocate QDRSMatrix(element!)\n");
		return NULL;
	}

#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d zero4;

	zero4 = _mm256_setzero_pd();
	for(i = 0; i < ret->real_nzero_total_num; i += _BNC_D_WIDTH)
	{
		_mm256_store_pd(&(ret->element[0][i]), zero4);
		_mm256_store_pd(&(ret->element[1][i]), zero4);
		_mm256_store_pd(&(ret->element[2][i]), zero4);
		_mm256_store_pd(&(ret->element[3][i]), zero4);
	}
#elif defined(__AVX512F__) // __AVX512F__
	__m512d zero8;

	zero8 = _mm512_setzero_pd();
	for(i = 0; i < ret->real_nzero_total_num; i += _BNC_D_WIDTH)
	{
		_mm512_store_pd(&(ret->element[0][i]), zero8);
		_mm512_store_pd(&(ret->element[1][i]), zero8);
		_mm512_store_pd(&(ret->element[2][i]), zero8);
		_mm512_store_pd(&(ret->element[3][i]), zero8);
	}
#elif defined(__ARM_NEON) // ARM Neon
	float64x2_t zero2;

	zero2 = vdupq_n_f64(0.0);
	for(i = 0; i < ret->real_nzero_total_num; i += 2)
	{
		vst1q_f64(&(ret->element[0][i]), zero2);
		vst1q_f64(&(ret->element[1][i]), zero2);
		vst1q_f64(&(ret->element[2][i]), zero2);
		vst1q_f64(&(ret->element[3][i]), zero2);
	}


#else // __AVX2__

	// element := 0
	//for(i = 0; i < nzero_total_num; i++)
	for(i = 0; i < ret->real_nzero_total_num; i++)
	{
		ret->element[0][i] = 0.0;
		ret->element[1][i] = 0.0;
		ret->element[2][i] = 0.0;
		ret->element[3][i] = 0.0;
	}
#endif // __AVX2__

	return ret;
}

/* Clear QDRSMatrix */
void free_qdrsmatrix(QDRSMatrix mat)
{
	long int i;

//	free(mat->element);
	free(mat->nzero_col_dim);
	free(mat->nzero_row_dim);
	free(mat->real_nzero_col_dim);

	for(i = 0; i < mat->row_dim; i++)
		free(mat->nzero_index[i]);

	free(mat->nzero_index);

	//free(mat);
	if(mat->element[0] != NULL)
		free(mat->element[0]);
	if(mat->element[1] != NULL)
		free(mat->element[1]);
	if(mat->element[2] != NULL)
		free(mat->element[2]);
	if(mat->element[3] != NULL)
		free(mat->element[3]);

	free(mat);
}

/* set nzero_row_dim automatically */
void set_nzero_row_dim_qd(QDRSMatrix mat)
{
	long int i, j;

	/* all clear */
	for(i = 0; i < mat->col_dim; i++)
		mat->nzero_row_dim[i] = 0;

	/* search */
	for(i = 0; i < mat->row_dim; i++)
	{
		for(j = 0; j < mat->nzero_col_dim[i]; j++)
			mat->nzero_row_dim[*(mat->nzero_index[i] + j)]++;
	}
}

/* Print QDRSMatrix */
void print_qdrsmatrix(QDRSMatrix mat)
{
	long int i, j, total_index;
	qdfloat tmp;

	if(mat == NULL)
		fprintf(stderr, "ERROR!\n");

	total_index = 0;
	for(i = 0; i < mat->row_dim; i++)
	{
		// Fix!: 2011-08-29 by T.Kouya
		if(mat->nzero_col_dim[i] >= 1)
		{
			printf("%5ld: ", i);
			for(j = 0; j < mat->real_nzero_col_dim[i]; j++)
			{
				// printf("%ld->%f, ", mat->nzero_index[i][j], mat->element[total_index++]);
				if(j < mat->nzero_col_dim[i])
				{
					printf("%ld-> ", mat->nzero_index[i][j]);
					//mpf_out_str(stdout, 10, 0, mat->element[total_index++]);
					tmp.val[0] = mat->element[0][total_index + j];
					tmp.val[1] = mat->element[1][total_index + j];
					tmp.val[2] = mat->element[2][total_index + j];
					tmp.val[3] = mat->element[3][total_index + j];
					rqd_out_str(tmp.val);
					if(j != (mat->nzero_col_dim[i] - 1)) printf(", ");
				}
				total_index++;
			}
			printf("\n");
		}
		total_index += mat->real_nzero_col_dim[i];
	}
	return;
}

/* initialize and substitute QDRSMatrix from QDMatrix */
QDRSMatrix init_set_qdrsmatrix_qdmatrix(QDMatrix org_mat)
{
	long int i, j;
	long int nzero_total_num, total_index, j_index;
	long int *ptr_nzero_col_dim;
	QDRSMatrix ret;
	qdfloat tmp;

	/* initialize variables */
	nzero_total_num = 0;

	ptr_nzero_col_dim = (long int *)malloc((size_t)(sizeof(long int) * (org_mat->row_dim)));

	/* initialize num_col as numbers of nonzero element in each row */
	if(ptr_nzero_col_dim == NULL)
	{
		fprintf(stderr, "Cannot allocate num_col(size %ld)\n", sizeof(long int) * (org_mat->row_dim));
		return NULL;
	}

	/* Read org_mat (1st) */
	for(i = 0; i < org_mat->row_dim; i++)
	{
		*(ptr_nzero_col_dim + i) = 0;
		for(j = 0; j < org_mat->col_dim; j++)
		{
			//if(mpf_cmp_ui(get_mpfmatrix_ij(org_mat, i, j), 0UL) != 0)
			if(rqd_cmp_ui(get_qdmatrix_ij(org_mat, i, j), 0UL) != 0)
			{
				/* get nzero_row_dim, nzero_col_dim, nzero_total_num */
				nzero_total_num++;
				*(ptr_nzero_col_dim + i) += 1;
			}
		}
	}

	// initialize
	ret = init_qdrsmatrix(org_mat->row_dim, ptr_nzero_col_dim, nzero_total_num); // , org_mat->prec);

	/* Read org_mat (2nd) */
	total_index = 0;
	for(i = 0; i < ret->row_dim; i++)
	{
		j_index = 0;
		for(j = 0; j < ret->col_dim; j++)
		{
			//if(mpf_cmp_ui(get_mpfmatrix_ij(org_mat, i, j), 0UL) != 0)
			if(rqd_cmp_ui(get_qdmatrix_ij(org_mat, i, j), 0UL) != 0)
			{
				ret->nzero_index[i][j_index] =  j;
				//mpf_set(*(ret->element + total_index), get_mpfmatrix_ij(org_mat, i, j));
				rqd_set(tmp.val, get_qdmatrix_ij(org_mat, i, j));
				ret->element[0][total_index + j_index] = tmp.val[0];
				ret->element[1][total_index + j_index] = tmp.val[1];
				ret->element[2][total_index + j_index] = tmp.val[2];
				ret->element[3][total_index + j_index] = tmp.val[3];

				//total_index += 1;
				j_index += 1;
			}
			total_index += ret->real_nzero_col_dim[i];
		}
	}

	free(ptr_nzero_col_dim);

	return ret;
}

// 2024-08-02(Fri) T.Kouya
/* get the DRSMatrix ij-element */
void get_qdrsmatrix_ij(double ret[QDSIZE], QDRSMatrix mat, long int row_index, long int col_index)
{
	long int i, j, total_index;

	if((row_index < 0) || (row_index >= mat->row_dim) || (col_index < 0) || (col_index >= mat->col_dim))
	{
		fprintf(stderr, "Warning: row_index(%ld) or col_index(%ld) is illegal!\n", row_index, col_index);
		rqd_set0(ret);
		//return mat->zero_element;
		return;
	}

	// finding mat_ij element
	if(mat->nzero_col_dim[row_index] >= 1)
	{
		total_index = 0;
		for(i = 0; i < row_index; i++)
			total_index += mat->real_nzero_col_dim[i];
			//total_index += mat->nzero_col_dim[i];

		for(j = 0; j < mat->nzero_col_dim[row_index] ; j++)
		{
			// Find!
			if(mat->nzero_index[row_index][j] == col_index)
			{
				//return mat->element[total_index];
				ret[0] = mat->element[0][total_index];
				ret[1] = mat->element[1][total_index];
				ret[2] = mat->element[2][total_index];
				ret[3] = mat->element[3][total_index];

				return;
			}
			
			total_index++;
		}
	}

	// Not found -> return 0
	//return mat->zero_element;
	rqd_set0(ret);
	return;
}

// 2024-08-04 (Sun) T.Kouya
/* set the QDRSMatrix ij-element */
void set_qdrsmatrix_ij(QDRSMatrix mat, long int row_index, long int col_index, double val[QDSIZE])
{
	long int i, j, total_index;

	if((row_index < 0) || (row_index >= mat->row_dim) || (col_index < 0) || (col_index >= mat->col_dim))
	{
		fprintf(stderr, "Warning: row_index(%ld) or col_index(%ld) is illegal!\n", row_index, col_index);
		//return mat->zero_element;
		return;
	}

	// finding mat_ij element
	if(mat->nzero_col_dim[row_index] >= 1)
	{
		total_index = 0;
		for(i = 0; i < row_index; i++)
			total_index += mat->real_nzero_col_dim[i];
			//total_index += mat->nzero_col_dim[i];

		for(j = 0; j < mat->nzero_col_dim[row_index] ; j++)
		{
			// Find!
			if(mat->nzero_index[row_index][j] == col_index)
			{
				//return mat->element[total_index];
				//ret[0] = mat->element[0][total_index];
				//ret[1] = mat->element[1][total_index];
				mat->element[0][total_index] = val[0];
				mat->element[1][total_index] = val[1];
				mat->element[2][total_index] = val[2];
				mat->element[3][total_index] = val[3];

				return;
			}
			
			total_index++;
		}
	}

	return;
}

// 2024-08-02 (Fri) T.Kouya
// init and set QDRSMatrix
QDRSMatrix init_set_qdrsmatrix(QDRSMatrix org_sp)
{
	QDRSMatrix ret;
	double ddtmp[QDSIZE];
	long int org_sp_total_index, total_index, i, j;

    //printf("row_dim, nzero_total_num = %ld, %ld\n", org_sp->row_dim, org_sp->nzero_total_num);
    ret = init_qdrsmatrix(org_sp->row_dim, org_sp->nzero_col_dim, org_sp->nzero_total_num);
    //printf("init_qdrsmatrix!\n");

	 // Real total number of non-zero elements
	ret->real_nzero_total_num = org_sp->real_nzero_total_num;

    // copy nzero_index
	for(i = 0; i < org_sp->row_dim; i++)
	{
		// Real numbers of non-zero elements in i-th row
		ret->real_nzero_col_dim[i] = org_sp->real_nzero_col_dim[i];

		for(j = 0; j < org_sp->nzero_col_dim[i]; j++)
			ret->nzero_index[i][j] = org_sp->nzero_index[i][j];
	}

	// copy values
    for(total_index = 0; total_index < org_sp->real_nzero_total_num; total_index++)
	{
		ret->element[0][total_index] = org_sp->element[0][total_index];
		ret->element[1][total_index] = org_sp->element[1][total_index];
		ret->element[2][total_index] = org_sp->element[2][total_index];
		ret->element[3][total_index] = org_sp->element[3][total_index];
	}

	return ret;
}

// 2024-08-01(Thu) T.Kouya
// spmat := 0
void set0_qdrsmatrix(QDRSMatrix spmat)
{
	long int index;

	// substitution
	for(index = 0; index < spmat->real_nzero_total_num; index++)
	{
		spmat->element[0][index] = (double)0.0;
		spmat->element[1][index] = (double)0.0;
		spmat->element[2][index] = (double)0.0;
		spmat->element[3][index] = (double)0.0;
	}

	return;
}

// 2024-12-03(Tue) T.Kouya
// ret := spmat_a
void subst_qdrsmatrix(QDRSMatrix ret, QDRSMatrix spmat_a)
{
	long int i, j, total_index;
/* <--> element = [a b c d e f g h i] */
/*      row_dim = 5, col_dim = 5 */
/*      nzero_index[0] = [0 2 3] */
/*      nzero_index[1] = [4]     */
/*      nzero_index[2] = [1 2]   */
/*      nzero_index[3] = [3]     */
/*      nzero_index[4] = [2 4]   */
/*      nzero_col_dim[0] = 3 */
/*      nzero_col_dim[1] = 1 */
/*      nzero_col_dim[2] = 2 */
/*      nzero_col_dim[3] = 1 */
/*      nzero_col_dim[4] = 2 */
/*      nzero_total_num = 9  */
/*      zero_element = 0.0   */

	// check parameters
	if(ret->nzero_total_num != spmat_a->nzero_total_num)
	{
		fprintf(stderr, "ERROR(subst_qdrsmatrix): mismatched nzero_total_nums! (%ld != %ld)\n", ret->nzero_total_num, spmat_a->nzero_total_num);
		return; // -1;
	}
	if((ret->row_dim != spmat_a->row_dim) || (ret->col_dim != spmat_a->col_dim))
	{
		fprintf(stderr, "ERROR(subst_qdrsmatrix): mismatched dimensions! ((%ld, %ld) != (%ld, %ld))\n", ret->row_dim, ret->col_dim, spmat_a->row_dim, spmat_a->col_dim);
		return; // -2;
	}

	// Real total number of non-zero elements
	ret->real_nzero_total_num = spmat_a->real_nzero_total_num;

    // copy nzero_index
	for(i = 0; i < spmat_a->row_dim; i++)
	{
		// Real numbers of non-zero elements in i-th row
		ret->real_nzero_col_dim[i] = spmat_a->real_nzero_col_dim[i];

		for(j = 0; j < spmat_a->nzero_col_dim[i]; j++)
			ret->nzero_index[i][j] = spmat_a->nzero_index[i][j];
	}

	// substitution
#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	for(total_index = 0; total_index < ret->real_nzero_total_num; total_index += _BNC_D_WIDTH)
	{
		_mm256_store_pd(&(ret->element[0][total_index]), _mm256_load_pd(&(spmat_a->element[0][total_index])));
		_mm256_store_pd(&(ret->element[1][total_index]), _mm256_load_pd(&(spmat_a->element[1][total_index])));
		_mm256_store_pd(&(ret->element[2][total_index]), _mm256_load_pd(&(spmat_a->element[2][total_index])));
		_mm256_store_pd(&(ret->element[3][total_index]), _mm256_load_pd(&(spmat_a->element[3][total_index])));
	}

#elif defined(__AVX512F__) // __AVX512F__
	for(total_index = 0; total_index < ret->real_nzero_total_num; total_index += _BNC_D_WIDTH)
	{
		_mm512_store_pd(&(ret->element[0][total_index]), _mm512_load_pd(&(spmat_a->element[0][total_index])));
		_mm512_store_pd(&(ret->element[1][total_index]), _mm512_load_pd(&(spmat_a->element[1][total_index])));
		_mm512_store_pd(&(ret->element[2][total_index]), _mm512_load_pd(&(spmat_a->element[2][total_index])));
		_mm512_store_pd(&(ret->element[3][total_index]), _mm512_load_pd(&(spmat_a->element[3][total_index])));
	}

#elif defined(__ARM_NEON) // ARM Neon
	for(total_index = 0; total_index < ret->real_nzero_total_num; total_index += 2)
	{
		vst1q_f64(&(ret->element[0][total_index]), vld1q_f64(&(spmat_a->element[0][total_index])));
		vst1q_f64(&(ret->element[1][total_index]), vld1q_f64(&(spmat_a->element[1][total_index])));
		vst1q_f64(&(ret->element[2][total_index]), vld1q_f64(&(spmat_a->element[2][total_index])));
		vst1q_f64(&(ret->element[3][total_index]), vld1q_f64(&(spmat_a->element[3][total_index])));
	}



#else // others
	//memcpy(ret->element, spmat_a->element, sizeof(double) * spmat_a->nzero_total_num);
	//for(total_index = 0; total_index < ret->nzero_total_num; total_index++)
	for(total_index = 0; total_index < ret->real_nzero_total_num; total_index++)
	{
		ret->element[0][total_index] = spmat_a->element[0][total_index];
		ret->element[1][total_index] = spmat_a->element[1][total_index];
		ret->element[2][total_index] = spmat_a->element[2][total_index];
		ret->element[3][total_index] = spmat_a->element[3][total_index];
	}

#endif // __AVX2__

}


// 2024-08-01 T.Kouya
// init and set DRSMatrix from QDRSMatrix
DRSMatrix init_set_drsmatrix_qdrsmat(QDRSMatrix org_sp)
{
	DRSMatrix ret;
	double ddtmp[QDSIZE];
	long int org_sp_total_index, total_index, i, j;

    //printf("row_dim, nzero_total_num = %ld, %ld\n", org_sp->row_dim, org_sp->nzero_total_num);
    ret = init_drsmatrix(org_sp->row_dim, org_sp->nzero_col_dim, org_sp->nzero_total_num);
    //printf("init_qdrsmatrix!\n");

	// Real total number of non-zero elements
	ret->real_nzero_total_num = org_sp->real_nzero_total_num;

    // copy nzero_index
	for(i = 0; i < org_sp->row_dim; i++)
	{
		// Real numbers of non-zero elements in i-th row
		ret->real_nzero_col_dim[i] = org_sp->real_nzero_col_dim[i];

		for(j = 0; j < org_sp->nzero_col_dim[i]; j++)
			ret->nzero_index[i][j] = org_sp->nzero_index[i][j];
	}

	// copy values
    for(total_index = 0; total_index < org_sp->real_nzero_total_num; total_index++)
	{
		ret->element[total_index] = org_sp->element[0][total_index];
		//ret->element[1][total_index] = org_sp->element[1][total_index];
	}

	return ret;
}

#ifdef USE_GMP
// MPFRSMatrix -> QDRSMatrix
QDRSMatrix init_set_qdrsmatrix_mpfrsmatrix(MPFRSMatrix org_sp)
{
	QDRSMatrix ret;
	double tdtmp[QDSIZE];
	long int org_sp_total_index, total_index, i, j;

    //printf("row_dim, nzero_total_num = %ld, %ld\n", mpfa_sp->row_dim, mpfa_sp->nzero_total_num);
    ret = init_qdrsmatrix(org_sp->row_dim, org_sp->nzero_col_dim, org_sp->nzero_total_num);
    //printf("init_qdrsmatrix!\n");

    // MPFR -> DD
    total_index = 0;
	org_sp_total_index = 0;
	for(i = 0; i < ret->row_dim; i++)
	{
		for(j = 0; j < ret->nzero_col_dim[i]; j++)
		{
            mpf_get_qd(tdtmp, org_sp->element[org_sp_total_index + j]);
            ret->element[0][total_index + j] = tdtmp[0];
            ret->element[1][total_index + j] = tdtmp[1];
            ret->element[2][total_index + j] = tdtmp[2];
            ret->element[3][total_index + j] = tdtmp[3];

            ret->nzero_index[i][j] = org_sp->nzero_index[i][j];
			//total_index++;
		}
		total_index += ret->real_nzero_col_dim[i];
		org_sp_total_index += org_sp->nzero_col_dim[i];
	}
    //print_qdrsmatrix(ret);

	return ret;
}
#endif // USE_GMP

/* Get variables to initialize QDRSMatrix */
int get_vars_qdrsmatrix_fname(long int *ptr_row_dim, long int **ptr_nzero_col_dim, long int *ptr_nzero_total_num, const char *fname)
{
	FILE *fp;
	static char line_buf[LINE_BUF_LEN];
	long int i, j;
	long int row_index, col_index, max_row_index, max_col_index, nzero_total_num;
	long int ele_index;

	/* file open */
	fp = fopen(fname, "r");
	if(fp == NULL)
	{
		fprintf(stderr, "Cannot open %s\n", fname);
		return ERROR;
	}

	/* initialize variables */
	nzero_total_num = 0;
	max_row_index = 0;
	max_col_index = 0;

	/* Read file (1st) */
	while(fgets(line_buf, LINE_BUF_LEN - 1, fp) != NULL)
	{
		/* get row_index and col_index */
		sscanf(line_buf, "%ld %ld", &row_index, &col_index);

		/* get nzero_row_dim, nzero_col_dim, nzero_total_num */
		nzero_total_num++;
		//row_index--; col_index--;
		if(max_row_index < row_index)
			max_row_index = row_index;
		if(max_col_index < col_index)
			max_col_index = col_index;
	}

//	printf("Total URIs: %ld\n", max_row_index + 1);

	/* initialize num_col as numbers of nonzero element in each row */
	*ptr_row_dim = max_row_index + 1;
	*ptr_nzero_total_num = nzero_total_num;
	*ptr_nzero_col_dim = (long int *)malloc((size_t)(sizeof(long int) * (max_row_index + 1)));
	if(*ptr_nzero_col_dim == NULL)
	{
		fprintf(stderr, "Cannot allocate num_col(size %ld)\n", sizeof(long int) * (max_row_index + 1));
		return ERROR;
	}

	/* Read file (2nd) */
	for(i = 0; i <= max_row_index; i++)
		*(*ptr_nzero_col_dim + i) = 0;

	rewind(fp);
	while(fgets(line_buf, LINE_BUF_LEN - 1, fp) != NULL)
	{
		/* get row_index, col_index, element */
		sscanf(line_buf, "%ld %ld", &row_index, &col_index);
		//fprintf(stderr, "%ld %ld\n", row_index--, col_index--);
		*(*ptr_nzero_col_dim + row_index) += 1;
	}

	fclose(fp);

	return SUCCESS;
}

// 2025-07-17(Thu)
#ifdef USE_IMKL
// ret := (sparse_matrix_t)mat
void convert_indeces_qdrsmatrix_mkl_csrmat(MKL_INT *ret_i_csr_start, MKL_INT *ret_i_csr_end, MKL_INT *ret_j_csr, QDRSMatrix mat)
{
	long int i, j, total_index;
    //int *i_mat_csr, *j_mat_csr, row_dim = (int)mat->row_dim;
    int row_dim = (int)mat->row_dim;

	// convert our CSR to intel math kernel csr format
	//i_mat_csr = (int *)calloc(mat->row_dim + 1, sizeof(int));
	//j_mat_csr = (int *)calloc(mat->real_nzero_total_num, sizeof(int));
	ret_i_csr_start = (MKL_INT *)calloc(mat->row_dim, sizeof(MKL_INT));
	ret_i_csr_end = (MKL_INT *)calloc(mat->row_dim, sizeof(MKL_INT));
	ret_j_csr = (MKL_INT *)calloc(mat->real_nzero_total_num, sizeof(MKL_INT));

    total_index = 0;
	for(i = 0; i < row_dim; i++)
	{
		ret_i_csr_start[i] = (MKL_INT)total_index;
		//if(a->nzero_col_dim[i] >= 1)
		if(mat->real_nzero_col_dim[i] >= 1)
		{
			for(j = 0; j < mat->nzero_col_dim[i]; j++)
			{
				ret_j_csr[total_index] = mat->nzero_index[i][j];
				total_index++;
			}
    		//ret_i_csr_end[i] = (MKL_INT)total_index - 1;
			// embed gap among nzero_col_dim and real_nzero_col_dim
			for(j = mat->nzero_col_dim[i]; j < mat->real_nzero_col_dim[i]; j++)
			{
				ret_j_csr[total_index] = mat->nzero_index[i][mat->nzero_col_dim[i] - 1] + (j + 1 - mat->nzero_col_dim[i]);
				total_index++;
			}
		}
		ret_i_csr_end[i] = (MKL_INT)total_index;
        //ret_i_csr_end[i] = ret_i_csr_start[i] + mat->real_nzero_col_dim[i];
    }
}
// ret := (sparse_matrix_t)mat
sparse_status_t convert_qdrsmatrix_mkl_csrmat(sparse_matrix_t *ret[QDSIZE], MKL_INT *ret_i_csr_start, MKL_INT *ret_i_csr_end, MKL_INT *ret_j_csr, QDRSMatrix mat)
{
	//long int i, j, total_index;
    //int *i_mat_csr, *j_mat_csr, row_dim = (int)mat->row_dim;
    //int row_dim = (int)mat->row_dim;
    sparse_status_t ret_mkl[QDSIZE];

#if 0
	// convert our CSR to intel math kernel csr format
	//i_mat_csr = (int *)calloc(mat->row_dim + 1, sizeof(int));
	//j_mat_csr = (int *)calloc(mat->real_nzero_total_num, sizeof(int));
	ret_i_csr_start = (MKL_INT *)calloc(mat->row_dim, sizeof(MKL_INT));
	ret_i_csr_end = (MKL_INT *)calloc(mat->row_dim, sizeof(MKL_INT));
	ret_j_csr = (MKL_INT *)calloc(mat->real_nzero_total_num, sizeof(MKL_INT));

    total_index = 0;
	for(i = 0; i < row_dim; i++)
	{
		ret_i_csr_start[i] = (MKL_INT)total_index;
		//if(a->nzero_col_dim[i] >= 1)
		if(mat->real_nzero_col_dim[i] >= 1)
		{
			for(j = 0; j < mat->nzero_col_dim[i]; j++)
			{
				ret_j_csr[total_index] = mat->nzero_index[i][j];
				total_index++;
			}
    		//ret_i_csr_end[i] = (MKL_INT)total_index - 1;
			// embed gap among nzero_col_dim and real_nzero_col_dim
			for(j = mat->nzero_col_dim[i]; j < mat->real_nzero_col_dim[i]; j++)
			{
				ret_j_csr[total_index] = mat->nzero_index[i][mat->nzero_col_dim[i] - 1] + (j + 1 - mat->nzero_col_dim[i]);
				total_index++;
			}
		}
		ret_i_csr_end[i] = (MKL_INT)total_index;
        //ret_i_csr_end[i] = ret_i_csr_start[i] + mat->real_nzero_col_dim[i];
    }
#endif // 0
	convert_indeces_qdrsmatrix_mkl_csrmat(ret_i_csr_start, ret_i_csr_end, ret_j_csr, mat);

	//i_mat_csr_end[row_dim] = mat->real_nzero_total_num;
	//mkl_cspblas_dcsrgemv("N", &row_dim, mat->element, i_mat_csr, j_mat_csr, vec->element, ret->element);
    ret_mkl[0] = mkl_sparse_d_create_csr(
        ret[0],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        ret_i_csr_start,
        ret_i_csr_end,
        ret_j_csr,
        mat->element[0]
    );
    ret_mkl[1] = mkl_sparse_d_create_csr(
        ret[1],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        ret_i_csr_start,
        ret_i_csr_end,
        ret_j_csr,
        mat->element[1]
    );
    ret_mkl[2] = mkl_sparse_d_create_csr(
        ret[2],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        ret_i_csr_start,
        ret_i_csr_end,
        ret_j_csr,
        mat->element[2]
    );
    ret_mkl[3] = mkl_sparse_d_create_csr(
        ret[3],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        ret_i_csr_start,
        ret_i_csr_end,
        ret_j_csr,
        mat->element[3]
    );

	//free(i_mat_csr); free(j_mat_csr);
    return (ret_mkl[0] & ret_mkl[1] & ret_mkl[2] & ret_mkl[3]);
}
// ret := (sparse_matrix_t)mat
sparse_status_t subst_qdrsmatrix_mkl_csrmat(sparse_matrix_t *ret[QDSIZE], MKL_INT *i_csr_start, MKL_INT *i_csr_end, MKL_INT *j_csr, QDRSMatrix mat)
{
	//long int i, j, total_index;
    //int *i_mat_csr, *j_mat_csr, row_dim = (int)mat->row_dim;
    //int row_dim = (int)mat->row_dim;
    sparse_status_t ret_mkl[QDSIZE];

	//i_mat_csr_end[row_dim] = mat->real_nzero_total_num;
	//mkl_cspblas_dcsrgemv("N", &row_dim, mat->element, i_mat_csr, j_mat_csr, vec->element, ret->element);
    ret_mkl[0] = mkl_sparse_d_create_csr(
        ret[0],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        i_csr_start,
        i_csr_end,
        j_csr,
        mat->element[0]
    );
    ret_mkl[1] = mkl_sparse_d_create_csr(
        ret[1],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        i_csr_start,
        i_csr_end,
        j_csr,
        mat->element[1]
    );
    ret_mkl[2] = mkl_sparse_d_create_csr(
        ret[2],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        i_csr_start,
        i_csr_end,
        j_csr,
        mat->element[2]
    );
    ret_mkl[3] = mkl_sparse_d_create_csr(
        ret[3],
        SPARSE_INDEX_BASE_ZERO,
        (MKL_INT)mat->row_dim,
        (MKL_INT)mat->col_dim,
        i_csr_start,
        i_csr_end,
        j_csr,
        mat->element[3]
    );

	//free(i_mat_csr); free(j_mat_csr);
    return (ret_mkl[0] & ret_mkl[1] & ret_mkl[2] & ret_mkl[3]);
}
#endif // USE_IMKL

/* Multiply QDRSMatrix * QDVector */
int mul_qdrsmatrix_qdvec(QDVector ret, QDRSMatrix mat, QDVector vec)
{
	long int i, j, total_index;
	//qdfloat tmp, mat_ij, vec_j, ret_i;
	double tmp[QDSIZE], mat_ij[QDSIZE], vec_j[QDSIZE], ret_i[QDSIZE];

	if((ret->dim < mat->col_dim) || (vec->dim != mat->col_dim))
	{
		fprintf(stderr, "Illegal dimension!\n");
		return ERROR;
	}

	total_index = 0;

#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d a4[QDSIZE], vb4[QDSIZE], tmp4[QDSIZE], tmp4_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE], vset[_BNC_D_WIDTH];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp4 = _mm256_setzero_pd();
		_bncavx2_set0_qd(tmp4);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		// jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		// jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a4[0]  = _mm256_load_pd(&(mat->element[0][total_index]));
			a4[1]  = _mm256_load_pd(&(mat->element[1][total_index]));
			a4[2]  = _mm256_load_pd(&(mat->element[2][total_index]));
			a4[3]  = _mm256_load_pd(&(mat->element[3][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[0][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[0][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[0][mat->nzero_index[i][j + 3]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[0] = _mm256_set_pd(
				vset[3], // vec->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[1][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[1][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[1][mat->nzero_index[i][j + 3]];
			//("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[1] = _mm256_set_pd(
				vset[3], // vec->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[2][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[2][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[2][mat->nzero_index[i][j + 3]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[2] = _mm256_set_pd(
				vset[3], // vec->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[3][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[3][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[3][mat->nzero_index[i][j + 3]];
			//printf("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[3] = _mm256_set_pd(
				vset[3], // vec->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			);

/*
			vb4[0] = _mm256_set_pd(
				vec->element[0][mat->nzero_index[i][j + 3]],
				vec->element[0][mat->nzero_index[i][j + 2]],
				vec->element[0][mat->nzero_index[i][j + 1]],
				vec->element[0][mat->nzero_index[i][j    ]]
			);
			vb4[1] = _mm256_set_pd(
				vec->element[1][mat->nzero_index[i][j + 3]],
				vec->element[1][mat->nzero_index[i][j + 2]],
				vec->element[1][mat->nzero_index[i][j + 1]],
				vec->element[1][mat->nzero_index[i][j    ]]
			);
			vb4[2] = _mm256_set_pd(
				vec->element[2][mat->nzero_index[i][j + 3]],
				vec->element[2][mat->nzero_index[i][j + 2]],
				vec->element[2][mat->nzero_index[i][j + 1]],
				vec->element[2][mat->nzero_index[i][j    ]]
			);
			vb4[3] = _mm256_set_pd(
				vec->element[3][mat->nzero_index[i][j + 3]],
				vec->element[3][mat->nzero_index[i][j + 2]],
				vec->element[3][mat->nzero_index[i][j + 1]],
				vec->element[3][mat->nzero_index[i][j    ]]
			);
*/
			//tmp4 = _mm256_fmadd_pd(a4, vb4, tmp4);
			_bncavx2_rqd_mul(tmp4_mul, a4, vb4);
			_bncavx2_rqd_add(tmp4, tmp4, tmp4_mul);

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//mat_vec_i = tmp4[0] + tmp4[1] + tmp4[2] + tmp4[3];
		_bncavx2_rqd_sum256d(mat_vec_i, tmp4);

		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i[0], mat->nzero_col_dim[i], jmax, jres);
/*
		col_dim = mat->nzero_col_dim[i];
		switch(jres)
		{
			case 1:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break; 

			case 2:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;	
			
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break; 

			case 3:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;	

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];				

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;	

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break; 
		}
		//printf("%ld mat_vec_i = %25.17e\n", i, mat_vec_i[0]);
*/
		set_qdvector_i(ret, i, mat_vec_i);
	}

#elif defined(__AVX512F__) // __AVX512F__
	__m512d a8[QDSIZE], vb8[QDSIZE], tmp8[QDSIZE], tmp8_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp8 = _mm512_setzero_pd();
		_bncavx512_set0_qd(tmp8);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		//jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a8[0] = _mm512_load_pd(&(mat->element[0][total_index]));
			a8[1] = _mm512_load_pd(&(mat->element[1][total_index]));
			a8[2] = _mm512_load_pd(&(mat->element[2][total_index]));
			a8[3] = _mm512_load_pd(&(mat->element[3][total_index]));

			vb8[0] = _mm512_set_pd(
				vec->element[0][mat->nzero_index[i][j + 7]],
				vec->element[0][mat->nzero_index[i][j + 6]],
				vec->element[0][mat->nzero_index[i][j + 5]],
				vec->element[0][mat->nzero_index[i][j + 4]],
				vec->element[0][mat->nzero_index[i][j + 3]],
				vec->element[0][mat->nzero_index[i][j + 2]],
				vec->element[0][mat->nzero_index[i][j + 1]],
				vec->element[0][mat->nzero_index[i][j    ]]
			);
			vb8[1] = _mm512_set_pd(
				vec->element[1][mat->nzero_index[i][j + 7]],
				vec->element[1][mat->nzero_index[i][j + 6]],
				vec->element[1][mat->nzero_index[i][j + 5]],
				vec->element[1][mat->nzero_index[i][j + 4]],
				vec->element[1][mat->nzero_index[i][j + 3]],
				vec->element[1][mat->nzero_index[i][j + 2]],
				vec->element[1][mat->nzero_index[i][j + 1]],
				vec->element[1][mat->nzero_index[i][j    ]]
			);
			vb8[2] = _mm512_set_pd(
				vec->element[2][mat->nzero_index[i][j + 7]],
				vec->element[2][mat->nzero_index[i][j + 6]],
				vec->element[2][mat->nzero_index[i][j + 5]],
				vec->element[2][mat->nzero_index[i][j + 4]],
				vec->element[2][mat->nzero_index[i][j + 3]],
				vec->element[2][mat->nzero_index[i][j + 2]],
				vec->element[2][mat->nzero_index[i][j + 1]],
				vec->element[2][mat->nzero_index[i][j    ]]
			);
			vb8[3] = _mm512_set_pd(
				vec->element[3][mat->nzero_index[i][j + 7]],
				vec->element[3][mat->nzero_index[i][j + 6]],
				vec->element[3][mat->nzero_index[i][j + 5]],
				vec->element[3][mat->nzero_index[i][j + 4]],
				vec->element[3][mat->nzero_index[i][j + 3]],
				vec->element[3][mat->nzero_index[i][j + 2]],
				vec->element[3][mat->nzero_index[i][j + 1]],
				vec->element[3][mat->nzero_index[i][j    ]]
			);

			//tmp8 = _mm512_fmadd_pd(a4, vb4, tmp4);
			_bncavx512_rqd_mul(tmp8_mul, a8, vb8);
			_bncavx512_rqd_add(tmp8, tmp8, tmp8_mul);

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//mat_vec_i = tmp4[0] + tmp4[1] + tmp4[2] + tmp4[3] + tmp4[4] + tmp4[5] + tmp4[6] + tmp4[7];
		_bncavx512_rqd_sum512d(mat_vec_i, tmp8);

/*
		col_dim = mat->nzero_col_dim[i];
		switch(jres)
		{
			case 1: 
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_col_dim[i] - 1];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break; 

			case 2:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break; 

			case 3:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break; 

			case 4:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 4]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 4]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 4]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 4]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break;

			case 5:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 5]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 5]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 5]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 5]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 4]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 4]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 4]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 4]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break;

			case 6:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 6]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 6]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 6]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 6]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 6]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 5]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 5]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 5]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 5]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 4]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 4]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 4]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 4]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break;

			case 7:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 7]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 7]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 7]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 7]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 7]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 6]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 6]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 6]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 6]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 6]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 5]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 5]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 5]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 5]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 4]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 4]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 4]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 4]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 3]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 2]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[2] = mat->element[2][total_index];
				mat_ij[3] = mat->element[3][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[2] = vec->element[2][mat->nzero_index[i][col_dim - 1]];
				vec_j[3] = vec->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
				break;
		}
*/
		set_qdvector_i(ret, i, mat_vec_i);
	}

#elif defined(__ARM_NEON) // ARM Neon
	float64x2_t a2[QDSIZE], vb2[QDSIZE], tmp2[QDSIZE], tmp4_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE], vset[2];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp2 = vdupq_n_f64(0.0);
		_bncneon_set0_qd(tmp2);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		// jmax = (mat->nzero_col_dim[i] / 2) * 2;
		// jres =  mat->nzero_col_dim[i] % 2;
		jmax = (mat->real_nzero_col_dim[i] / 2) * 2;
		jres =  mat->real_nzero_col_dim[i] % 2;
		for(j = 0; j < jmax; j += 2)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a2[0] = vld1q_f64(&(mat->element[0][total_index]));
			a2[1] = vld1q_f64(&(mat->element[1][total_index]));
			a2[2] = vld1q_f64(&(mat->element[2][total_index]));
			a2[3] = vld1q_f64(&(mat->element[3][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[0][mat->nzero_index[i][j + 1]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[0] = vld1q_f64(vset);
			//vb2[0] = _mm256_set_pd(
			//	vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			//);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[1][mat->nzero_index[i][j + 1]];
			//("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[1] = vld1q_f64(vset);
			//vb2[1] = _mm256_set_pd(
			//	vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[2][mat->nzero_index[i][j + 1]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[2] = vld1q_f64(vset);
			//vb2[0] = _mm256_set_pd(
			//	vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			//);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[3][mat->nzero_index[i][j + 1]];
			//printf("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[3] = vld1q_f64(vset);
			//vb2[1] = _mm256_set_pd(
			//	vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			//);

/*
			vb2[0] = _mm256_set_pd(
				vec->element[0][mat->nzero_index[i][j + 3]],
				vec->element[0][mat->nzero_index[i][j + 2]],
				vec->element[0][mat->nzero_index[i][j + 1]],
				vec->element[0][mat->nzero_index[i][j    ]]
			);
			vb2[1] = _mm256_set_pd(
				vec->element[1][mat->nzero_index[i][j + 3]],
				vec->element[1][mat->nzero_index[i][j + 2]],
				vec->element[1][mat->nzero_index[i][j + 1]],
				vec->element[1][mat->nzero_index[i][j    ]]
			);
			vb2[0] = _mm256_set_pd(
				vec->element[0][mat->nzero_index[i][j + 3]],
				vec->element[0][mat->nzero_index[i][j + 2]],
				vec->element[0][mat->nzero_index[i][j + 1]],
				vec->element[0][mat->nzero_index[i][j    ]]
			);
			vb2[1] = _mm256_set_pd(
				vec->element[1][mat->nzero_index[i][j + 3]],
				vec->element[1][mat->nzero_index[i][j + 2]],
				vec->element[1][mat->nzero_index[i][j + 1]],
				vec->element[1][mat->nzero_index[i][j    ]]
			);
*/
			//tmp2 = vfmaq_f64(tmp2, a2, vb2);
			_bncneon_rqd_mul(tmp4_mul, a2, vb2);
			_bncneon_rqd_add(tmp2, tmp2, tmp4_mul);

			// total_index++;
			total_index += 2;
		}
		//mat_vec_i = tmp2[0] + tmp2[1];
		_bncneon_rqd_sum128d(mat_vec_i, tmp2);

		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i[0], mat->nzero_col_dim[i], jmax, jres);
/*
		col_dim = mat->nzero_col_dim[i];
		switch(jres)
		{
			case 1:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break;

			case 2:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;
			
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break;

			case 3:
				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 3]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 3]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 2]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 2]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				//mat_vec_i += mat->element[total_index++] * vec->element[mat->nzero_index[i][col_dim - 1]];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];
				mat_ij[0] = mat->element[0][total_index];
				mat_ij[1] = mat->element[1][total_index];

				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];
				vec_j[0] = vec->element[0][mat->nzero_index[i][col_dim - 1]];
				vec_j[1] = vec->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ij, vec_j);
				rqd_add(mat_vec_i, mat_vec_i, tmp);
				total_index++;

				break;
		}
		//printf("%ld mat_vec_i = %25.17e\n", i, mat_vec_i[0]);
*/
		set_qdvector_i(ret, i, mat_vec_i);
	}



#else // others

	for(i = 0; i < mat->row_dim; i++)
	{
		//get_mpfvector_i(ret, i) = 0.0;
		//mpf_set_ui(get_mpfvector_i(ret, i), 0UL);
		//rqd_set_ui(get_qdvector_i(ret, i), 0UL);
		rqd_set_ui(ret_i, 0UL);

		for(j = 0; j < mat->nzero_col_dim[i]; j++)
		{
			//get_mpfvector_i(ret, i) += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			//mpf_mul(tmp, mat->element[total_index], get_mpfvector_i(vec, mat->nzero_index[i][j]]));
			//mpf_mul(tmp, get_mpfvector_i(mat, total_index), get_mpfvector_i(vec, mat->nzero_index[i][j]));
			//rqd_mul(tmp, (mpf_ptr)(mat->element[total_index]), get_mpfvector_i(vec, mat->nzero_index[i][j]));
			mat_ij[0] = mat->element[0][total_index];
			mat_ij[1] = mat->element[1][total_index];
			mat_ij[2] = mat->element[2][total_index];
			mat_ij[3] = mat->element[3][total_index];

			vec_j[0] = vec->element[0][mat->nzero_index[i][j]];
			vec_j[1] = vec->element[1][mat->nzero_index[i][j]];
			vec_j[2] = vec->element[2][mat->nzero_index[i][j]];
			vec_j[3] = vec->element[3][mat->nzero_index[i][j]];

			rqd_mul(tmp, mat_ij, vec_j);
			//mpf_add(get_mpfvector_i(ret, i), get_mpfvector_i(ret, i), tmp);
			rqd_add(ret_i, ret_i, tmp);
			total_index++;
		}
		set_qdvector_i(ret, i, ret_i);
	}

#endif // __AVX2__

	return SUCCESS;
}

/* Multiply QDRSMatrix^T * QDVector */
int mul_qdrsmatrixt_qdvec(QDVector ret, QDRSMatrix mat, QDVector vec)
{
	long int i, j, total_index;
	//qdfloat tmp, mat_ji, vec_j, ret_j;
	double tmp[QDSIZE], mat_ji[QDSIZE], vec_i[QDSIZE], ret_j[QDSIZE];

	if((ret->dim < mat->col_dim) || (vec->dim != mat->col_dim))
	{
		fprintf(stderr, "Illegal dimension!\n");
		return ERROR;
	}

	//for(i = 0; i < mat->row_dim; i++)
	//	mpf_set_ui(get_mpfvector_i(ret, i), 0UL);

	// ret := 0
	set0_qdvector(ret);
	total_index = 0;

#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d a4[QDSIZE], vb4[QDSIZE], tmp4[QDSIZE], ret4[QDSIZE];
	long int jmax, jres, col_dim;
	double vset[_BNC_D_WIDTH];

	for(i = 0; i < mat->row_dim; i++)
	{
		vb4[0] = _mm256_set1_pd(vec->element[0][i]);
		vb4[1] = _mm256_set1_pd(vec->element[1][i]);
		vb4[2] = _mm256_set1_pd(vec->element[2][i]);
		vb4[3] = _mm256_set1_pd(vec->element[3][i]);

		// jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		// jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;

		//jmax = (mat->row_dim / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->row_dim % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a4[0] = _mm256_load_pd(&(mat->element[0][total_index]));
			a4[1] = _mm256_load_pd(&(mat->element[1][total_index]));
			a4[2] = _mm256_load_pd(&(mat->element[2][total_index]));
			a4[3] = _mm256_load_pd(&(mat->element[3][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[0][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[0][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[0][mat->nzero_index[i][j + 3]];

			ret4[0] = _mm256_set_pd(
				vset[3], // ret->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			);
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[1][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[1][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[1][mat->nzero_index[i][j + 3]];

			ret4[1] = _mm256_set_pd(
				vset[3], // ret->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[2][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[2][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[2][mat->nzero_index[i][j + 3]];

			ret4[2] = _mm256_set_pd(
				vset[3], // ret->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[3][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[3][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[3][mat->nzero_index[i][j + 3]];

			ret4[3] = _mm256_set_pd(
				vset[3], // ret->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			);

/*
			ret4[0] = _mm256_set_pd(
				ret->element[0][mat->nzero_index[i][j + 3]],
				ret->element[0][mat->nzero_index[i][j + 2]],
				ret->element[0][mat->nzero_index[i][j + 1]],
				ret->element[0][mat->nzero_index[i][j    ]]
			);
			ret4[1] = _mm256_set_pd(
				ret->element[1][mat->nzero_index[i][j + 3]],
				ret->element[1][mat->nzero_index[i][j + 2]],
				ret->element[1][mat->nzero_index[i][j + 1]],
				ret->element[1][mat->nzero_index[i][j    ]]
			);
			ret4[2] = _mm256_set_pd(
				ret->element[2][mat->nzero_index[i][j + 3]],
				ret->element[2][mat->nzero_index[i][j + 2]],
				ret->element[2][mat->nzero_index[i][j + 1]],
				ret->element[2][mat->nzero_index[i][j    ]]
			);
			ret4[3] = _mm256_set_pd(
				ret->element[3][mat->nzero_index[i][j + 3]],
				ret->element[3][mat->nzero_index[i][j + 2]],
				ret->element[3][mat->nzero_index[i][j + 1]],
				ret->element[3][mat->nzero_index[i][j    ]]
			);
*/
			//ret4 = _mm256_fmadd_pd(a4, vb4, ret4);
			_bncavx2_rqd_mul(tmp4, a4, vb4);
			_bncavx2_rqd_add(ret4, ret4, tmp4);

			if((j    ) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j    ]] = ret4[0][0];
				ret->element[1][mat->nzero_index[i][j    ]] = ret4[1][0];
				ret->element[2][mat->nzero_index[i][j    ]] = ret4[2][0];
				ret->element[3][mat->nzero_index[i][j    ]] = ret4[3][0];
			}
			if((j + 1) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 1]] = ret4[0][1];
				ret->element[1][mat->nzero_index[i][j + 1]] = ret4[1][1];
				ret->element[2][mat->nzero_index[i][j + 1]] = ret4[2][1];
				ret->element[3][mat->nzero_index[i][j + 1]] = ret4[3][1];

			}
			if((j + 2) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 2]] = ret4[0][2];
				ret->element[1][mat->nzero_index[i][j + 2]] = ret4[1][2];
				ret->element[2][mat->nzero_index[i][j + 2]] = ret4[2][2];
				ret->element[3][mat->nzero_index[i][j + 2]] = ret4[3][2];
			}
			if((j + 3) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 3]] = ret4[0][3];
				ret->element[1][mat->nzero_index[i][j + 3]] = ret4[1][3];
				ret->element[2][mat->nzero_index[i][j + 3]] = ret4[2][3];
				ret->element[3][mat->nzero_index[i][j + 3]] = ret4[3][3];
			}
/*
			ret->element[0][mat->nzero_index[i][j + 3]] = ret4[0][3];
			ret->element[0][mat->nzero_index[i][j + 2]] = ret4[0][2];
			ret->element[0][mat->nzero_index[i][j + 1]] = ret4[0][1];
			ret->element[0][mat->nzero_index[i][j    ]] = ret4[0][0];

			ret->element[1][mat->nzero_index[i][j + 3]] = ret4[1][3];
			ret->element[1][mat->nzero_index[i][j + 2]] = ret4[1][2];
			ret->element[1][mat->nzero_index[i][j + 1]] = ret4[1][1];
			ret->element[1][mat->nzero_index[i][j    ]] = ret4[1][0];

			ret->element[2][mat->nzero_index[i][j + 3]] = ret4[2][3];
			ret->element[2][mat->nzero_index[i][j + 2]] = ret4[2][2];
			ret->element[2][mat->nzero_index[i][j + 1]] = ret4[2][1];
			ret->element[2][mat->nzero_index[i][j    ]] = ret4[2][0];

			ret->element[3][mat->nzero_index[i][j + 3]] = ret4[3][3];
			ret->element[3][mat->nzero_index[i][j + 2]] = ret4[3][2];
			ret->element[3][mat->nzero_index[i][j + 1]] = ret4[3][1];
			ret->element[3][mat->nzero_index[i][j    ]] = ret4[3][0];
*/
			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
/*
		col_dim = mat->nzero_col_dim[i];

		vec_i[0] = vec->element[0][i];
		vec_i[1] = vec->element[1][i];
		vec_i[2] = vec->element[2][i];
		vec_i[3] = vec->element[3][i];

		switch(jres)
		{
			case 1: 
				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

			case 2:
				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

			case 3:
				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break; 

		}
*/
		//printf("%ld mat_vec_i = %25.17e\n", i, mat_vec_i);
	}

#elif defined(__AVX512F__) // __AVX512F__
	__m512d a8[QDSIZE], vb8[QDSIZE], tmp8[QDSIZE], ret8[QDSIZE];
	long int jmax, jres, col_dim;

	for(i = 0; i < mat->row_dim; i++)
	{
		vb8[0] = _mm512_set1_pd(vec->element[0][i]);
		vb8[1] = _mm512_set1_pd(vec->element[1][i]);
		vb8[2] = _mm512_set1_pd(vec->element[2][i]);
		vb8[3] = _mm512_set1_pd(vec->element[3][i]);

		//jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a8[0] = _mm512_load_pd(&(mat->element[0][total_index]));
			a8[1] = _mm512_load_pd(&(mat->element[1][total_index]));
			a8[2] = _mm512_load_pd(&(mat->element[2][total_index]));
			a8[3] = _mm512_load_pd(&(mat->element[3][total_index]));

			ret8[0] = _mm512_set_pd(
				ret->element[0][mat->nzero_index[i][j + 7]],
				ret->element[0][mat->nzero_index[i][j + 6]],
				ret->element[0][mat->nzero_index[i][j + 5]],
				ret->element[0][mat->nzero_index[i][j + 4]],
				ret->element[0][mat->nzero_index[i][j + 3]],
				ret->element[0][mat->nzero_index[i][j + 2]],
				ret->element[0][mat->nzero_index[i][j + 1]],
				ret->element[0][mat->nzero_index[i][j    ]]
			);
			ret8[1] = _mm512_set_pd(
				ret->element[1][mat->nzero_index[i][j + 7]],
				ret->element[1][mat->nzero_index[i][j + 6]],
				ret->element[1][mat->nzero_index[i][j + 5]],
				ret->element[1][mat->nzero_index[i][j + 4]],
				ret->element[1][mat->nzero_index[i][j + 3]],
				ret->element[1][mat->nzero_index[i][j + 2]],
				ret->element[1][mat->nzero_index[i][j + 1]],
				ret->element[1][mat->nzero_index[i][j    ]]
			);
			ret8[2] = _mm512_set_pd(
				ret->element[2][mat->nzero_index[i][j + 7]],
				ret->element[2][mat->nzero_index[i][j + 6]],
				ret->element[2][mat->nzero_index[i][j + 5]],
				ret->element[2][mat->nzero_index[i][j + 4]],
				ret->element[2][mat->nzero_index[i][j + 3]],
				ret->element[2][mat->nzero_index[i][j + 2]],
				ret->element[2][mat->nzero_index[i][j + 1]],
				ret->element[2][mat->nzero_index[i][j    ]]
			);
			ret8[3] = _mm512_set_pd(
				ret->element[3][mat->nzero_index[i][j + 7]],
				ret->element[3][mat->nzero_index[i][j + 6]],
				ret->element[3][mat->nzero_index[i][j + 5]],
				ret->element[3][mat->nzero_index[i][j + 4]],
				ret->element[3][mat->nzero_index[i][j + 3]],
				ret->element[3][mat->nzero_index[i][j + 2]],
				ret->element[3][mat->nzero_index[i][j + 1]],
				ret->element[3][mat->nzero_index[i][j    ]]
			);

			//ret8 = _mm512_fmadd_pd(a8, vb8, ret8);
			_bncavx512_rqd_mul(tmp8, a8, vb8);
			_bncavx512_rqd_add(ret8, ret8, tmp8);

			ret->element[0][mat->nzero_index[i][j + 7]] = ret8[0][7];
			ret->element[0][mat->nzero_index[i][j + 6]] = ret8[0][6];
			ret->element[0][mat->nzero_index[i][j + 5]] = ret8[0][5];
			ret->element[0][mat->nzero_index[i][j + 4]] = ret8[0][4];
			ret->element[0][mat->nzero_index[i][j + 3]] = ret8[0][3];
			ret->element[0][mat->nzero_index[i][j + 2]] = ret8[0][2];
			ret->element[0][mat->nzero_index[i][j + 1]] = ret8[0][1];
			ret->element[0][mat->nzero_index[i][j    ]] = ret8[0][0];

			ret->element[1][mat->nzero_index[i][j + 7]] = ret8[1][7];
			ret->element[1][mat->nzero_index[i][j + 6]] = ret8[1][6];
			ret->element[1][mat->nzero_index[i][j + 5]] = ret8[1][5];
			ret->element[1][mat->nzero_index[i][j + 4]] = ret8[1][4];
			ret->element[1][mat->nzero_index[i][j + 3]] = ret8[1][3];
			ret->element[1][mat->nzero_index[i][j + 2]] = ret8[1][2];
			ret->element[1][mat->nzero_index[i][j + 1]] = ret8[1][1];
			ret->element[1][mat->nzero_index[i][j    ]] = ret8[1][0];

			ret->element[2][mat->nzero_index[i][j + 7]] = ret8[2][7];
			ret->element[2][mat->nzero_index[i][j + 6]] = ret8[2][6];
			ret->element[2][mat->nzero_index[i][j + 5]] = ret8[2][5];
			ret->element[2][mat->nzero_index[i][j + 4]] = ret8[2][4];
			ret->element[2][mat->nzero_index[i][j + 3]] = ret8[2][3];
			ret->element[2][mat->nzero_index[i][j + 2]] = ret8[2][2];
			ret->element[2][mat->nzero_index[i][j + 1]] = ret8[2][1];
			ret->element[2][mat->nzero_index[i][j    ]] = ret8[2][0];

			ret->element[3][mat->nzero_index[i][j + 7]] = ret8[3][7];
			ret->element[3][mat->nzero_index[i][j + 6]] = ret8[3][6];
			ret->element[3][mat->nzero_index[i][j + 5]] = ret8[3][5];
			ret->element[3][mat->nzero_index[i][j + 4]] = ret8[3][4];
			ret->element[3][mat->nzero_index[i][j + 3]] = ret8[3][3];
			ret->element[3][mat->nzero_index[i][j + 2]] = ret8[3][2];
			ret->element[3][mat->nzero_index[i][j + 1]] = ret8[3][1];
			ret->element[3][mat->nzero_index[i][j    ]] = ret8[3][0];

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
/*
		col_dim = mat->nzero_col_dim[i];
		switch(jres)
		{
			case 1: 
				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;

				break;

			case 2:
				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;

				break;

			case 3:
				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];
				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

			case 4:
				//ret->element[mat->nzero_index[i][col_dim - 4]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 4]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 4]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 4]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 4]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 4]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 4]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 4]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;

				break;

			case 5:
				//ret->element[mat->nzero_index[i][col_dim - 5]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];


				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 5]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 5]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 5]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 5]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 5]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 5]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 5]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 4]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 4]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 4]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 4]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 4]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 4]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 4]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 4]] = ret_j[3];
				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];
				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

			case 6:
				//ret->element[mat->nzero_index[i][col_dim - 6]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 6]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 6]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 6]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 6]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 6]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 6]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 6]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 6]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 5]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];


				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 5]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 5]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 5]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 5]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 5]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 5]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 5]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 4]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 4]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 4]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 4]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 4]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 4]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 4]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 4]] = ret_j[3];
				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];
				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

			case 7:
				//ret->element[mat->nzero_index[i][col_dim - 7]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 7]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 7]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 7]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 7]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 7]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 7]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 7]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 7]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 6]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 6]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 6]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 6]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 6]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 6]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 6]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 6]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 6]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 5]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 5]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 5]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 5]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 5]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 5]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 5]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 5]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 5]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 4]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 4]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 4]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 4]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 4]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 4]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 4]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 4]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 4]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 3]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 3]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 3]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 2]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 2]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 2]] = ret_j[3];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[2] = mat->element[2][total_index];
				mat_ji[3] = mat->element[3][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[2] = ret->element[2][mat->nzero_index[i][col_dim - 1]];
				ret_j[3] = ret->element[3][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[2][mat->nzero_index[i][col_dim - 1]] = ret_j[2];
				ret->element[3][mat->nzero_index[i][col_dim - 1]] = ret_j[3];

				total_index++;
				break;

		}
*/
		//printf("%ld mat_vec_i = %25.17e\n", i, mat_vec_i);
	}

#elif defined(__ARM_NEON) // ARM Neon
	float64x2_t a2[QDSIZE], vb2[QDSIZE], tmp2[QDSIZE], ret2[QDSIZE];
	long int jmax, jres, col_dim;
	double vset[2];

	for(i = 0; i < mat->row_dim; i++)
	{
		vb2[0] = vdupq_n_f64(vec->element[0][i]);
		vb2[1] = vdupq_n_f64(vec->element[1][i]);
		vb2[2] = vdupq_n_f64(vec->element[2][i]);
		vb2[3] = vdupq_n_f64(vec->element[3][i]);

		// jmax = (mat->nzero_col_dim[i] / 2) * 2;
		// jres =  mat->nzero_col_dim[i] % 2;
		jmax = (mat->real_nzero_col_dim[i] / 2) * 2;
		jres =  mat->real_nzero_col_dim[i] % 2;

		//jmax = (mat->row_dim / 2) * 2;
		//jres =  mat->row_dim % 2;
		for(j = 0; j < jmax; j += 2)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a2[0] = vld1q_f64(&(mat->element[0][total_index]));
			a2[1] = vld1q_f64(&(mat->element[1][total_index]));
			a2[2] = vld1q_f64(&(mat->element[0][total_index]));
			a2[3] = vld1q_f64(&(mat->element[1][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[0][mat->nzero_index[i][j + 1]];
    		ret2[0] = vld1q_f64(vset);
			//ret2[0] = _mm256_set_pd(
			//	vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[1][mat->nzero_index[i][j + 1]];
    		ret2[1] = vld1q_f64(vset);
			//ret2[1] = _mm256_set_pd(
			//	vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[2][mat->nzero_index[i][j + 1]];
    		ret2[2] = vld1q_f64(vset);
			//ret2[0] = _mm256_set_pd(
			//	vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[3][mat->nzero_index[i][j + 1]];
    		ret2[3] = vld1q_f64(vset);
			//ret2[1] = _mm256_set_pd(
			//	vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			//);

/*
			ret2[0] = _mm256_set_pd(
				ret->element[0][mat->nzero_index[i][j + 3]],
				ret->element[0][mat->nzero_index[i][j + 2]],
				ret->element[0][mat->nzero_index[i][j + 1]],
				ret->element[0][mat->nzero_index[i][j    ]]
			);
			ret2[1] = _mm256_set_pd(
				ret->element[1][mat->nzero_index[i][j + 3]],
				ret->element[1][mat->nzero_index[i][j + 2]],
				ret->element[1][mat->nzero_index[i][j + 1]],
				ret->element[1][mat->nzero_index[i][j    ]]
			);
			ret2[0] = _mm256_set_pd(
				ret->element[0][mat->nzero_index[i][j + 3]],
				ret->element[0][mat->nzero_index[i][j + 2]],
				ret->element[0][mat->nzero_index[i][j + 1]],
				ret->element[0][mat->nzero_index[i][j    ]]
			);
			ret2[1] = _mm256_set_pd(
				ret->element[1][mat->nzero_index[i][j + 3]],
				ret->element[1][mat->nzero_index[i][j + 2]],
				ret->element[1][mat->nzero_index[i][j + 1]],
				ret->element[1][mat->nzero_index[i][j    ]]
			);
*/
			//ret2 = vfmaq_f64(ret2, a2, vb2);
			_bncneon_rqd_mul(tmp2, a2, vb2);
			_bncneon_rqd_add(ret2, ret2, tmp2);

			if((j    ) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j    ]] = ret2[0][0];
				ret->element[1][mat->nzero_index[i][j    ]] = ret2[1][0];
				ret->element[2][mat->nzero_index[i][j    ]] = ret2[2][0];
				ret->element[3][mat->nzero_index[i][j    ]] = ret2[3][0];
			}
			if((j + 1) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 1]] = ret2[0][1];
				ret->element[1][mat->nzero_index[i][j + 1]] = ret2[1][1];
				ret->element[2][mat->nzero_index[i][j + 1]] = ret2[2][1];
				ret->element[3][mat->nzero_index[i][j + 1]] = ret2[3][1];

			}
/*
			ret->element[0][mat->nzero_index[i][j + 3]] = ret2[0][3];
			ret->element[0][mat->nzero_index[i][j + 2]] = ret2[0][2];
			ret->element[0][mat->nzero_index[i][j + 1]] = ret2[0][1];
			ret->element[0][mat->nzero_index[i][j    ]] = ret2[0][0];

			ret->element[1][mat->nzero_index[i][j + 3]] = ret2[1][3];
			ret->element[1][mat->nzero_index[i][j + 2]] = ret2[1][2];
			ret->element[1][mat->nzero_index[i][j + 1]] = ret2[1][1];
			ret->element[1][mat->nzero_index[i][j    ]] = ret2[1][0];

			ret->element[0][mat->nzero_index[i][j + 3]] = ret2[0][3];
			ret->element[0][mat->nzero_index[i][j + 2]] = ret2[0][2];
			ret->element[0][mat->nzero_index[i][j + 1]] = ret2[0][1];
			ret->element[0][mat->nzero_index[i][j    ]] = ret2[0][0];

			ret->element[1][mat->nzero_index[i][j + 3]] = ret2[1][3];
			ret->element[1][mat->nzero_index[i][j + 2]] = ret2[1][2];
			ret->element[1][mat->nzero_index[i][j + 1]] = ret2[1][1];
			ret->element[1][mat->nzero_index[i][j    ]] = ret2[1][0];
*/
			// total_index++;
			total_index += 2;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
/*
		col_dim = mat->nzero_col_dim[i];

		vec_i[0] = vec->element[0][i];
		vec_i[1] = vec->element[1][i];
		vec_i[0] = vec->element[0][i];
		vec_i[1] = vec->element[1][i];

		switch(jres)
		{
			case 1:
				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];

				total_index++;
				break;

			case 2:
				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];

				total_index++;
				break;

			case 3:
				//ret->element[mat->nzero_index[i][col_dim - 3]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 3]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 3]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 3]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 3]] = ret_j[1];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 2]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 2]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 2]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 2]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 2]] = ret_j[1];

				total_index++;

				//ret->element[mat->nzero_index[i][col_dim - 1]] += mat->element[total_index++] * vec->element[i];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];
				mat_ji[0] = mat->element[0][total_index];
				mat_ji[1] = mat->element[1][total_index];

				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];
				ret_j[0] = ret->element[0][mat->nzero_index[i][col_dim - 1]];
				ret_j[1] = ret->element[1][mat->nzero_index[i][col_dim - 1]];

				rqd_mul(tmp, mat_ji, vec_i);
				rqd_add(ret_j, ret_j, tmp);

				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];
				ret->element[0][mat->nzero_index[i][col_dim - 1]] = ret_j[0];
				ret->element[1][mat->nzero_index[i][col_dim - 1]] = ret_j[1];

				total_index++;
				break;

		}
*/
		//printf("%ld mat_vec_i = %25.17e\n", i, mat_vec_i);
	}



#else // __AVX2__

	for(i = 0; i < mat->row_dim; i++)
	{
		vec_i[0] = vec->element[0][i];
		vec_i[1] = vec->element[1][i];
		vec_i[2] = vec->element[2][i];
		vec_i[3] = vec->element[3][i];

		for(j = 0; j < mat->nzero_col_dim[i]; j++)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			mat_ji[0] = mat->element[0][total_index];
			mat_ji[1] = mat->element[1][total_index];
			mat_ji[2] = mat->element[2][total_index];
			mat_ji[3] = mat->element[3][total_index];

			ret_j[0] = ret->element[0][mat->nzero_index[i][j]];
			ret_j[1] = ret->element[1][mat->nzero_index[i][j]];
			ret_j[2] = ret->element[2][mat->nzero_index[i][j]];
			ret_j[3] = ret->element[3][mat->nzero_index[i][j]];

			//rqd_mul(tmp, mat->element[total_index]), get_qdvector_i(vec, i));
			rqd_mul(tmp, mat_ji, vec_i);
			//rqd_add(ret->element[mat->nzero_index[i][j]], ret->element[mat->nzero_index[i][j]], tmp);
			rqd_add(ret_j, ret_j, tmp);
			set_qdvector_i(ret, mat->nzero_index[i][j], ret_j);
			total_index++;
		}
	}

#endif // __AVX2__

	return SUCCESS;
}

/* Multiply DRSMatrix * QDVector */
int mul_drsmatrix_qdvec(QDVector ret, DRSMatrix mat, QDVector vec)
{
	long int i, j, total_index;
	//qdfloat tmp, mat_ij, vec_j, ret_i;
	double tmp[QDSIZE], mat_ij, vec_j[QDSIZE], ret_i[QDSIZE];

	if((ret->dim < mat->col_dim) || (vec->dim != mat->col_dim))
	{
		fprintf(stderr, "Illegal dimension!\n");
		return ERROR;
	}

	total_index = 0;

#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d a4, vb4[QDSIZE], tmp4[QDSIZE], tmp4_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE], vset[_BNC_D_WIDTH];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp4 = _mm256_setzero_pd();
		_bncavx2_set0_qd(tmp4);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		// jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		// jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a4  = _mm256_load_pd(&(mat->element[total_index]));
			//a4[1]  = _mm256_load_pd(&(mat->element[1][total_index]));
			//a4[2]  = _mm256_load_pd(&(mat->element[2][total_index]));
			//a4[3]  = _mm256_load_pd(&(mat->element[3][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[0][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[0][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[0][mat->nzero_index[i][j + 3]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[0] = _mm256_set_pd(
				vset[3], // vec->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[1][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[1][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[1][mat->nzero_index[i][j + 3]];
			//("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[1] = _mm256_set_pd(
				vset[3], // vec->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[2][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[2][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[2][mat->nzero_index[i][j + 3]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[2] = _mm256_set_pd(
				vset[3], // vec->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[3][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = vec->element[3][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = vec->element[3][mat->nzero_index[i][j + 3]];
			//printf("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[2], vset[3]); fflush(stdout);
			vb4[3] = _mm256_set_pd(
				vset[3], // vec->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // vec->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			);

			//tmp4 = _mm256_fmadd_pd(a4, vb4, tmp4);
			//_bncavx2_rqd_mul(tmp4_mul, a4, vb4);
			_bncavx2_rqd_mul_d(tmp4_mul, vb4, a4);
			_bncavx2_rqd_add(tmp4, tmp4, tmp4_mul);

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//mat_vec_i = tmp4[0] + tmp4[1] + tmp4[2] + tmp4[3];
		_bncavx2_rqd_sum256d(mat_vec_i, tmp4);

		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i[0], mat->nzero_col_dim[i], jmax, jres);
		set_qdvector_i(ret, i, mat_vec_i);
	}

#elif defined(__AVX512F__) // __AVX512F__
	__m512d a8, vb8[QDSIZE], tmp8[QDSIZE], tmp8_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp8 = _mm512_setzero_pd();
		_bncavx512_set0_qd(tmp8);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		//jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a8 = _mm512_load_pd(&(mat->element[total_index]));
			//a8[1] = _mm512_load_pd(&(mat->element[1][total_index]));
			//a8[2] = _mm512_load_pd(&(mat->element[2][total_index]));
			//a8[3] = _mm512_load_pd(&(mat->element[3][total_index]));

			vb8[0] = _mm512_set_pd(
				vec->element[0][mat->nzero_index[i][j + 7]],
				vec->element[0][mat->nzero_index[i][j + 6]],
				vec->element[0][mat->nzero_index[i][j + 5]],
				vec->element[0][mat->nzero_index[i][j + 4]],
				vec->element[0][mat->nzero_index[i][j + 3]],
				vec->element[0][mat->nzero_index[i][j + 2]],
				vec->element[0][mat->nzero_index[i][j + 1]],
				vec->element[0][mat->nzero_index[i][j    ]]
			);
			vb8[1] = _mm512_set_pd(
				vec->element[1][mat->nzero_index[i][j + 7]],
				vec->element[1][mat->nzero_index[i][j + 6]],
				vec->element[1][mat->nzero_index[i][j + 5]],
				vec->element[1][mat->nzero_index[i][j + 4]],
				vec->element[1][mat->nzero_index[i][j + 3]],
				vec->element[1][mat->nzero_index[i][j + 2]],
				vec->element[1][mat->nzero_index[i][j + 1]],
				vec->element[1][mat->nzero_index[i][j    ]]
			);
			vb8[2] = _mm512_set_pd(
				vec->element[2][mat->nzero_index[i][j + 7]],
				vec->element[2][mat->nzero_index[i][j + 6]],
				vec->element[2][mat->nzero_index[i][j + 5]],
				vec->element[2][mat->nzero_index[i][j + 4]],
				vec->element[2][mat->nzero_index[i][j + 3]],
				vec->element[2][mat->nzero_index[i][j + 2]],
				vec->element[2][mat->nzero_index[i][j + 1]],
				vec->element[2][mat->nzero_index[i][j    ]]
			);
			vb8[3] = _mm512_set_pd(
				vec->element[3][mat->nzero_index[i][j + 7]],
				vec->element[3][mat->nzero_index[i][j + 6]],
				vec->element[3][mat->nzero_index[i][j + 5]],
				vec->element[3][mat->nzero_index[i][j + 4]],
				vec->element[3][mat->nzero_index[i][j + 3]],
				vec->element[3][mat->nzero_index[i][j + 2]],
				vec->element[3][mat->nzero_index[i][j + 1]],
				vec->element[3][mat->nzero_index[i][j    ]]
			);

			//tmp8 = _mm512_fmadd_pd(a4, vb4, tmp4);
			//_bncavx512_rqd_mul(tmp8_mul, a8, vb8);
			_bncavx512_rqd_mul_d(tmp8_mul, vb8, a8);
			_bncavx512_rqd_add(tmp8, tmp8, tmp8_mul);

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//mat_vec_i = tmp4[0] + tmp4[1] + tmp4[2] + tmp4[3] + tmp4[4] + tmp4[5] + tmp4[6] + tmp4[7];
		_bncavx512_rqd_sum512d(mat_vec_i, tmp8);
		set_qdvector_i(ret, i, mat_vec_i);
	}

#elif defined(__ARM_NEON) // ARM Neon
	float64x2_t a2, vb2[QDSIZE], tmp2[QDSIZE], tmp4_mul[QDSIZE];
	long int jmax, jres, col_dim;
	double mat_vec_i[QDSIZE], vset[2];

	for(i = 0; i < mat->row_dim; i++)
	{
		//ret->element[i] = 0.0;
		//tmp2 = vdupq_n_f64(0.0);
		_bncneon_set0_qd(tmp2);

		//for(j = 0; j < mat->nzero_col_dim[i]; j++)
		// jmax = (mat->nzero_col_dim[i] / 2) * 2;
		// jres =  mat->nzero_col_dim[i] % 2;
		jmax = (mat->real_nzero_col_dim[i] / 2) * 2;
		jres =  mat->real_nzero_col_dim[i] % 2;
		for(j = 0; j < jmax; j += 2)
		{
			//ret->element[i] += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			a2  = vld1q_f64(&(mat->element[total_index]));
			//a2[1] = vld1q_f64(&(mat->element[1][total_index]));
			//a2[0] = vld1q_f64(&(mat->element[0][total_index]));
			//a2[1] = vld1q_f64(&(mat->element[1][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[0][mat->nzero_index[i][j + 1]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
			vb2[0] = vld1q_f64(vset);
			//vb2[0] = _mm256_set_pd(
			//	vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			//);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[1][mat->nzero_index[i][j + 1]];
			//("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[1] = vld1q_f64(vset);
			//vb2[1] = _mm256_set_pd(
			//	vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[2][mat->nzero_index[i][j + 1]];
			//printf("set0 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[2] = vld1q_f64(vset);
			//vb2[0] = _mm256_set_pd(
			//	vset[1], // vec->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[0][mat->nzero_index[i][j    ]]
			//);

			//printf("set1 ");
			vset[0] = 0.0; vset[1] = 0.0; 
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = vec->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = vec->element[3][mat->nzero_index[i][j + 1]];
			//printf("set1 %g, %g, %g, %g ", vset[0], vset[1], vset[0], vset[1]); fflush(stdout);
    		vb2[3] = vld1q_f64(vset);
			//vb2[1] = _mm256_set_pd(
			//	vset[1], // vec->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // vec->element[1][mat->nzero_index[i][j    ]]
			//);

			//tmp2 = vfmaq_f64(tmp2, a2, vb2);
			//_bncneon_rqd_mul(tmp4_mul, a2, vb2);
			_bncneon_rqd_mul_d(tmp4_mul, vb2, a2);
			_bncneon_rqd_add(tmp2, tmp2, tmp4_mul);

			// total_index++;
			total_index += 2;
		}
		//mat_vec_i = tmp2[0] + tmp2[1];
		_bncneon_rqd_sum128d(mat_vec_i, tmp2);

		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i[0], mat->nzero_col_dim[i], jmax, jres);
		set_qdvector_i(ret, i, mat_vec_i);
	}



#else // others

	for(i = 0; i < mat->row_dim; i++)
	{
		//get_mpfvector_i(ret, i) = 0.0;
		//mpf_set_ui(get_mpfvector_i(ret, i), 0UL);
		//rqd_set_ui(get_qdvector_i(ret, i), 0UL);
		rqd_set_ui(ret_i, 0UL);

		for(j = 0; j < mat->nzero_col_dim[i]; j++)
		{
			//get_mpfvector_i(ret, i) += mat->element[total_index] * vec->element[mat->nzero_index[i][j]];
			//mpf_mul(tmp, mat->element[total_index], get_mpfvector_i(vec, mat->nzero_index[i][j]]));
			//mpf_mul(tmp, get_mpfvector_i(mat, total_index), get_mpfvector_i(vec, mat->nzero_index[i][j]));
			//rqd_mul(tmp, (mpf_ptr)(mat->element[total_index]), get_mpfvector_i(vec, mat->nzero_index[i][j]));
			mat_ij = mat->element[total_index];
			//mat_ij[1] = mat->element[1][total_index];
			//mat_ij[2] = mat->element[2][total_index];
			//mat_ij[3] = mat->element[3][total_index];

			vec_j[0] = vec->element[0][mat->nzero_index[i][j]];
			vec_j[1] = vec->element[1][mat->nzero_index[i][j]];
			vec_j[2] = vec->element[2][mat->nzero_index[i][j]];
			vec_j[3] = vec->element[3][mat->nzero_index[i][j]];

			//rqd_mul(tmp, mat_ij, vec_j);
			rqd_mul_d(tmp, vec_j, mat_ij);

			//mpf_add(get_mpfvector_i(ret, i), get_mpfvector_i(ret, i), tmp);
			rqd_add(ret_i, ret_i, tmp);
			total_index++;
		}
		set_qdvector_i(ret, i, ret_i);
	}

#endif // __AVX2__

	return SUCCESS;
}

/* Multiply DRSMatrix^T * QDVector */
int mul_drsmatrixt_qdvec(QDVector ret, DRSMatrix mat, QDVector vec)
{
	long int i, j, total_index;
	//qdfloat tmp, mat_ji, vec_j, ret_j;
	double tmp[QDSIZE], mat_ji, vec_i[QDSIZE], ret_j[QDSIZE];

	if((ret->dim < mat->col_dim) || (vec->dim != mat->col_dim))
	{
		fprintf(stderr, "Illegal dimension!\n");
		return ERROR;
	}

	//for(i = 0; i < mat->row_dim; i++)
	//	mpf_set_ui(get_mpfvector_i(ret, i), 0UL);

	// ret := 0
	set0_qdvector(ret);
	total_index = 0;

#if defined(__AVX2__) && !defined(__AVX512F__) // __AVX2__
	__m256d a4, vb4[QDSIZE], tmp4[QDSIZE], ret4[QDSIZE];
	long int jmax, jres, col_dim;
	double vset[_BNC_D_WIDTH];

	for(i = 0; i < mat->row_dim; i++)
	{
		vb4[0] = _mm256_set1_pd(vec->element[0][i]);
		vb4[1] = _mm256_set1_pd(vec->element[1][i]);
		vb4[2] = _mm256_set1_pd(vec->element[2][i]);
		vb4[3] = _mm256_set1_pd(vec->element[3][i]);

		// jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		// jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;

		//jmax = (mat->row_dim / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->row_dim % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a4 = _mm256_load_pd(&(mat->element[total_index]));
			//a4[1] = _mm256_load_pd(&(mat->element[1][total_index]));
			//a4[2] = _mm256_load_pd(&(mat->element[2][total_index]));
			//a4[3] = _mm256_load_pd(&(mat->element[3][total_index]));

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[0][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[0][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[0][mat->nzero_index[i][j + 3]];

			ret4[0] = _mm256_set_pd(
				vset[3], // ret->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			);
			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[1][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[1][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[1][mat->nzero_index[i][j + 3]];

			ret4[1] = _mm256_set_pd(
				vset[3], // ret->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[2][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[2][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[2][mat->nzero_index[i][j + 3]];

			ret4[2] = _mm256_set_pd(
				vset[3], // ret->element[0][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[0][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			);

			vset[0] = 0.0; vset[1] = 0.0; vset[2] = 0.0; vset[3] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[3][mat->nzero_index[i][j + 1]];
			if((j + 2) < mat->nzero_col_dim[i]) vset[2] = ret->element[3][mat->nzero_index[i][j + 2]];
			if((j + 3) < mat->nzero_col_dim[i]) vset[3] = ret->element[3][mat->nzero_index[i][j + 3]];

			ret4[3] = _mm256_set_pd(
				vset[3], // ret->element[1][mat->nzero_index[i][j + 3]],
				vset[2], // ret->element[1][mat->nzero_index[i][j + 2]],
				vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
				vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			);

			//ret4 = _mm256_fmadd_pd(a4, vb4, ret4);
			//_bncavx2_rqd_mul(tmp4, a4, vb4);
			_bncavx2_rqd_mul_d(tmp4, vb4, a4);
			_bncavx2_rqd_add(ret4, ret4, tmp4);

			if((j    ) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j    ]] = ret4[0][0];
				ret->element[1][mat->nzero_index[i][j    ]] = ret4[1][0];
				ret->element[2][mat->nzero_index[i][j    ]] = ret4[2][0];
				ret->element[3][mat->nzero_index[i][j    ]] = ret4[3][0];
			}
			if((j + 1) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 1]] = ret4[0][1];
				ret->element[1][mat->nzero_index[i][j + 1]] = ret4[1][1];
				ret->element[2][mat->nzero_index[i][j + 1]] = ret4[2][1];
				ret->element[3][mat->nzero_index[i][j + 1]] = ret4[3][1];

			}
			if((j + 2) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 2]] = ret4[0][2];
				ret->element[1][mat->nzero_index[i][j + 2]] = ret4[1][2];
				ret->element[2][mat->nzero_index[i][j + 2]] = ret4[2][2];
				ret->element[3][mat->nzero_index[i][j + 2]] = ret4[3][2];
			}
			if((j + 3) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 3]] = ret4[0][3];
				ret->element[1][mat->nzero_index[i][j + 3]] = ret4[1][3];
				ret->element[2][mat->nzero_index[i][j + 3]] = ret4[2][3];
				ret->element[3][mat->nzero_index[i][j + 3]] = ret4[3][3];
			}
			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
	}

#elif defined(__AVX512F__) // __AVX512F__
	__m512d a8, vb8[QDSIZE], tmp8[QDSIZE], ret8[QDSIZE];
	long int jmax, jres, col_dim;

	for(i = 0; i < mat->row_dim; i++)
	{
		vb8[0] = _mm512_set1_pd(vec->element[0][i]);
		vb8[1] = _mm512_set1_pd(vec->element[1][i]);
		vb8[2] = _mm512_set1_pd(vec->element[2][i]);
		vb8[3] = _mm512_set1_pd(vec->element[3][i]);

		//jmax = (mat->nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		//jres =  mat->nzero_col_dim[i] % _BNC_D_WIDTH;
		jmax = (mat->real_nzero_col_dim[i] / _BNC_D_WIDTH) * _BNC_D_WIDTH;
		jres =  mat->real_nzero_col_dim[i] % _BNC_D_WIDTH;
		for(j = 0; j < jmax; j += _BNC_D_WIDTH)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a8 = _mm512_load_pd(&(mat->element[total_index]));
			//a8[1] = _mm512_load_pd(&(mat->element[1][total_index]));
			//a8[2] = _mm512_load_pd(&(mat->element[2][total_index]));
			//a8[3] = _mm512_load_pd(&(mat->element[3][total_index]));

			ret8[0] = _mm512_set_pd(
				ret->element[0][mat->nzero_index[i][j + 7]],
				ret->element[0][mat->nzero_index[i][j + 6]],
				ret->element[0][mat->nzero_index[i][j + 5]],
				ret->element[0][mat->nzero_index[i][j + 4]],
				ret->element[0][mat->nzero_index[i][j + 3]],
				ret->element[0][mat->nzero_index[i][j + 2]],
				ret->element[0][mat->nzero_index[i][j + 1]],
				ret->element[0][mat->nzero_index[i][j    ]]
			);
			ret8[1] = _mm512_set_pd(
				ret->element[1][mat->nzero_index[i][j + 7]],
				ret->element[1][mat->nzero_index[i][j + 6]],
				ret->element[1][mat->nzero_index[i][j + 5]],
				ret->element[1][mat->nzero_index[i][j + 4]],
				ret->element[1][mat->nzero_index[i][j + 3]],
				ret->element[1][mat->nzero_index[i][j + 2]],
				ret->element[1][mat->nzero_index[i][j + 1]],
				ret->element[1][mat->nzero_index[i][j    ]]
			);
			ret8[2] = _mm512_set_pd(
				ret->element[2][mat->nzero_index[i][j + 7]],
				ret->element[2][mat->nzero_index[i][j + 6]],
				ret->element[2][mat->nzero_index[i][j + 5]],
				ret->element[2][mat->nzero_index[i][j + 4]],
				ret->element[2][mat->nzero_index[i][j + 3]],
				ret->element[2][mat->nzero_index[i][j + 2]],
				ret->element[2][mat->nzero_index[i][j + 1]],
				ret->element[2][mat->nzero_index[i][j    ]]
			);
			ret8[3] = _mm512_set_pd(
				ret->element[3][mat->nzero_index[i][j + 7]],
				ret->element[3][mat->nzero_index[i][j + 6]],
				ret->element[3][mat->nzero_index[i][j + 5]],
				ret->element[3][mat->nzero_index[i][j + 4]],
				ret->element[3][mat->nzero_index[i][j + 3]],
				ret->element[3][mat->nzero_index[i][j + 2]],
				ret->element[3][mat->nzero_index[i][j + 1]],
				ret->element[3][mat->nzero_index[i][j    ]]
			);

			//ret8 = _mm512_fmadd_pd(a8, vb8, ret8);
			//_bncavx512_mul(tmp8, a8, vb8);
			_bncavx512_rqd_mul_d(tmp8, vb8, a8);
			_bncavx512_rqd_add(ret8, ret8, tmp8);

			ret->element[0][mat->nzero_index[i][j + 7]] = ret8[0][7];
			ret->element[0][mat->nzero_index[i][j + 6]] = ret8[0][6];
			ret->element[0][mat->nzero_index[i][j + 5]] = ret8[0][5];
			ret->element[0][mat->nzero_index[i][j + 4]] = ret8[0][4];
			ret->element[0][mat->nzero_index[i][j + 3]] = ret8[0][3];
			ret->element[0][mat->nzero_index[i][j + 2]] = ret8[0][2];
			ret->element[0][mat->nzero_index[i][j + 1]] = ret8[0][1];
			ret->element[0][mat->nzero_index[i][j    ]] = ret8[0][0];

			ret->element[1][mat->nzero_index[i][j + 7]] = ret8[1][7];
			ret->element[1][mat->nzero_index[i][j + 6]] = ret8[1][6];
			ret->element[1][mat->nzero_index[i][j + 5]] = ret8[1][5];
			ret->element[1][mat->nzero_index[i][j + 4]] = ret8[1][4];
			ret->element[1][mat->nzero_index[i][j + 3]] = ret8[1][3];
			ret->element[1][mat->nzero_index[i][j + 2]] = ret8[1][2];
			ret->element[1][mat->nzero_index[i][j + 1]] = ret8[1][1];
			ret->element[1][mat->nzero_index[i][j    ]] = ret8[1][0];

			ret->element[2][mat->nzero_index[i][j + 7]] = ret8[2][7];
			ret->element[2][mat->nzero_index[i][j + 6]] = ret8[2][6];
			ret->element[2][mat->nzero_index[i][j + 5]] = ret8[2][5];
			ret->element[2][mat->nzero_index[i][j + 4]] = ret8[2][4];
			ret->element[2][mat->nzero_index[i][j + 3]] = ret8[2][3];
			ret->element[2][mat->nzero_index[i][j + 2]] = ret8[2][2];
			ret->element[2][mat->nzero_index[i][j + 1]] = ret8[2][1];
			ret->element[2][mat->nzero_index[i][j    ]] = ret8[2][0];

			ret->element[3][mat->nzero_index[i][j + 7]] = ret8[3][7];
			ret->element[3][mat->nzero_index[i][j + 6]] = ret8[3][6];
			ret->element[3][mat->nzero_index[i][j + 5]] = ret8[3][5];
			ret->element[3][mat->nzero_index[i][j + 4]] = ret8[3][4];
			ret->element[3][mat->nzero_index[i][j + 3]] = ret8[3][3];
			ret->element[3][mat->nzero_index[i][j + 2]] = ret8[3][2];
			ret->element[3][mat->nzero_index[i][j + 1]] = ret8[3][1];
			ret->element[3][mat->nzero_index[i][j    ]] = ret8[3][0];

			// total_index++;
			total_index += _BNC_D_WIDTH;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
	}

#elif defined(__ARM_NEON) // ARM Neon
	float64x2_t a2, vb2[QDSIZE], tmp2[QDSIZE], ret2[QDSIZE];
	long int jmax, jres, col_dim;
	double vset[0];

	for(i = 0; i < mat->row_dim; i++)
	{
		vb2[0] = vdupq_n_f64(vec->element[0][i]);
		vb2[1] = vdupq_n_f64(vec->element[1][i]);
		vb2[0] = vdupq_n_f64(vec->element[0][i]);
		vb2[1] = vdupq_n_f64(vec->element[1][i]);

		// jmax = (mat->nzero_col_dim[i] / 2) * 2;
		// jres =  mat->nzero_col_dim[i] % 2;
		jmax = (mat->real_nzero_col_dim[i] / 2) * 2;
		jres =  mat->real_nzero_col_dim[i] % 2;

		//jmax = (mat->row_dim / 2) * 2;
		//jres =  mat->row_dim % 2;
		for(j = 0; j < jmax; j += 2)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			a2 = vld1q_f64(&(mat->element[total_index]));
			//a2[1] = vld1q_f64(&(mat->element[1][total_index]));
			//a2[0] = vld1q_f64(&(mat->element[0][total_index]));
			//a2[1] = vld1q_f64(&(mat->element[1][total_index]));

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[0][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[0][mat->nzero_index[i][j + 1]];
    		ret2[0] = vld1q_f64(vset);
			//ret2[0] = _mm256_set_pd(
			//	vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[1][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[1][mat->nzero_index[i][j + 1]];
    		ret2[1] = vld1q_f64(vset);
			//ret2[1] = _mm256_set_pd(
			//	vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[2][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[2][mat->nzero_index[i][j + 1]];
    		ret2[2] = vld1q_f64(vset);
			//ret2[0] = _mm256_set_pd(
			//	vset[1], // ret->element[0][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[0][mat->nzero_index[i][j    ]]
			//);

			vset[0] = 0.0; vset[1] = 0.0;
			if((j    ) < mat->nzero_col_dim[i]) vset[0] = ret->element[3][mat->nzero_index[i][j    ]];
			if((j + 1) < mat->nzero_col_dim[i]) vset[1] = ret->element[3][mat->nzero_index[i][j + 1]];
    		ret2[3] = vld1q_f64(vset);
			//ret2[1] = _mm256_set_pd(
			//	vset[1], // ret->element[1][mat->nzero_index[i][j + 1]],
			//	vset[0]  // ret->element[1][mat->nzero_index[i][j    ]]
			//);

			//ret2 = vfmaq_f64(ret2, a2, vb2);
			//_bncneon_rqd_mul(tmp2, a2, vb2);
			_bncneon_rqd_mul_d(tmp2, vb2, a2);
			_bncneon_rqd_add(ret2, ret2, tmp2);

			if((j    ) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j    ]] = ret2[0][0];
				ret->element[1][mat->nzero_index[i][j    ]] = ret2[1][0];
				ret->element[2][mat->nzero_index[i][j    ]] = ret2[2][0];
				ret->element[3][mat->nzero_index[i][j    ]] = ret2[3][0];
			}
			if((j + 1) < mat->nzero_col_dim[i])
			{
				ret->element[0][mat->nzero_index[i][j + 1]] = ret2[0][1];
				ret->element[1][mat->nzero_index[i][j + 1]] = ret2[1][1];
				ret->element[2][mat->nzero_index[i][j + 1]] = ret2[2][1];
				ret->element[3][mat->nzero_index[i][j + 1]] = ret2[3][1];

			}
			// total_index++;
			total_index += 2;
		}
		//printf("%ld mat_vec_i, jmax, jrec = %25.17e, %ld -> %ld, %ld\n", i, mat_vec_i, mat->nzero_col_dim[i], jmax, jres);
	}



#else // __AVX2__

	for(i = 0; i < mat->row_dim; i++)
	{
		vec_i[0] = vec->element[0][i];
		vec_i[1] = vec->element[1][i];
		vec_i[2] = vec->element[2][i];
		vec_i[3] = vec->element[3][i];

		for(j = 0; j < mat->nzero_col_dim[i]; j++)
		{
			//ret->element[mat->nzero_index[i][j]] += mat->element[total_index] * vec->element[i];
			mat_ji = mat->element[total_index];
			//mat_ji[1] = mat->element[1][total_index];
			//mat_ji[2] = mat->element[2][total_index];
			//mat_ji[3] = mat->element[3][total_index];

			ret_j[0] = ret->element[0][mat->nzero_index[i][j]];
			ret_j[1] = ret->element[1][mat->nzero_index[i][j]];
			ret_j[2] = ret->element[2][mat->nzero_index[i][j]];
			ret_j[3] = ret->element[3][mat->nzero_index[i][j]];

			//rqd_mul(tmp, mat->element[total_index]), get_qdvector_i(vec, i));
			//rqd_mul(tmp, mat_ji, vec_i);
			rqd_mul_d(tmp, vec_i, mat_ji);
			//rqd_add(ret->element[mat->nzero_index[i][j]], ret->element[mat->nzero_index[i][j]], tmp);
			rqd_add(ret_j, ret_j, tmp);
			set_qdvector_i(ret, mat->nzero_index[i][j], ret_j);
			total_index++;
		}
	}

#endif // __AVX2__

	return SUCCESS;
}

/* Power Method for Randomly Sparse Matrices */
/* 	QDVector *evec: the eigenvector for max eigenvalue */
/* 	QDRSMatrix *drsmat: Randomly sparse matrix */
/* 	double *reps, *aeps: Relative and Absolute tolerance */
/* 	long int max_times: Maximum iterative times of Power method */
void qdpower_sp(double max_eig[QDSIZE], QDVector evec, QDRSMatrix mat, double reps[QDSIZE], double aeps[QDSIZE], long int max_times)
{
	long int i, absmax_index, times;
	qdfloat absmax_new_evec, old_max_eig, tmp, tmp2;
	QDVector new_evec;

	new_evec = init_qdvector(mat->row_dim);

	/* initialize evec */
	for(i = 0; i < evec->dim; i++)
		rqd_set_ui(get_qdvector_i(evec, i), 1UL);
		//evec->element[i] = 1.0;

	/* main loop */
	//old_max_eig = 0.0;
	rqd_set_ui(old_max_eig.val, 0UL);
	for(times = 0; times < max_times; times++)
	{
		/* w := A * x */
		mul_qdrsmatrix_qdvec(new_evec, mat, evec);
		absmax_index = absmax_index_qdvector(absmax_new_evec.val, new_evec);
//		max_eig = absmax_new_evec / evec->element[absmax_index];
		rqd_div(max_eig, absmax_new_evec.val, get_qdvector_i(evec, absmax_index));
//		smul_mpfvector(evec, 1.0 / absmax_new_evec, new_evec);
//		smul_mpfvector(evec, 1.0 / norm1_MPFVector(new_evec), new_evec); // Baba's example
		norm1_qdvector(tmp.val, new_evec);
		rqd_ui_div(tmp.val, 1UL, tmp.val);
		cmul_qdvector(evec, tmp.val, new_evec);

//		if((fabs(max_eig - old_max_eig) <= reps * fabs(old_max_eig) + aeps) && (times >= 2))
		rqd_sub(tmp.val, max_eig, old_max_eig.val);
		rqd_abs(tmp.val, tmp.val);
		
		rqd_abs(tmp2.val, old_max_eig.val);
		rqd_mul(tmp2.val, reps, tmp2.val);
		rqd_add(tmp2.val, tmp2.val, aeps);
		if((rqd_cmp(tmp.val, tmp2.val) <= 0) && (times >= 2))
		{
			fprintf(stderr, "Convergent!(Iterative Times = %ld)\n", times);
			break;
		}
		if(times % 10 == 0)
			fprintf(stderr, "%5ld %25.17e\n", times, rqd_get_d(max_eig));
		//old_max_eig = max_eig;
		rqd_set(old_max_eig.val, max_eig);
	}

	free_qdvector(new_evec);

//	return max_eig;
	return;
}

/* Select index of absolute maximum element and its value in QDVector */
long int absmax_index_qdvector(double ret[QDSIZE], QDVector vec)
{
	long int absmax_index, i;
	qdfloat abs_element;

	rqd_set_ui(ret, 0UL);
	absmax_index = 0;
	for(i = 0; i < vec->dim; i++)
	{
		rqd_abs(abs_element.val, get_qdvector_i(vec, i));
		if(rqd_cmp(ret, abs_element.val) < 0)
		{
			absmax_index = i;
			//*ret = abs_element;
		}
	}

	rqd_set(ret, get_qdvector_i(vec, absmax_index));

	return absmax_index;
}

// 2024-08-02 (Fri) T.Kouya
/* c := (qd)a */
void subst_qdrsmatrix_drsmat(QDRSMatrix c, DRSMatrix a)
{
	long int i, j, total_index;

	if((c->row_dim != a->row_dim) || (c->col_dim != a->col_dim))
	{
		fprintf(stderr, "ERROR: subst_qdrsmatrix_drsmat\n");
		return;
	}

	//for(total_index = 0; total_index < c->nzero_total_num; total_index++)
	for(total_index = 0; total_index < c->real_nzero_total_num; total_index++)
	{
		c->element[0][total_index] = a->element[total_index];
		c->element[1][total_index] = (double)0.0;
		c->element[2][total_index] = (double)0.0;
		c->element[3][total_index] = (double)0.0;
	}
}

// 2024-08-02 (Fri) T.Kouya
/* c := (d)a */
void subst_drsmatrix_qdrsmat(DRSMatrix c, QDRSMatrix a)
{
	long int i, j, ij_index;

	if((c->row_dim != a->row_dim) || (c->col_dim != a->col_dim))
	{
		fprintf(stderr, "ERROR: subst_drsmatrix_qdrsmat\n");
		return;
	}

	//for(ij_index = 0; ij_index < c->nzero_total_num; ij_index++)
	for(ij_index = 0; ij_index < c->real_nzero_total_num; ij_index++)
	{
		c->element[ij_index] = a->element[0][ij_index];
	}
}

// 2024-08-02 (Fri) T.Kouya
// absmax_row_qdrsmatrix
void absmax_row_qdrsmatrix(double mu[QDSIZE], long int *max_j, long int row_index, QDRSMatrix mat)
{
    long int j, max_index = 0;
    double abs_aij[QDSIZE], aij[QDSIZE];

	//mu = fabs(mat[i * col_dim + 0]);
	get_qdrsmatrix_ij(aij, mat, row_index, 0);
    rqd_abs(mu, aij);

	//for(j = 1; j < mat->nzero_col_dim[row_index]; j++)
	for(j = 1; j < mat->real_nzero_col_dim[row_index]; j++)
	{
		get_qdrsmatrix_ij(aij, mat, row_index, j);
		rqd_abs(abs_aij, aij);
		if(rqd_cmp(abs_aij, mu) > 0)
        {
			//mu = abs_aij;
            rqd_set(mu, abs_aij);
            max_index = j;
        }
	}

    if(max_j != NULL)
        *max_j = max_index;

    //return mu;
    return;
}

// 2024-08-04 (SUN) T.Kouya
// absmax_col_qdrsmatrix
void absmax_col_qdrsmatrix(double mu[QDSIZE], long int *max_i, long int col_index, QDRSMatrix mat)
{
    long int i, max_index = 0;
    double abs_aij[QDSIZE], aij[QDSIZE];

	//mu = fabs(mat[i * col_dim + 0]);
	get_qdrsmatrix_ij(aij, mat, 0, col_index);
    rqd_abs(mu, aij);

	//for(j = 1; j < mat->nzero_col_dim[row_index]; j++)
	for(i = 1; i < mat->row_dim; i++) //mat->real_nzero_col_dim[row_index]; j++)
	{
		get_qdrsmatrix_ij(aij, mat, i, col_index);
		rqd_abs(abs_aij, aij);
		if(rqd_cmp(abs_aij, mu) > 0)
        {
			//mu = abs_aij;
            rqd_set(mu, abs_aij);
            max_index = i;
        }
	}

    if(max_i != NULL)
        *max_i = max_index;

    //return mu;
    return;
}

// 2024-08-02 (Fri) T.Kouya
/* c := a + (double)b */
void add_qdrsmatrix_drsmat(QDRSMatrix c, QDRSMatrix a, DRSMatrix b)
{
	long int i, j, row_dim, col_dim, real_row_dim, real_col_dim, real_total_dim, index;
    double aij[QDSIZE], bij[QDSIZE], tmp[QDSIZE];

	/* check row_dim */
	if((a->row_dim != b->row_dim) || (b->row_dim != c->row_dim) || (c->row_dim != a->row_dim))
	{
		fprintf(stderr, "ERROR: add_qdrsmatrix_drsmat\n");
		return;
	}
	row_dim = c->row_dim;
	//real_row_dim = c->real_row_dim;

	/* check col_dim */
	if((a->col_dim != b->col_dim) || (b->col_dim != c->col_dim) || (c->col_dim != a->col_dim))
	{
		fprintf(stderr, "ERROR: add_qdrsmatrix_drsmat\n");
		return;
	}
	col_dim = c->col_dim;
	//real_col_dim = c->real_col_dim;

	real_total_dim = c->nzero_total_num; // real_row_dim * real_col_dim;

	for(index = 0; index < c->real_nzero_total_num; index++)
	{
		//rqd_add_d(tmp, get_qdrsmatrix_ij(a, i, j), get_drsmatrix_ij(b, i, j));
        bij[0] = b->element[index];
		bij[1] = 0.0; 
		bij[2] = 0.0;
		bij[3] = 0.0;
		aij[0] = a->element[0][index];
		aij[1] = a->element[1][index];
		aij[2] = a->element[2][index];
		aij[3] = a->element[3][index];
        rqd_add(tmp, aij, bij);
		c->element[0][index] = tmp[0];
		c->element[1][index] = tmp[1];
		c->element[2][index] = tmp[2];
		c->element[3][index] = tmp[2];
	}
}

// 2024-07-31(Wed) T.Kouya
/* c := a - (double)b */
void sub_qdrsmatrix_drsmat(QDRSMatrix c, QDRSMatrix a, DRSMatrix b)
{
	long int i, j, row_dim, col_dim, real_row_dim, real_col_dim, real_total_dim, index;
    double aij[QDSIZE], bij[QDSIZE], tmp[QDSIZE];

	/* check row_dim */
	if((a->row_dim != b->row_dim) || (b->row_dim != c->row_dim) || (c->row_dim != a->row_dim))
	{
		fprintf(stderr, "ERROR: sub_qdrsmatrix_drsmat\n");
		return;
	}
	row_dim = c->row_dim;
	//real_row_dim = c->real_row_dim;

	/* check col_dim */
	if((a->col_dim != b->col_dim) || (b->col_dim != c->col_dim) || (c->col_dim != a->col_dim))
	{
		fprintf(stderr, "ERROR: sub_qdrsmatrix_drsmat\n");
		return;
	}
	col_dim = c->col_dim;
	//real_col_dim = c->real_col_dim;

	real_total_dim = c->nzero_total_num; // real_row_dim * real_col_dim;

	for(index = 0; index < c->real_nzero_total_num; index++)
	{
		//rqd_add_d(tmp, get_qdrsmatrix_ij(a, i, j), get_drsmatrix_ij(b, i, j));
        bij[0] = b->element[index];
		bij[1] = 0.0; 
		bij[2] = 0.0;
		bij[3] = 0.0;
		aij[0] = a->element[0][index];
		aij[1] = a->element[1][index];
		aij[2] = a->element[2][index];
		aij[3] = a->element[3][index];
        rqd_sub(tmp, aij, bij);
		c->element[0][index] = tmp[0];
		c->element[1][index] = tmp[1];
		c->element[2][index] = tmp[2];
		c->element[3][index] = tmp[3];
	}
}

// 2024-07-31(Wed) T.Kouya
// SplitMat_A
// return real_num_div
int split_qdrsmatrix_drsmat(DRSMatrix ret_mat[], int num_div, QDRSMatrix org_mat)
{
	long int i, j, index, row_dim, col_dim, real_total_dim, total_index;
	long int num_digits = 53; // IEEE double prec.
    int real_num_div;
	//long int num_digits = SPLIT_NUM_DIGITS; // IEEE double prec.
	//long int num_digits = 64; // IEEE double prec.
	//double *s;
    QDRSMatrix tmp_org_mat;
    DRSMatrix s, tmp_mat[2], in_ret_mat; 
	double mu, mu_total, abs_aij, t_exp, power2;

    row_dim = org_mat->row_dim;
    //row_dim = org_mat->real_row_dim;
    col_dim = org_mat->col_dim;
    //real_total_dim = org_mat->real_row_dim * org_mat->real_col_dim;
	real_total_dim = org_mat->nzero_total_num;

	// threshold matrix 
	//s = (double *)calloc(row_dim * col_dim, sizeof(double));
    //s = init_ddmatrix(row_dim, col_dim);
    s = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
	set0_drsmatrix(s);

    //tmp_mat[0] = init_ddmatrix(row_dim, col_dim);
    //tmp_mat[1] = init_ddmatrix(row_dim, col_dim);
    tmp_mat[0] = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
    tmp_mat[1] = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
	if(ret_mat == NULL)
		in_ret_mat = init_set_drsmatrix_qdrsmat(org_mat);
	else
		in_ret_mat = ret_mat[0];

    // tmp_org_mat := org_mat;
    tmp_org_mat = init_set_qdrsmatrix(org_mat);
   	//subst_ddmatrix(tmp_org_mat, org_mat);

    real_num_div = 0;
    for(index = 0; index < num_div; index++)
    {
        //printf("In split_ddmatrix ... index= %d\n", index);
        //set0_dmatrix(ret_mat[index]);
		if(ret_mat != NULL)
			in_ret_mat = ret_mat[index];

        //subst_drsmatrix_qdrsmat(ret_mat[index], tmp_org_mat);
        subst_drsmatrix_qdrsmat(in_ret_mat, tmp_org_mat);

        // mu[i] = max_j |mat[i, j]|
        // mu_total = sum mu
        mu_total = 0.0;

		total_index = 0;
        for(i = 0; i < row_dim; i++)
        {
            //absmax_row_ddmatrix(mu, NULL, i, tmp_org_mat);
            //mu = absmax_row_drsmatrix(NULL, i, ret_mat[index]);
            mu = absmax_row_drsmatrix(NULL, i, in_ret_mat);

            mu_total += mu;

            // t_exp = ceil(log2(mu)) + ceil(s + log2(col_dim + 1) / 2)
            //t_exp[0] = ceil(DLOG2(mu[0])) + ceil(((double)num_digits + DLOG2((double)(col_dim + 1))) / 2.0);
            //t_exp[1] = 0.0;
            //printf("     num, num_digits, col_dim + 1   = %15.7e, %ld, %ld\n", mu, num_digits, col_dim + 1);
            //printf("log2(num, num_digits + col_dim + 1) = %15.7e, %15.7e\n", DLOG2(mu), ceil(((double)num_digits + DLOG2((double)(col_dim + 1))) / 2.0));
            //t_exp = ceil(DLOG2(mu)) + ceil(((double)num_digits + DLOG2((double)(col_dim + 1))) / 2.0);
            //t_exp = ceil(DLOG2(mu)) + ceil(((double)num_digits + DLOG2((double)(ret_mat[index]->nzero_col_dim[i]))) / 2.0);
            t_exp = ceil(DLOG2(mu)) + ceil(((double)num_digits + DLOG2((double)(in_ret_mat->nzero_col_dim[i]))) / 2.0);

            // s[i, j] = 2^t_exp
            //rqd_pow(power2, two, t_exp);
            //rqd_pow_mpfr(power2, two, t_exp);
            power2 = pow(2.0, t_exp);
            //printf("power2 = %15.7e\n", power2);
            //printf("index, i, power2 = %ld, %ld, %25.17e\n", index, i, power2[0]);
            //for(j = 0; j < ret_mat[index]->real_nzero_col_dim[i]; j++)
            for(j = 0; j < in_ret_mat->real_nzero_col_dim[i]; j++)
            {
                //s[i * col_dim + j] = pow(2.0, t_exp);
                //set_ddmatrix_ij(s, i, j, power2);
                //set_dmatrix_ij(s, i, j, power2);
				s->element[total_index++] = power2;
            }
        }

        // if ret_mat[index] == 0 -> break
        if(mu_total == 0.0) break;

        // split org_mat to ret_high_mat and ret_low_mat
#ifdef USE_IMKL
        //real_total_dim = ret_mat[index]->nzero_total_num; //ret_mat[index]->real_row_dim * ret_mat[index]->real_col_dim;
        //real_total_dim = ret_mat[index]->real_nzero_total_num; //ret_mat[index]->real_row_dim * ret_mat[index]->real_col_dim;
        real_total_dim = in_ret_mat->real_nzero_total_num; //ret_mat[index]->real_row_dim * ret_mat[index]->real_col_dim;

        // tmp_mat := mat + s
        //blas_dcopy(real_total_dim, ret_mat[index]->element, 1, tmp_mat[0]->element, 1);
        //cblas_daxpy(real_total_dim, 1.0, s->element, 1, tmp_mat[0]->element, 1);
        //cblas_daxpy(real_total_dim, 1.0, s->element, 1, ret_mat[index]->element, 1);
        cblas_daxpy(real_total_dim, 1.0, s->element, 1, in_ret_mat->element, 1);

        // high_mat := tmp_mat - s
        //cblas_daxpy(real_total_dim, -1.0, s->element, 1, ret_mat[index]->element, 1);
        cblas_daxpy(real_total_dim, -1.0, s->element, 1, in_ret_mat->element, 1);

        // low_mat := mat - high_mat
        //cblas_dcopy(real_total_dim, tmp_mat[0]->element, 1, ret_mat[index]->element, 1);
#else // USE_IMKL
        // tmp_mat := mat + s
        //add_drsmatrix(tmp_mat[0], ret_mat[index], s);
        add_drsmatrix(tmp_mat[0], in_ret_mat, s);

        // high_mat := tmp_mat - s
        sub_drsmatrix(tmp_mat[1], tmp_mat[0], s);
        //subst_drsmatrix(ret_mat[index], tmp_mat[1]);
        subst_drsmatrix(in_ret_mat, tmp_mat[1]);

#endif // USE_IMKL

        // low_mat := mat - high_mat
        //sub_ddmatrix_dmat(tmp_org_mat, tmp_org_mat, tmp_mat[1]);
        //sub_qdrsmatrix_drsmat(tmp_org_mat, tmp_org_mat, ret_mat[index]);
        sub_qdrsmatrix_drsmat(tmp_org_mat, tmp_org_mat, in_ret_mat);

        // real_num_div = index + 1;
        real_num_div = index + 1;
    }

	// free s
	//free_ddmatrix(s);
	free_drsmatrix(s);
    free_qdrsmatrix(tmp_org_mat);
    free_drsmatrix(tmp_mat[0]);
    free_drsmatrix(tmp_mat[1]);
	if(ret_mat == NULL)
		free_drsmatrix(in_ret_mat); 

    return real_num_div;
}

// Matrix-Vector multiplication based on Ozaki scheme
void mul_qdrsmatrix_qdvec_oz(QDVector ret, QDRSMatrix a, int max_num_div_a, QDVector vb, int max_num_div_vb) //, int num_digits)
{
    int i, j;
    int real_num_div_a, real_num_div_vb, *i_div_a_csr, *j_div_a_csr, total_index;
    long int vec_dim = ret->dim, row_dim = a->row_dim, col_dim = a->col_dim;
    DRSMatrix *div_a;
    DVector *div_vb, div_ret;
#ifdef USE_IMKL
	int *i_div_a_csr_start, *i_div_a_csr_end;
	sparse_matrix_t *mkl_div_a;
	struct matrix_descr descr;
#endif // USE_IMKL

	div_a = (DRSMatrix *)calloc(max_num_div_a, sizeof(DRSMatrix));
    div_vb = (DVector *)calloc(max_num_div_vb, sizeof(DVector));

	// convert our CSR to intel math kernel csr format
#ifdef USE_IMKL
	#ifdef USE_IMKL_OLD
	//i_div_a_csr = (int *)calloc(a->nzero_total_num, sizeof(int));
	i_div_a_csr = (int *)calloc(a->row_dim + 1, sizeof(int));
	//j_div_a_csr = (int *)calloc(a->nzero_total_num, sizeof(int));
	j_div_a_csr = (int *)calloc(a->real_nzero_total_num, sizeof(int));
	total_index = 0;
	for(i = 0; i < row_dim; i++)
	{
		i_div_a_csr[i] = total_index;
		//if(a->nzero_col_dim[i] >= 1)
		if(a->real_nzero_col_dim[i] >= 1)
		{
			for(j = 0; j < a->nzero_col_dim[i]; j++)
			{
				j_div_a_csr[total_index] = a->nzero_index[i][j];
				total_index++;
			}
			// embed gap among nzero_col_dim and real_nzero_col_dim
			for(j = a->nzero_col_dim[i]; j < a->real_nzero_col_dim[i]; j++)
			{
				j_div_a_csr[total_index] = a->nzero_index[i][a->nzero_col_dim[i] - 1] + (j + 1 - a->nzero_col_dim[i]);
				total_index++;
			}
		}
	}
	//i_div_a_csr[row_dim] = a->nzero_total_num;
	i_div_a_csr[row_dim] = a->real_nzero_total_num;
	#else // New
	mkl_div_a = (sparse_matrix_t *)calloc(max_num_div_a, sizeof(sparse_matrix_t));
	convert_indeces_qdrsmatrix_mkl_csrmat(i_div_a_csr_start, i_div_a_csr_end, j_div_a_csr, a);
	#endif // USE_IMKL_OLD
#endif // USE_IMKL

	for(i = 0; i < max_num_div_a; i++)
		div_a[i] = init_set_drsmatrix_qdrsmat(a); // a->row_dim, a->nzero_col_dim, a->nzero_total_num);
        //div_a[i] = init_drsmatrix(row_dim, col_dim);

    for(i = 0; i < max_num_div_vb; i++)
        div_vb[i] = init_dvector(vec_dim);

    div_ret = init_dvector(vec_dim);

    real_num_div_a = split_qdrsmatrix_drsmat(div_a, max_num_div_a, a);
    real_num_div_vb = split_qdvector_dvec(div_vb, max_num_div_vb, vb);

    set0_qdvector(ret);
    for(i = 0; i < real_num_div_a; i++)
    {
#ifdef USE_IMKL
		subst_drsmatrix_mkl_csrmat(&mkl_div_a[i], i_div_a_csr_start, i_div_a_csr_end, j_div_a_csr, div_a[i]);
#endif // USE_IMKL
		for(j = 0; j < real_num_div_vb; j++)
        {

#ifdef USE_IMKL
            set0_dvector(div_ret);
	#ifdef USE_IMKL_OLD
			//mul_drsmatrix_dvec(vec[8], a, vec[6]);
			// Old MKL SpMV
			mkl_cspblas_dcsrgemv("N", &row_dim, div_a[i]->element, i_div_a_csr, j_div_a_csr, div_vb[j]->element, div_ret->element);
			// New MKL SpMV
			//mkl_sparse_d_mv(SPARSE_OPERATION_NON_TRANSPOSE, div_a[i]->element, i_div_a_csr, j_div_a_csr, div_vb[j]->element, div_ret->element);
	#else // USE_IMKL_OLD
			descr.type = SPARSE_MATRIX_TYPE_GENERAL;
			//descr.mode = ?
			//descr.diag = ?
			mkl_sparse_d_mv(
				SPARSE_OPERATION_NON_TRANSPOSE,
				(double)1.0,
				mkl_div_a[i],
				descr,
				div_vb[j]->element,
				(double)0.0,
				div_ret->element
			);
	#endif // USE_IMKL_OLD
#else // USE_IMKL
            mul_drsmatrix_dvec(div_ret, div_a[i], div_vb[j]);
#endif // USE_IMKL
			//printf("%ld,%ld ||div_ret||_F = %10.3e\n", i, j, norm2_dvector(div_ret));
            add_qdvector_dvec(ret, ret, div_ret);
       }
    }

#ifdef USE_IMKL
	#ifdef USE_IMKL_OLD
	free(i_div_a_csr);
	#else // New!
	free(i_div_a_csr_start);
	free(i_div_a_csr_end);
	for(i = 0; i < max_num_div_a; i++)
		mkl_sparse_destroy(mkl_div_a[i]);
	free(mkl_div_a);
	#endif // USE_IMKL_OLD
	free(j_div_a_csr);
#endif // USE_IMKL

	free_dvector(div_ret);
    for(i = 0; i < max_num_div_a; i++)
        free_drsmatrix(div_a[i]);
    for(i = 0; i < max_num_div_vb; i++)
        free_dvector(div_vb[i]);

    free(div_a);
    free(div_vb);

}

// 2024-08-04 (Sun) T.Kouya
// SplitMat_B
// return real_num_div
int split_qdrsmatrix_t_drsmat(DRSMatrix ret_mat[], int num_div, QDRSMatrix org_mat)
{
	long int i, j, index, row_dim, col_dim, real_total_dim;
	int real_num_div, num_digits = 53; // IEEE double prec.
	//int flag_stop = 0; //, num_digits = SPLIT_NUM_DIGITS; // IEEE double prec.
	//int flag_stop = 0, num_digits = 64; // IEEE double prec.
	//double *s;
    QDRSMatrix tmp_org_mat;
    DRSMatrix s, tmp_mat[2], in_ret_mat;
	//double mu[DDSIZE], abs_aij[DDSIZE], t_exp[DDSIZE], power2[DDSIZE], two[DDSIZE] = {2.0, 0.0};
	double mu, abs_aij, t_exp, power2, mu_total;

    row_dim = org_mat->row_dim;
    //row_dim = org_mat->real_row_dim;
    col_dim = org_mat->col_dim;
    //real_total_dim = org_mat->real_row_dim * org_mat->real_col_dim;
	real_total_dim = org_mat->nzero_total_num;

	// threshold matrix 
	//s = (double *)calloc(row_dim * col_dim, sizeof(double));
    //s = init_ddmatrix(row_dim, col_dim);
    s = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
	set0_drsmatrix(s);

    //tmp_mat[0] = init_ddmatrix(row_dim, col_dim);
    //tmp_mat[1] = init_ddmatrix(row_dim, col_dim);
    tmp_mat[0] = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
    tmp_mat[1] = init_set_drsmatrix_qdrsmat(org_mat); //row_dim, org_mat->nzero_col_dim, org_mat->nzero_total_num);
	if(ret_mat == NULL)
		in_ret_mat = init_set_drsmatrix_qdrsmat(org_mat);

    // tmp_org_mat := org_mat;
    tmp_org_mat = init_set_qdrsmatrix(org_mat);
   	//subst_ddmatrix(tmp_org_mat, org_mat);

    real_num_div = 0;
    for(index = 0; index < num_div; index++)
    {
        //subst_dmatrix_ddmat(ret_mat[index], tmp_org_mat);
		if(ret_mat != NULL)
			in_ret_mat = ret_mat[index];

        //subst_drsmatrix_qdrsmat(ret_mat[index], tmp_org_mat);
		subst_drsmatrix_qdrsmat(in_ret_mat, tmp_org_mat);

        // mu[j] = max_j |mat[i, j]|
        // mu_total += mu
        mu_total = 0.0;
        for(j = 0; j < col_dim; j++)
        {
            /* mu = fabs(mat[0 * col_dim + j]);
            for(i = 1; i < row_dim; i++)
            {
                abs_aij = fabs(mat[i * col_dim + j]);
                if(abs_aij > mu)
                    mu = abs_aij;
            }
            */
            //mu = absmax_col_drsmatrix(NULL, j, ret_mat[index]);
            mu = absmax_col_drsmatrix(NULL, j, in_ret_mat);
            mu_total += mu;
            //printf("mu%d: %15.7e ", j, mu);

            // t_exp = ceil(log2(mu)) + ceil(s + log2(col_dim + 1) / 2)
            //t_exp[0] = ceil(DLOG2(mu[0])) + ceil(((double)num_digits + DLOG2((double)(row_dim + 1))) / 2.0);
            //t_exp[1] = 0.0;
            t_exp = ceil(DLOG2(mu)) + ceil(((double)num_digits + DLOG2((double)(row_dim + 1))) / 2.0);
            //if(isnan(t_exp))
            //    flag_stop = 1;

            // s[i, j] = 2^t_exp
            //rdd_pow(power2, two, t_exp);
            //rdd_pow_mpfr(power2, two, t_exp);
            power2 = pow(2.0, t_exp);

            //printf("index, j, power2 = %ld, %ld, %25.17e\n", index, j, power2[0]);
            for(i = 0; i < row_dim; i++)
                set_drsmatrix_ij(s, i, j, power2);
                //s[i * col_dim + j] = pow(2.0, t_exp);
        }
        //if(flag_stop == 1)
        //    break;
        if(mu_total == 0.0) break;

#ifdef USE_IMKL
        //real_total_dim = ret_mat[index]->real_row_dim * ret_mat[index]->real_col_dim;
		//real_total_dim = ret_mat[index]->real_nzero_total_num;
		real_total_dim = in_ret_mat->real_nzero_total_num;

        // tmp_mat := mat + s
        //blas_dcopy(real_total_dim, ret_mat[index]->element, 1, tmp_mat[0]->element, 1);
        //cblas_daxpy(real_total_dim, 1.0, s->element, 1, tmp_mat[0]->element, 1);
        //cblas_daxpy(real_total_dim, 1.0, s->element, 1, ret_mat[index]->element, 1);
        cblas_daxpy(real_total_dim, 1.0, s->element, 1, in_ret_mat->element, 1);

        // high_mat := tmp_mat - s
        //cblas_daxpy(real_total_dim, -1.0, s->element, 1, ret_mat[index]->element, 1);
        cblas_daxpy(real_total_dim, -1.0, s->element, 1, in_ret_mat->element, 1);

        // low_mat := mat - high_mat
        //cblas_dcopy(real_total_dim, tmp_mat[0]->element, 1, ret_mat[index]->element, 1);
#else // USE_IMKL
        // tmp_mat := mat + s
        //add_drsmatrix(tmp_mat[0], ret_mat[index], s);
        add_drsmatrix(tmp_mat[0], in_ret_mat, s);

        // high_mat := tmp_mat - s
        sub_drsmatrix(tmp_mat[1], tmp_mat[0], s);
        //subst_drsmatrix(ret_mat[index], tmp_mat[1]);
        subst_drsmatrix(in_ret_mat, tmp_mat[1]);

#endif // USE_IMKL

        // low_mat := mat - high_mat
        //sub_qdrsmatrix_drsmat(tmp_org_mat, tmp_org_mat, ret_mat[index]);
        sub_qdrsmatrix_drsmat(tmp_org_mat, tmp_org_mat, in_ret_mat);
        //sub_ddmatrix_dmat(tmp_org_mat, tmp_org_mat, tmp_mat[1]);

        real_num_div = index + 1;
    }

    // free s
	free_drsmatrix(s);
    free_drsmatrix(tmp_mat[0]);
    free_drsmatrix(tmp_mat[1]);
    free_qdrsmatrix(tmp_org_mat);
	if(ret_mat == NULL)
		free_drsmatrix(in_ret_mat);

    return real_num_div;
}

// 2024-08-02(Fri) T.Kouya
// Transposed Matrix-Vector multiplication based on Ozaki scheme
void mul_qdrsmatrixt_qdvec_oz(QDVector ret, QDRSMatrix a, int max_num_div_a, QDVector vb, int max_num_div_vb)
{
    int i, j;
    int real_num_div_a, real_num_div_vb, *i_div_a_csr, *j_div_a_csr, total_index;
    long int vec_dim = ret->dim, row_dim = a->row_dim, col_dim = a->col_dim;
    DRSMatrix *div_a;
    DVector *div_vb, div_ret;
#ifdef USE_IMKL
	int *i_div_a_csr_start, *i_div_a_csr_end;
	sparse_matrix_t *mkl_div_a;
	struct matrix_descr descr;
#endif // USE_IMKL

    div_a = (DRSMatrix *)calloc(max_num_div_a, sizeof(DRSMatrix));
    div_vb = (DVector *)calloc(max_num_div_vb, sizeof(DVector));

	// convert our CSR to intel math kernel csr format
#ifdef USE_IMKL
	#ifdef USE_IMKL_OLD
	//i_div_a_csr = (int *)calloc(a->nzero_total_num, sizeof(int));
	i_div_a_csr = (int *)calloc(a->row_dim + 1, sizeof(int));
	//j_div_a_csr = (int *)calloc(a->nzero_total_num, sizeof(int));
	j_div_a_csr = (int *)calloc(a->real_nzero_total_num, sizeof(int));
	total_index = 0;
	for(i = 0; i < row_dim; i++)
	{
		i_div_a_csr[i] = total_index;
		//if(a->nzero_col_dim[i] >= 1)
		if(a->real_nzero_col_dim[i] >= 1)
		{
			for(j = 0; j < a->nzero_col_dim[i]; j++)
			{
				j_div_a_csr[total_index] = a->nzero_index[i][j];
				total_index++;
			}
			// embed gap among nzero_col_dim and real_nzero_col_dim
			for(j = a->nzero_col_dim[i]; j < a->real_nzero_col_dim[i]; j++)
			{
				j_div_a_csr[total_index] = a->nzero_index[i][a->nzero_col_dim[i] - 1] + (j + 1 - a->nzero_col_dim[i]);
				total_index++;
			}
		}
	}
	//i_div_a_csr[row_dim] = a->nzero_total_num;
	i_div_a_csr[row_dim] = a->real_nzero_total_num;
	#else // New
	mkl_div_a = (sparse_matrix_t *)calloc(max_num_div_a, sizeof(sparse_matrix_t));
	convert_indeces_qdrsmatrix_mkl_csrmat(i_div_a_csr_start, i_div_a_csr_end, j_div_a_csr, a);
	#endif // USE_IMKL_OLD
#endif // USE_IMKL

	for(i = 0; i < max_num_div_a; i++)
		div_a[i] = init_set_drsmatrix_qdrsmat(a); // a->row_dim, a->nzero_col_dim, a->nzero_total_num);
        //div_a[i] = init_drsmatrix(row_dim, col_dim);

    for(i = 0; i < max_num_div_vb; i++)
        div_vb[i] = init_dvector(vec_dim);

    div_ret = init_dvector(vec_dim);

    //real_num_div_a = split_qdrsmatrix_drsmat(div_a, max_num_div_a, a);
    real_num_div_a = split_qdrsmatrix_t_drsmat(div_a, max_num_div_a, a);
    real_num_div_vb = split_qdvector_dvec(div_vb, max_num_div_vb, vb);

    set0_qdvector(ret);
    for(i = 0; i < real_num_div_a; i++)
    {
#ifdef USE_IMKL
		subst_drsmatrix_mkl_csrmat(&mkl_div_a[i], i_div_a_csr_start, i_div_a_csr_end, j_div_a_csr, div_a[i]);
#endif // USE_IMKL
		for(j = 0; j < real_num_div_vb; j++)
        {

#ifdef USE_IMKL
            set0_dvector(div_ret);
	#ifdef USE_IMKL_OLD
			mkl_cspblas_dcsrgemv("T", &row_dim, div_a[i]->element, i_div_a_csr, j_div_a_csr, div_vb[j]->element, div_ret->element);
	#else // new
			descr.type = SPARSE_MATRIX_TYPE_GENERAL;
			//descr.mode = ?
			//descr.diag = ?
			mkl_sparse_d_mv(
				SPARSE_OPERATION_TRANSPOSE,
				(double)1.0,
				mkl_div_a[i],
				descr,
				div_vb[j]->element,
				(double)0.0,
				div_ret->element
			);
	#endif // USE_IMKL_OLD
#else // USE_IMKL
            mul_drsmatrixt_dvec(div_ret, div_a[i], div_vb[j]);
#endif // USE_IMKL
			//printf("%ld,%ld ||div_ret||_F = %10.3e\n", i, j, norm2_dvector(div_ret));
            add_qdvector_dvec(ret, ret, div_ret);
       }
    }

#ifdef USE_IMKL
	#ifdef USE_IMKL_OLD
	free(i_div_a_csr);
	#else // New!
	free(i_div_a_csr_start);
	free(i_div_a_csr_end);
	for(i = 0; i < max_num_div_a; i++)
		mkl_sparse_destroy(mkl_div_a[i]);
	free(mkl_div_a);
	#endif // USE_IMKL_OLD
	free(j_div_a_csr);
#endif // USE_IMKL

	free_dvector(div_ret);
    for(i = 0; i < max_num_div_a; i++)
        free_drsmatrix(div_a[i]);
    for(i = 0; i < max_num_div_vb; i++)
        free_dvector(div_vb[i]);

    free(div_a);
    free(div_vb);

}

// Incomplete LU decomposition; iLU0_qdrsmatrix
void iLU0_qdrsmatrix(QDRSMatrix mat)
{
	long int i, j, k, row_dim, col_dim;
	double aii[QDSIZE], aji[QDSIZE], ajk[QDSIZE], aik[QDSIZE], ctmp[QDSIZE];
	//double dtmp[QDSIZE];

	row_dim = mat->row_dim;
	col_dim = mat->col_dim;

	for(i = 0; i < row_dim; i++)
	{
		get_qdrsmatrix_ij(aii, mat, i, i);
		if(rqd_cmp_ui(aii, 0UL) != 0)
		{
			for(j = i + 1; j < row_dim; j++)
			{
				get_qdrsmatrix_ij(aji, mat, j, i);
				if(rqd_cmp_ui(aji, 0UL) != 0)
				{
					//aji /= aii;
					rqd_div(aji, aji, aii);
					set_qdrsmatrix_ij(mat, j, i, aji);
					for(k = i + 1; k < col_dim; k++)
					{
						get_qdrsmatrix_ij(ajk, mat, j, k);
						get_qdrsmatrix_ij(aik, mat, i, k);
						if((rqd_cmp_ui(ajk, 0UL) != 0) && (rqd_cmp_ui(aik, 0UL) != 0))
						{
							//ajk = ajk - aji * aik;
							rqd_mul(ctmp, aji, aik);
							rqd_sub(ajk, ajk, ctmp);
							set_qdrsmatrix_ij(mat, j, k, ajk);
							//printf("%ld, %ld, %ld\n", i, j, k);
						}
					}
				}
			}
		}
	}
}

// iLU0_solve: iLU * x = b
void solve_iLU0_qdrsmatrix(QDVector ret, QDRSMatrix ilu, QDVector b)
{
	long int i, j, row_dim, col_dim;
	double ret_i[QDSIZE], ret_j[QDSIZE], ilu_ii[QDSIZE], ilu_ij[QDSIZE], ctmp[QDSIZE];

	row_dim = ilu->row_dim;
	col_dim = ilu->col_dim;

	// ret := b
	subst_qdvector(ret, b);

	// Forward substitution
	for(i = 0; i < row_dim; i++)
	{
		get_qdrsmatrix_ij(ilu_ii, ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(rqd_cmp_ui(ilu_ii, 0UL) != 0)
		{
			for(j = 0; j < i; j++)
			{
				get_qdrsmatrix_ij(ilu_ij, ilu, i, j);
				if(rqd_cmp_ui(ilu_ij, 0UL) != 0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_j = ret_j - ilu_ji * ret_i;
					rqd_mul(ctmp, ilu_ij, ret_j);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_qdvector_i(ret, j, &ret_j);
					//printf("f: %ld, %ld\n", i, j);
				}
			}
			set_qdvector_i(ret, i, ret_i);
		}
	}

	// Backward substitution
	for(i = (row_dim - 1); i >= 0; i--)
	{
		get_qdrsmatrix_ij(ilu_ii, ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(rqd_cmp_ui(ilu_ii, 0UL) != 0)
		{
			for(j = (i + 1); j < col_dim; j++)
			{
				get_qdrsmatrix_ij(ilu_ij, ilu, i, j);
				if(rqd_cmp_ui(ilu_ij, 0UL) != 0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ij * ret_j;
					rqd_mul(ctmp, ilu_ij, ret_j);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_qdvector_i(ret, i, ret_i);
					//printf("b: %ld, %ld\n", i, j);
				}
			}
			//ret_i /= ilu_ii;
			rqd_div(ret_i, ret_i, ilu_ii);
			set_qdvector_i(ret, i, ret_i);
		}
	}
}

// iLU0t_solve: x^T * iLU = b^T
void solve_iLU0t_qdrsmatrix(QDVector ret, QDRSMatrix ilu, QDVector b)
{
	long int i, j, row_dim, col_dim;
	double ret_i[QDSIZE], ret_j[QDSIZE], ctmp[QDSIZE], ilu_ii[QDSIZE], ilu_ji[QDSIZE];

	row_dim = ilu->row_dim;
	col_dim = ilu->col_dim;

	// ret := b
	subst_qdvector(ret, b);

	// Forward substitution
	for(i = 0; i < row_dim; i++)
	{
		get_qdrsmatrix_ij(ilu_ii, ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(rqd_cmp_ui(ilu_ii, 0UL) != 0)
		{
			for(j = 0; j < i; j++)
			{
				get_qdrsmatrix_ij(ilu_ji, ilu, j, i);
				if(rqd_cmp_ui(ilu_ji, 0UL) != 0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ji * ret_j;
					rqd_mul(ctmp, ret_j, ilu_ji);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_cdvector_i(ret, i, ret_i);
				}
			}
			//ret_i /= ilu_ii;
			rqd_div(ret_i, ret_i, ilu_ii);
			set_qdvector_i(ret, i, ret_i);
		}
	}

	// Backward substitution
	for(i = row_dim - 1; i >= 0; i--)
	{
		get_qdrsmatrix_ij(ilu_ii, ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(rqd_cmp_ui(ilu_ii, 0UL) != 0)
		{
			for(j = (i + 1); j < col_dim; j++)
			{
				get_qdrsmatrix_ij(ilu_ji, ilu, j, i);
				if(rqd_cmp_ui(ilu_ji, 0UL) != 0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ji * ret_j;
					rqd_mul(ctmp, ret_j, ilu_ji);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_cdvector_i(ret, j, ret_j);
				}
			}
			set_qdvector_i(ret, i, ret_i);
		}
	}
}

// iLU0_solve: iLU * x = b
void solve_iLU0_drsmatrix_qdvec(QDVector ret, DRSMatrix ilu, QDVector b)
{
	long int i, j, row_dim, col_dim;
	double ilu_ii, ilu_ij;
	double ret_i[QDSIZE], ret_j[QDSIZE], ctmp[QDSIZE];

	row_dim = ilu->row_dim;
	col_dim = ilu->col_dim;

	// ret := b
	subst_qdvector(ret, b);

	// Forward substitution
	for(i = 0; i < row_dim; i++)
	{
		ilu_ii = get_drsmatrix_ij(ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(fabs(ilu_ii) != 0.0)
		{
			for(j = 0; j < i; j++)
			{
				ilu_ij = get_drsmatrix_ij(ilu, i, j);
				if(fabs(ilu_ij) != 0.0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_j = ret_j - ilu_ji * ret_i;
					rqd_mul_d(ctmp, ret_j, ilu_ij);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_qdvector_i(ret, j, ret_j);
					//printf("f: %ld, %ld\n", i, j);
				}
			}
			set_qdvector_i(ret, i, ret_i);
		}
	}

	// Backward substitution
	for(i = (row_dim - 1); i >= 0; i--)
	{
		ilu_ii = get_drsmatrix_ij(ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(fabs(ilu_ii) != 0.0)
		{
			for(j = (i + 1); j < col_dim; j++)
			{
				ilu_ij = get_drsmatrix_ij(ilu, i, j);
				if(fabs(ilu_ij) != 0.0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ij * ret_j;
					//rqd_mul(ctmp, ilu_ij, ret_j);
					rqd_mul_d(ctmp, ret_j, ilu_ij);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_qdvector_i(ret, i, ret_i);
					//printf("b: %ld, %ld\n", i, j);
				}
			}
			//ret_i /= ilu_ii;
			//rqd_div(ret_i, ret_i, ilu_ii);
			rqd_div_d(ret_i, ret_i, ilu_ii);
			set_qdvector_i(ret, i, ret_i);
		}
	}
}

// iLU0t_solve: x^T * iLU = b^T
void solve_iLU0t_drsmatrix_qdvec(QDVector ret, DRSMatrix ilu, QDVector b)
{
	long int i, j, row_dim, col_dim;
	double ilu_ii, ilu_ji;
	double ret_i[QDSIZE], ret_j[QDSIZE], ctmp[QDSIZE];

	row_dim = ilu->row_dim;
	col_dim = ilu->col_dim;

	// ret := b
	subst_qdvector(ret, b);

	// Forward substitution
	for(i = 0; i < row_dim; i++)
	{
		ilu_ii = get_drsmatrix_ij(ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(fabs(ilu_ii) != 0.0)
		{
			for(j = 0; j < i; j++)
			{
				ilu_ji = get_drsmatrix_ij(ilu, j, i);
				if(fabs(ilu_ji) != 0.0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ji * ret_j;
					rqd_mul_d(ctmp, ret_j, ilu_ji);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_cdvector_i(ret, i, ret_i);
				}
			}
			//ret_i /= ilu_ii;
			rqd_div_d(ret_i, ret_i, ilu_ii);
			set_qdvector_i(ret, i, ret_i);
		}
	}

	// Backward substitution
	for(i = row_dim - 1; i >= 0; i--)
	{
		ilu_ii = get_drsmatrix_ij(ilu, i, i);
		subst_qdvector_i(ret_i, ret, i);
		if(fabs(ilu_ii) != 0.0)
		{
			for(j = (i + 1); j < col_dim; j++)
			{
				ilu_ji = get_drsmatrix_ij(ilu, j, i);
				if(fabs(ilu_ji) != 0.0)
				{
					subst_qdvector_i(ret_j, ret, j);
					//ret_i = ret_i - ilu_ji * ret_j;
					rqd_mul_d(ctmp, ret_j, ilu_ji);
					rqd_sub(ret_i, ret_i, ctmp);
					//set_cdvector_i(ret, j, ret_j);
				}
			}
			set_qdvector_i(ret, i, ret_i);
		}
	}
}
#endif // USE_QDLINEAR
