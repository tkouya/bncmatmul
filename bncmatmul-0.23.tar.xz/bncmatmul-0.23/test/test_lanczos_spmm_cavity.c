/********************************************************************************/
/* test_lanczos_spmm_cavity.c:                                                  */
/* Copyright (C) 2023 Tomonori Kouya                                            */
/*                                                                              */
/* This program is free software: you can redistribute it and/or modify it      */
/* under the terms of the GNU Lesser General Public License as published by the */
/* Free Software Foundation, either version 3 of the License or any later       */
/* version.                                                                     */
/*                                                                              */
/* This program is distributed in the hope that it will be useful, but WITHOUT  */
/* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or        */
/* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License */
/* for more details.                                                            */
/*                                                                              */
/* You should have received a copy of the GNU Lesser General Public License     */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.        */
/*                                                                              */
/********************************************************************************/
/****************************************************/
/* Test Program for dlanczos, mpf_lanczos           */
/****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "bncmatmul.h"
//#include "bnc.h"
//#include "bncsparse.h"
//#include "bncmm.h"

/* Downloaded file from UF Sparse Matrix Collection */
#define MATRIX_MM_FILE "cavity04/cavity04.mtx"
#define VEC_ANS_MM_FILE "cavity04/cavity04_dx.mtx"
#define VEC_B_MM_FILE "cavity04/cavity04_db.mtx"

#ifdef USE_GMP
void free_mpfproblem(MPFMatrix a, MPFVector b, MPFVector ans)
{
	if(a != NULL)
		free_mpfmatrix(a);
	if(b != NULL)
		free_mpfvector(b);
	if(ans != NULL)
		free_mpfvector(ans);
}

void free_mpfproblem_sp(MPFRSMatrix a, MPFVector b, MPFVector ans)
{
	if(a != NULL)
		free_mpfrsmatrix(a);
	if(b != NULL)
		free_mpfvector(b);
	if(ans != NULL)
		free_mpfvector(ans);
}
#endif // USE_GMP

#define MAXTIMES 1000
#define PREC 512

void main()
{
	long int dim;
	long int maxtimes = MAXTIMES;
	DMatrix da;
	DRSMatrix da_sp;
	DVector db, dx, dans;
	double start, dtime[5], dtime_sp[5];
	long int itimes_d[5], itimes_d_sp[5];
	long int i, j;

#ifdef USE_GMP
	MPFMatrix mpfa;
	MPFVector mpfb, mpfx, mpfans;
	mpf_t reps, aeps;
	long int itimes_mpf[4][5], itimes_mpf_sp[4][5];
	double mpftime[4][5], mpftime_sp[4][5];

	MPFRSMatrix mpfa_sp;
#endif // USE_GMP

//goto MPFR;

/* Double */
	/* initialize & get problem */
	dans = init_dvector_readMMcoordinate(VEC_ANS_MM_FILE);
//	print_dvector(dans);

	dim = dans->dim;
	dx = init_dvector(dim);

	/* run DBiCG_sp */
	da_sp = init_drsmatrix_readMMcoordinate(MATRIX_MM_FILE);
	db = init_dvector_readMMcoordinate(VEC_B_MM_FILE);

	printf("\n-- dim = %ld, DBiCG_sp\n", dim);
	start = get_secv();
	itimes_d_sp[0] = dlanczos_sp(dp_tri, da_sp);
	dtime_sp[0] = get_secv() - start;

	free_drsmatrix(da_sp);


MPFR:
#ifdef USE_GMP
/* MPF */
	set_bnc_default_prec(PREC);
	/* initialize */

//	goto MPFGPBiCG;
MPFBiCG:

#ifndef SPARSEONLY
	/* run MPFBiCG */
	/* load */
	mpfa = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans);
//	mpfa_sp = get_mpfproblem_sp(mpfa, mpfb, mpfans);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	printf("\n--- dim = %ld, prec = %ld, MPFBiCG\n", dim, (unsigned long)PREC);
	start = get_secv();
	itimes_mpf[0][0]  = MPFBiCG(mpfx, mpfa, mpfb, reps, aeps, maxtimes);
	mpftime[0][0] = get_secv() - start;
	free_mpfproblem(mpfa, mpfb, mpfans);

	printf("\n--- dim = %ld, prec = %ld, MPFBiCG\n", dim, (unsigned long)PREC * 2);
	mpfa2 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf[0][1] = MPFBiCG(mpfx2, mpfa2, mpfb2, reps2, aeps2, maxtimes);
	mpftime[0][1] = get_secv() - start;
	free_mpfproblem(mpfa2, mpfb2, mpfans2);

	printf("\n--- dim = %ld, prec = %ld, MPFBiCG\n", dim, (unsigned long)PREC * 4);
	mpfa3 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);

	start = get_secv();
	itimes_mpf[0][2] = MPFBiCG(mpfx3, mpfa3, mpfb3, reps3, aeps3, maxtimes);
	mpftime[0][2] = get_secv() - start;
	free_mpfproblem(mpfa3, mpfb3, mpfans3);

	printf("\n--- dim = %ld, prec = %ld, MPFBiCG\n", dim, (unsigned long)PREC * 8);
	mpfa4 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);

	start = get_secv();
	itimes_mpf[0][3] = MPFBiCG(mpfx4, mpfa4, mpfb4, reps4, aeps4, maxtimes);
	mpftime[0][3] = get_secv() - start;
	free_mpfproblem(mpfa4, mpfb4, mpfans4);

	printf("\n--- dim = %ld, prec = %ld, MPFBiCG\n", dim, (unsigned long)PREC * 16);
	mpfa5 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);

	start = get_secv();
	itimes_mpf[0][4] = MPFBiCG(mpfx5, mpfa5, mpfb5, reps5, aeps5, maxtimes);
	mpftime[0][4] = get_secv() - start;
	free_mpfproblem(mpfa5, mpfb5, mpfans5);

	/* print */
//	print_mpfvector(mpfx);
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/
#endif // SPARSEONLY

MPFBiCG_sp:

	/* run MPFBiCG */
//	get_mpfproblem(mpfa, mpfb, mpfans);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans, PREC);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	printf("\n-- dim = %ld, prec = %ld, MPFBiCG_sp\n", dim, (unsigned long)PREC);
	mpfa_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);

#ifdef SPARSEONLY
	mpfx  = init2_mpfvector(dim, PREC);
	mpfx2 = init2_mpfvector(dim, PREC * 2);
	mpfx3 = init2_mpfvector(dim, PREC * 4);
	mpfx4 = init2_mpfvector(dim, PREC * 8);
	mpfx5 = init2_mpfvector(dim, PREC * 16);
#endif // SPARSEONLY

	start = get_secv();
	itimes_mpf_sp[0][0]  = MPFBiCG_sp(mpfx, mpfa_sp, mpfb, reps, aeps, maxtimes);
	mpftime_sp[0][0] = get_secv() - start;
	free_mpfproblem_sp(mpfa_sp, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCG_sp\n", dim, (unsigned long)PREC * 2);
	mpfa2_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf_sp[0][1] = MPFBiCG_sp(mpfx2, mpfa2_sp, mpfb2, reps2, aeps2, maxtimes);
	mpftime_sp[0][1] = get_secv() - start;
	free_mpfproblem_sp(mpfa2_sp, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCG_sp\n", dim, (unsigned long)PREC * 4);
	mpfa3_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);
//	get_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3, PREC * 4);
	start = get_secv();
	itimes_mpf_sp[0][2] = MPFBiCG_sp(mpfx3, mpfa3_sp, mpfb3, reps3, aeps3, maxtimes);
	mpftime_sp[0][2] = get_secv() - start;
	free_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCG_sp\n", dim, (unsigned long)PREC * 8);
	mpfa4_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);
	//get_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4, PREC * 8);
	start = get_secv();
	itimes_mpf_sp[0][3] = MPFBiCG_sp(mpfx4, mpfa4_sp, mpfb4, reps4, aeps4, maxtimes);
	mpftime_sp[0][3] = get_secv() - start;
	free_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCG_sp\n", dim, (unsigned long)PREC * 16);
	mpfa5_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);
	//get_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5, PREC * 16);
	start = get_secv();
	itimes_mpf_sp[0][4] = MPFBiCG_sp(mpfx5, mpfa5_sp, mpfb5, reps5, aeps5, maxtimes);
	mpftime_sp[0][4] = get_secv() - start;
	free_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5);

	/* print */
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/

MPFCGS:

#ifndef SPARSEONLY
	/* run MPFCGS */
	/* load */
	mpfa = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans);
//	mpfa_sp = get_mpfproblem_sp(mpfa, mpfb, mpfans);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	mpfx  = init2_mpfvector(dim, PREC);
	mpfx2 = init2_mpfvector(dim, PREC * 2);
	mpfx3 = init2_mpfvector(dim, PREC * 4);
	mpfx4 = init2_mpfvector(dim, PREC * 8);
	mpfx5 = init2_mpfvector(dim, PREC * 16);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS\n", dim, (unsigned long)PREC);
	start = get_secv();
	itimes_mpf[1][0]  = MPFCGS(mpfx, mpfa, mpfb, reps, aeps, maxtimes);
	mpftime[1][0] = get_secv() - start;
	free_mpfproblem(mpfa, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS\n", dim, (unsigned long)PREC * 2);
	mpfa2 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf[1][1] = MPFCGS(mpfx2, mpfa2, mpfb2, reps2, aeps2, maxtimes);
	mpftime[1][1] = get_secv() - start;
	free_mpfproblem(mpfa2, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS\n", dim, (unsigned long)PREC * 4);
	mpfa3 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);

	start = get_secv();
	itimes_mpf[1][2] = MPFCGS(mpfx3, mpfa3, mpfb3, reps3, aeps3, maxtimes);
	mpftime[1][2] = get_secv() - start;
	free_mpfproblem(mpfa3, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS\n", dim, (unsigned long)PREC * 8);
	mpfa4 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);

	start = get_secv();
	itimes_mpf[1][3] = MPFCGS(mpfx4, mpfa4, mpfb4, reps4, aeps4, maxtimes);
	mpftime[1][3] = get_secv() - start;
	free_mpfproblem(mpfa4, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS\n", dim, (unsigned long)PREC * 16);
	mpfa5 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);

	start = get_secv();
	itimes_mpf[1][4] = MPFCGS(mpfx5, mpfa5, mpfb5, reps5, aeps5, maxtimes);
	mpftime[1][4] = get_secv() - start;
	free_mpfproblem(mpfa5, mpfb5, mpfans5);

	/* print */
//	print_mpfvector(mpfx);
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/
#endif // SPARSEONLY

MPFCGS_sp:

	/* run MPFCGS */
//	get_mpfproblem(mpfa, mpfb, mpfans);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans, PREC);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	printf("\n-- dim = %ld, prec = %ld, MPFCGS_sp\n", dim, (unsigned long)PREC);
	mpfa_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);

#ifdef SPARSEONLY
	mpfx  = init2_mpfvector(dim, PREC);
	mpfx2 = init2_mpfvector(dim, PREC * 2);
	mpfx3 = init2_mpfvector(dim, PREC * 4);
	mpfx4 = init2_mpfvector(dim, PREC * 8);
	mpfx5 = init2_mpfvector(dim, PREC * 16);
#endif

	start = get_secv();
	itimes_mpf_sp[1][0]  = MPFCGS_sp(mpfx, mpfa_sp, mpfb, reps, aeps, maxtimes);
	mpftime_sp[1][0] = get_secv() - start;
	free_mpfproblem_sp(mpfa_sp, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS_sp\n", dim, (unsigned long)PREC * 2);
	mpfa2_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf_sp[1][1] = MPFCGS_sp(mpfx2, mpfa2_sp, mpfb2, reps2, aeps2, maxtimes);
	mpftime_sp[1][1] = get_secv() - start;
	free_mpfproblem_sp(mpfa2_sp, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS_sp\n", dim, (unsigned long)PREC * 4);
	mpfa3_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);
//	get_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3, PREC * 4);
	start = get_secv();
	itimes_mpf_sp[1][2] = MPFCGS_sp(mpfx3, mpfa3_sp, mpfb3, reps3, aeps3, maxtimes);
	mpftime_sp[1][2] = get_secv() - start;
	free_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS_sp\n", dim, (unsigned long)PREC * 8);
	mpfa4_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);
	//get_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4, PREC * 8);
	start = get_secv();
	itimes_mpf_sp[1][3] = MPFCGS_sp(mpfx4, mpfa4_sp, mpfb4, reps4, aeps4, maxtimes);
	mpftime_sp[1][3] = get_secv() - start;
	free_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFCGS_sp\n", dim, (unsigned long)PREC * 16);
	mpfa5_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);
	//get_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5, PREC * 16);
	start = get_secv();
	itimes_mpf_sp[1][4] = MPFCGS_sp(mpfx5, mpfa5_sp, mpfb5, reps5, aeps5, maxtimes);
	mpftime_sp[1][4] = get_secv() - start;
	free_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5);

	/* print */
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/

MPFBiCGSTAB:

#ifndef SPARSEONLY
	/* run MPFBiCGSTAB */
	/* load */
	mpfa = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans);
//	mpfa_sp = get_mpfproblem_sp(mpfa, mpfb, mpfans);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	mpfx  = init2_mpfvector(dim, PREC);
	mpfx2 = init2_mpfvector(dim, PREC * 2);
	mpfx3 = init2_mpfvector(dim, PREC * 4);
	mpfx4 = init2_mpfvector(dim, PREC * 8);
	mpfx5 = init2_mpfvector(dim, PREC * 16);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB\n", dim, (unsigned long)PREC);
	start = get_secv();
	itimes_mpf[2][0]  = MPFBiCGSTAB(mpfx, mpfa, mpfb, reps, aeps, maxtimes);
	mpftime[2][0] = get_secv() - start;
	free_mpfproblem(mpfa, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB\n", dim, (unsigned long)PREC * 2);
	mpfa2 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf[2][1] = MPFBiCGSTAB(mpfx2, mpfa2, mpfb2, reps2, aeps2, maxtimes);
	mpftime[2][1] = get_secv() - start;
	free_mpfproblem(mpfa2, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB\n", dim, (unsigned long)PREC * 4);
	mpfa3 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);

	start = get_secv();
	itimes_mpf[2][2] = MPFBiCGSTAB(mpfx3, mpfa3, mpfb3, reps3, aeps3, maxtimes);
	mpftime[2][2] = get_secv() - start;
	free_mpfproblem(mpfa3, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB\n", dim, (unsigned long)PREC * 8);
	mpfa4 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);

	start = get_secv();
	itimes_mpf[2][3] = MPFBiCGSTAB(mpfx4, mpfa4, mpfb4, reps4, aeps4, maxtimes);
	mpftime[2][3] = get_secv() - start;
	free_mpfproblem(mpfa4, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB\n", dim, (unsigned long)PREC * 16);
	mpfa5 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);

	start = get_secv();
	itimes_mpf[2][4] = MPFBiCGSTAB(mpfx5, mpfa5, mpfb5, reps5, aeps5, maxtimes);
	mpftime[2][4] = get_secv() - start;
	free_mpfproblem(mpfa5, mpfb5, mpfans5);

	/* print */
//	print_mpfvector(mpfx);
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/
#endif // SPARSEONLY

MPFBiCGSTAB_sp:

	/* run MPFBiCGSTAB */
//	get_mpfproblem(mpfa, mpfb, mpfans);
//	get_mpfproblem_sp(mpfa_sp, mpfb, mpfans, PREC);
//	print_mpfrsmatrix(mpfa_sp);
//	return;

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB_sp\n", dim, (unsigned long)PREC);
	mpfa_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);

#ifdef SPARSEONLY
	mpfx  = init2_mpfvector(dim, PREC);
	mpfx2 = init2_mpfvector(dim, PREC * 2);
	mpfx3 = init2_mpfvector(dim, PREC * 4);
	mpfx4 = init2_mpfvector(dim, PREC * 8);
	mpfx5 = init2_mpfvector(dim, PREC * 16);
#endif // SPARSEONLY

	start = get_secv();
	itimes_mpf_sp[2][0]  = MPFBiCGSTAB_sp(mpfx, mpfa_sp, mpfb, reps, aeps, maxtimes);
	mpftime_sp[2][0] = get_secv() - start;
	free_mpfproblem_sp(mpfa_sp, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB_sp\n", dim, (unsigned long)PREC * 2);
	mpfa2_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf_sp[2][1] = MPFBiCGSTAB_sp(mpfx2, mpfa2_sp, mpfb2, reps2, aeps2, maxtimes);
	mpftime_sp[2][1] = get_secv() - start;
	free_mpfproblem_sp(mpfa2_sp, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB_sp\n", dim, (unsigned long)PREC * 4);
	mpfa3_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);
//	get_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3, PREC * 4);
	start = get_secv();
	itimes_mpf_sp[2][2] = MPFBiCGSTAB_sp(mpfx3, mpfa3_sp, mpfb3, reps3, aeps3, maxtimes);
	mpftime_sp[2][2] = get_secv() - start;
	free_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB_sp\n", dim, (unsigned long)PREC * 8);
	mpfa4_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);
	//get_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4, PREC * 8);
	start = get_secv();
	itimes_mpf_sp[2][3] = MPFBiCGSTAB_sp(mpfx4, mpfa4_sp, mpfb4, reps4, aeps4, maxtimes);
	mpftime_sp[2][3] = get_secv() - start;
	free_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFBiCGSTAB_sp\n", dim, (unsigned long)PREC * 16);
	mpfa5_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);
	//get_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5, PREC * 16);
	start = get_secv();
	itimes_mpf_sp[2][4] = MPFBiCGSTAB_sp(mpfx5, mpfa5_sp, mpfb5, reps5, aeps5, maxtimes);
	mpftime_sp[2][4] = get_secv() - start;
	free_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5);

	/* print */
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/

MPFGPBiCG:
#ifndef SPARSEONLY
	/* run MPFGPBiCG */
	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG\n", dim, (unsigned long)PREC);
	mpfa = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);

	start = get_secv();
	itimes_mpf[3][0]  = MPFGPBiCG(mpfx, mpfa, mpfb, reps, aeps, maxtimes);
	mpftime[3][0] = get_secv() - start;
	free_mpfproblem(mpfa, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG\n", dim, (unsigned long)PREC * 2);
	mpfa2 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf[3][1] = MPFGPBiCG(mpfx2, mpfa2, mpfb2, reps2, aeps2, maxtimes);
	mpftime[3][1] = get_secv() - start;
	free_mpfproblem(mpfa2, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG\n", dim, (unsigned long)PREC * 4);
	mpfa3 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);

	start = get_secv();
	itimes_mpf[3][2] = MPFGPBiCG(mpfx3, mpfa3, mpfb3, reps3, aeps3, maxtimes);
	mpftime[3][2] = get_secv() - start;
	free_mpfproblem(mpfa3, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG\n", dim, (unsigned long)PREC * 8);
	mpfa4 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);

	start = get_secv();
	itimes_mpf[3][3] = MPFGPBiCG(mpfx4, mpfa4, mpfb4, reps4, aeps4, maxtimes);
	mpftime[3][3] = get_secv() - start;
	free_mpfproblem(mpfa4, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG\n", dim, (unsigned long)PREC * 16);
	mpfa5 = init2_mpfmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);

	start = get_secv();
	itimes_mpf[3][4] = MPFGPBiCG(mpfx5, mpfa5, mpfb5, reps5, aeps5, maxtimes);
	mpftime[3][4] = get_secv() - start;
	free_mpfproblem(mpfa5, mpfb5, mpfans5);

	/* print */
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/
#endif // SPARSEONLY
MPFGPBiCG_sp:

	/* run MPFGPBiCG */
	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG_sp\n", dim, (unsigned long)PREC);
	mpfa_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC);
	mpfans = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC);
	mpfb = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC);

	start = get_secv();
	itimes_mpf_sp[3][0]  = MPFGPBiCG_sp(mpfx, mpfa_sp, mpfb, reps, aeps, maxtimes);
	mpftime_sp[3][0] = get_secv() - start;
	free_mpfproblem_sp(mpfa_sp, mpfb, mpfans);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG_sp\n", dim, (unsigned long)PREC * 2);
	mpfa2_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 2);
	mpfans2 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 2);
	mpfb2 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 2);

	start = get_secv();
	itimes_mpf_sp[3][1] = MPFGPBiCG_sp(mpfx2, mpfa2_sp, mpfb2, reps2, aeps2, maxtimes);
	mpftime_sp[3][1] = get_secv() - start;
	free_mpfproblem_sp(mpfa2_sp, mpfb2, mpfans2);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG_sp\n", dim, (unsigned long)PREC * 4);
	mpfa3_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 4);
	mpfans3 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 4);
	mpfb3 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 4);

	start = get_secv();
	itimes_mpf_sp[3][2] = MPFGPBiCG_sp(mpfx3, mpfa3_sp, mpfb3, reps3, aeps3, maxtimes);
	mpftime_sp[3][2] = get_secv() - start;
	free_mpfproblem_sp(mpfa3_sp, mpfb3, mpfans3);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG_sp\n", dim, (unsigned long)PREC * 8);
	mpfa4_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 8);
	mpfans4 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 8);
	mpfb4 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 8);

	start = get_secv();
	itimes_mpf_sp[3][3] = MPFGPBiCG_sp(mpfx4, mpfa4_sp, mpfb4, reps4, aeps4, maxtimes);
	mpftime_sp[3][3] = get_secv() - start;
	free_mpfproblem_sp(mpfa4_sp, mpfb4, mpfans4);

	printf("\n-- dim = %ld, prec = %ld, MPFGPBiCG_sp\n", dim, (unsigned long)PREC * 16);
	mpfa5_sp = init2_mpfrsmatrix_readMMcoordinate(MATRIX_MM_FILE, PREC * 16);
	mpfans5 = init2_mpfvector_readMMcoordinate(VEC_ANS_MM_FILE, PREC * 16);
	mpfb5 = init2_mpfvector_readMMcoordinate(VEC_B_MM_FILE, PREC * 16);

	start = get_secv();
	itimes_mpf_sp[3][4] = MPFGPBiCG_sp(mpfx5, mpfa5_sp, mpfb5, reps5, aeps5, maxtimes);
	mpftime_sp[3][4] = get_secv() - start;
	free_mpfproblem_sp(mpfa5_sp, mpfb5, mpfans5);

	/* print */
/*	for(i = 0; i < dim; i++)
	{
		printf("%5ld ", i);
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx2, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx3, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx4, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfx5, i));
		printf(" ");
		mpf_out_str(stdout, 10, (unsigned int)floor(log10(2.0) * PREC), get_mpfvector_i(mpfans, i));
		printf("\n");
	}
*/
	/* end */
	mpf_clear(reps); mpf_clear(aeps);
	mpf_clear(reps2); mpf_clear(aeps2);
	mpf_clear(reps3); mpf_clear(aeps3);
	free_mpfvector(mpfx);
	free_mpfvector(mpfx2);
	free_mpfvector(mpfx3);
#endif // USE_GMP

	/* print itimes */
	printf("Iterative Times\n");
	printf("double(BiCG)       : %ld(%f)\n", itimes_d[0]   , dtime[0]   );
	printf("double(BiCG_sp)    : %ld(%f)\n", itimes_d_sp[0], dtime_sp[0]);
	printf("     Speedup Ratio : %f\n", dtime[0] / dtime_sp[0]);
	printf("double(CGS)        : %ld(%f)\n", itimes_d[1]   , dtime[1]   );
	printf("double(CGS_sp)     : %ld(%f)\n", itimes_d_sp[1], dtime_sp[1]);
	printf("     Speedup Ratio : %f\n", dtime[1] / dtime_sp[1]);
	printf("double(BiCGSTAB)   : %ld(%f)\n", itimes_d[2]   , dtime[2]   );
	printf("double(BiCGSTAB_sp): %ld(%f)\n", itimes_d_sp[2], dtime_sp[2]);
	printf("     Speedup Ratio : %f\n", dtime[2] / dtime_sp[2]);
	printf("double(GPBiCG)     : %ld(%f)\n", itimes_d[3]   , dtime[3]   );
	printf("double(GPBiCG_sp)  : %ld(%f)\n", itimes_d_sp[3], dtime_sp[3]);
	printf("     Speedup Ratio : %f\n", dtime[3] / dtime_sp[3]);
#ifdef USE_GMP
#ifdef USE_MPFR
#ifndef SPARSEONLY
	printf("mpfr_t(%ld,BiCG)       : %ld(%f)\n", (unsigned long)PREC, itimes_mpf   [0][0], mpftime   [0][0]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[0][0], mpftime_sp[0][0]);
	printf("       Speedup Ratio  : %f\n", mpftime[0][0] / mpftime_sp[0][0]);
	printf("mpfr_t(%ld,CGS)        : %ld(%f)\n", (unsigned long)PREC, itimes_mpf   [1][0], mpftime   [1][0]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[1][0], mpftime_sp[1][0]);
	printf("       Speedup Ratio  : %f\n", mpftime[1][0] / mpftime_sp[1][0]);
	printf("mpfr_t(%ld,BiCGSTAB)   : %ld(%f)\n", (unsigned long)PREC, itimes_mpf   [2][0], mpftime   [2][0]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[2][0], mpftime_sp[2][0]);
	printf("       Speedup Ratio  : %f\n", mpftime[2][0] / mpftime_sp[2][0]);
	printf("mpfr_t(%ld,GPBiCG)     : %ld(%f)\n", (unsigned long)PREC, itimes_mpf   [3][0], mpftime   [3][0]);
	printf("mpfr_t(%ld,GPBICG_sp)  : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[3][0], mpftime_sp[3][0]);
	printf("       Speedup Ratio  : %f\n", mpftime[3][0] / mpftime_sp[3][0]);
	printf("mpfr_t(%ld,BiCG)       : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf   [0][1], mpftime   [0][1]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf_sp[0][1], mpftime_sp[0][1]);
	printf("       Speedup Ratio  : %f\n", mpftime[0][1] / mpftime_sp[0][1]);
	printf("mpfr_t(%ld,CGS)        : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf   [1][1], mpftime   [1][1]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf_sp[1][1], mpftime_sp[1][1]);
	printf("       Speedup Ratio  : %f\n", mpftime[1][1] / mpftime_sp[1][1]);
	printf("mpfr_t(%ld,BiCGSTAB)   : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf   [2][1], mpftime   [2][1]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf_sp[2][1], mpftime_sp[2][1]);
	printf("       Speedup Ratio  : %f\n", mpftime[2][1] / mpftime_sp[2][1]);
	printf("mpfr_t(%ld,GPBiCG)     : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf   [3][1], mpftime   [3][1]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC * 2, itimes_mpf_sp[3][1], mpftime_sp[3][1]);
	printf("       Speedup Ratio  : %f\n", mpftime[3][1] / mpftime_sp[3][1]);
	printf("mpfr_t(%ld,BiCG)       : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf   [0][2], mpftime   [0][2]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf_sp[0][2], mpftime_sp[0][2]);
	printf("       Speedup Ratio  : %f\n", mpftime[0][2] / mpftime_sp[0][2]);
	printf("mpfr_t(%ld,CGS)        : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf   [1][2], mpftime   [1][2]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf_sp[1][2], mpftime_sp[1][2]);
	printf("       Speedup Ratio  : %f\n", mpftime[1][2] / mpftime_sp[1][2]);
	printf("mpfr_t(%ld,BiCGSTAB)   : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf   [2][2], mpftime   [2][2]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf_sp[2][2], mpftime_sp[2][2]);
	printf("       Speedup Ratio  : %f\n", mpftime[2][2] / mpftime_sp[2][2]);
	printf("mpfr_t(%ld,GPBiCG)     : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf   [3][2], mpftime   [3][2]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC * 4, itimes_mpf_sp[3][2], mpftime_sp[3][2]);
	printf("       Speedup Ratio  : %f\n", mpftime[3][2] / mpftime_sp[3][2]);
	printf("mpfr_t(%ld,BiCG)       : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf   [0][3], mpftime   [0][3]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf_sp[0][3], mpftime_sp[0][3]);
	printf("       Speedup Ratio  : %f\n", mpftime[0][3] / mpftime_sp[0][3]);
	printf("mpfr_t(%ld,CGS)        : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf   [1][3], mpftime   [1][3]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf_sp[1][3], mpftime_sp[1][3]);
	printf("       Speedup Ratio  : %f\n", mpftime[1][3] / mpftime_sp[1][3]);
	printf("mpfr_t(%ld,BiCGSTAB)   : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf   [2][3], mpftime   [2][3]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf_sp[2][3], mpftime_sp[2][3]);
	printf("       Speedup Ratio  : %f\n", mpftime[2][3] / mpftime_sp[2][3]);
	printf("mpfr_t(%ld,GPBiCG)     : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf   [3][3], mpftime   [3][3]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC * 8, itimes_mpf_sp[3][3], mpftime_sp[3][3]);
	printf("       Speedup Ratio  : %f\n", mpftime[3][3] / mpftime_sp[3][3]);
	printf("mpfr_t(%ld,BiCG)       : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf   [0][4], mpftime   [0][4]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf_sp[0][4], mpftime_sp[0][4]);
	printf("       Speedup Ratio  : %f\n", mpftime[0][4] / mpftime_sp[0][4]);
	printf("mpfr_t(%ld,CGS)        : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf   [1][4], mpftime   [1][4]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf_sp[1][4], mpftime_sp[1][4]);
	printf("       Speedup Ratio  : %f\n", mpftime[1][4] / mpftime_sp[1][4]);
	printf("mpfr_t(%ld,BiCGSTAB)   : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf   [2][4], mpftime   [2][4]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf_sp[2][4], mpftime_sp[2][4]);
	printf("       Speedup Ratio  : %f\n", mpftime[2][4] / mpftime_sp[2][4]);
	printf("mpfr_t(%ld,GPBiCG)     : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf   [3][4], mpftime   [3][4]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC * 16, itimes_mpf_sp[3][4], mpftime_sp[3][4]);
	printf("       Speedup Ratio  : %f\n", mpftime[3][4] / mpftime_sp[3][4]);
#else // SPARSEONLU
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[0][0], mpftime_sp[0][0]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[1][0], mpftime_sp[1][0]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[2][0], mpftime_sp[2][0]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC, itimes_mpf_sp[3][0], mpftime_sp[3][0]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC*2, itimes_mpf_sp[0][1], mpftime_sp[0][1]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC*2, itimes_mpf_sp[1][1], mpftime_sp[1][1]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC*2, itimes_mpf_sp[2][1], mpftime_sp[2][1]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC*2, itimes_mpf_sp[3][1], mpftime_sp[3][1]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC*4, itimes_mpf_sp[0][2], mpftime_sp[0][2]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC*4, itimes_mpf_sp[1][2], mpftime_sp[1][2]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC*4, itimes_mpf_sp[2][2], mpftime_sp[2][2]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC*4, itimes_mpf_sp[3][2], mpftime_sp[3][2]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC*8, itimes_mpf_sp[0][3], mpftime_sp[0][3]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC*8, itimes_mpf_sp[1][3], mpftime_sp[1][3]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC*8, itimes_mpf_sp[2][3], mpftime_sp[2][3]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC*8, itimes_mpf_sp[3][3], mpftime_sp[3][3]);
	printf("mpfr_t(%ld,BiCG_sp)    : %ld(%f)\n", (unsigned long)PREC*16, itimes_mpf_sp[0][4], mpftime_sp[0][4]);
	printf("mpfr_t(%ld,CGS_sp)     : %ld(%f)\n", (unsigned long)PREC*16, itimes_mpf_sp[1][4], mpftime_sp[1][4]);
	printf("mpfr_t(%ld,BiCGSTAB_sp): %ld(%f)\n", (unsigned long)PREC*16, itimes_mpf_sp[2][4], mpftime_sp[2][4]);
	printf("mpfr_t(%ld,GPBiCG_sp)  : %ld(%f)\n", (unsigned long)PREC*16, itimes_mpf_sp[3][4], mpftime_sp[3][4]);
#endif // SPARSEONLY
#else // USE_MPFR
	printf("mpf_t(128): %ld(%f)\n", itimes_mpf, mpftime[0]);
	printf("mpf_t(256): %ld(%f)\n", itimes_mpf2, mpftime[1]);
	printf("mpf_t(512): %ld(%f)\n", itimes_mpf3, mpftime[2]);
#endif // USE_MPFR
#endif // USE_GMP
}

