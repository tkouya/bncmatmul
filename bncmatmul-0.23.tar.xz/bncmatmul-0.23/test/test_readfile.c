// test_readfile.c
