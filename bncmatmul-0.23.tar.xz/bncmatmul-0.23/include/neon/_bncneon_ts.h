// ------------------------
// ---------- TS ----------
// ------------------------
#ifndef __BNCNEON_TS_H
#define __BNCNEON_TS_H

#include "_bncneon_ds.h"

#ifndef TSSIZE
    #define TSSIZE 3
#endif // TSSIZE

// NOTE: Implementation depends on scalar helper functions like frenorm, vec_sum, merge.

// ret := 0
static inline void _bncneon_rts_set0(float32x4_t ret[TSSIZE])
{
    ret[0] = vdupq_n_f32(0.0f);
    ret[1] = vdupq_n_f32(0.0f);
    ret[2] = vdupq_n_f32(0.0f);
}

// ret := -a
static inline void _bncneon_rts_neg(float32x4_t c[TSSIZE], float32x4_t a[TSSIZE])
{
    c[0] = vnegq_f32(a[0]);
    c[1] = vnegq_f32(a[1]);
    c[2] = vnegq_f32(a[2]);
}

// Placeholder for add, sub, mul, div which require scalar helpers
static inline void _bncneon_rts_add(float32x4_t ret[TSSIZE], float32x4_t a[TSSIZE], float32x4_t b[TSSIZE]) { /* Requires scalar frenorm etc. */ }
static inline void _bncneon_rts_sub(float32x4_t ret[TSSIZE], float32x4_t a[TSSIZE], float32x4_t b[TSSIZE]) { _bncneon_rts_neg(b, b); _bncneon_rts_add(ret, a, b); }
static inline void _bncneon_rts_mul(float32x4_t ret[TSSIZE], float32x4_t a[TSSIZE], float32x4_t b[TSSIZE]) { /* Requires scalar frenorm etc. */ }
static inline void _bncneon_rts_div(float32x4_t ret[TSSIZE], float32x4_t a[TSSIZE], float32x4_t b[TSSIZE]) { /* Requires scalar frenorm etc. */ }


#endif // __BNCNEON_TS_H
