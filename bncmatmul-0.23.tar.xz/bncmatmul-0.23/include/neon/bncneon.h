/************************************************************/
/* BNCneon.h ... Vector arithmetic with NEON                */
/* 2025-08-05 (Tue) Tomonori Kouya                          */
/************************************************************/
#ifndef __BNCNEON_H__
#define __BNCNEON_H__

#include <stdio.h>
#include <math.h>

// Helper functions for double-double arithmetic with NEON
// Note: ARM NEON doesn't have native double arithmetic in older versions
// We'll use float64x2_t for 2-element double vectors

#if defined(__ARM_NEON) //|| defined(__aarch64__)

#include <arm_neon.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// get_secv()
//#include "get_secv.h"

#if defined (_MSC_VER) || defined(__MINGW32__)
    #include <malloc.h> // _aligned_malloc, _aligned_free
#else //  defined (_MSC_VER) || defined(__MINGW32__)
    #include <stdlib.h> // aligned_alloc, free
#endif //  defined (_MSC_VER) || defined(__MINGW32__)

// rd[sd].h
#include "rdd.h"
#include "rds.h"
// mpfr_dtq_sd.h
#if defined(USE_GMP) && defined(USE_MPFR)
#include "mpfr_dtq_sd.h" // + mpfr_dd.
#endif //defined(USE_GMP) && defined(USE_MPFR)

//#ifndef __BNC_DDLINEAR_H__
//#include "dlinear.h"
//#include "ddlinear.h"
//#endif // __BNC_DDLINEAR_H__

// ------------------------
// -------- Float ---------
// ------------------------
#include "_bncneon_f.h"

// ------------------------
// -------- Double --------
// ------------------------
#include "_bncneon_d.h"

// ------------------------
// -- Error Free Trans. ---
// ------------------------
#include "_bncneon_feft.h"
#include "_bncneon_deft.h"

// ------------------------
// ---------- DD ----------
// ------------------------
#include "_bncneon_dd.h"
#include "_bncneon_cdd.h" // 2024-01-26(Fri)

// ------------------------
// ---------- TD ----------
// ------------------------
#include "_bncneon_td.h"
#include "_bncneon_ctd.h" // 2024-01-26(Fri)

// ------------------------
// ---------- QD ----------
// ------------------------
#include "_bncneon_qd.h"
#include "_bncneon_cqd.h" // 2024-01-26(Fri)

// ------------------------
// ---------- DS ----------
// ------------------------
#include "_bncneon_ds.h"

// ------------------------
// ---------- TS ----------
// ------------------------
#include "_bncneon_ts.h"

// ------------------------
// ---------- QS ----------
// ------------------------
#include "_bncneon_qs.h"

#ifdef __cplusplus
} // extern "C" {
#endif // __cpluplus

#endif // defined(__ARM_NEON) || defined(__aarch64__)

#endif // __BNCNEON_H__