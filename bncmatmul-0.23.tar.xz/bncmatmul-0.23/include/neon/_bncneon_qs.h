// ------------------------
// ---------- QS ----------
// ------------------------
#ifndef __BNCNEON_QS_H
#define __BNCNEON_QS_H

#include "_bncneon_ts.h"

#ifndef QSSIZE
    #define QSSIZE 4
#endif // QSSIZE

// NOTE: Implementation depends on scalar helper functions like frenorm4.

// ret := 0
static inline void _bncneon_rqs_set0(float32x4_t ret[QSSIZE])
{
    ret[0] = vdupq_n_f32(0.0f);
    ret[1] = vdupq_n_f32(0.0f);
    ret[2] = vdupq_n_f32(0.0f);
    ret[3] = vdupq_n_f32(0.0f);
}

// ret := -a
static inline void _bncneon_rqs_neg(float32x4_t c[QSSIZE], float32x4_t a[QSSIZE])
{
    c[0] = vnegq_f32(a[0]);
    c[1] = vnegq_f32(a[1]);
    c[2] = vnegq_f32(a[2]);
    c[3] = vnegq_f32(a[3]);
}

// Placeholder for add, sub, mul, div which require scalar helpers
static inline void _bncneon_rqs_add(float32x4_t ret[QSSIZE], float32x4_t a[QSSIZE], float32x4_t b[QSSIZE]) { /* Requires scalar frenorm4 etc. */ }
static inline void _bncneon_rqs_sub(float32x4_t ret[QSSIZE], float32x4_t a[QSSIZE], float32x4_t b[QSSIZE]) { _bncneon_rqs_neg(b, b); _bncneon_rqs_add(ret, a, b); }
static inline void _bncneon_rqs_mul(float32x4_t ret[QSSIZE], float32x4_t a[QSSIZE], float32x4_t b[QSSIZE]) { /* Requires scalar frenorm4 etc. */ }
static inline void _bncneon_rqs_div(float32x4_t ret[QSSIZE], float32x4_t a[QSSIZE], float32x4_t b[QSSIZE]) { /* Requires scalar frenorm4 etc. */ }


#endif // __BNCNEON_QS_H
